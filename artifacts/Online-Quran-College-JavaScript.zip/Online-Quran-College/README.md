# Online Quran College — JavaScript + Supabase

An updated version of your supplied Online Quran College project. Both uploaded ZIPs contained the same project (SHA-256 `1cf54d90f1b61881fdedb5c4566e6268a42d3757c1f71b2fc8da114f8e32243e`); the existing application, logo, styles and workflows form the base.

The application, configuration, scripts and tests are JavaScript/JSX. It uses Next.js 16, React 19 and PostgreSQL through Prisma's **JavaScript** client. SQL migrations run on Supabase PostgreSQL or a standard PostgreSQL server with the required extensions. TypeScript remains only a development dependency used by the JavaScript syntax/API tooling and upstream package typings.

## What is included

- Public website, searchable courses, teacher profiles, fees, journal, FAQs and trial/contact forms.
- Staff dashboard, searchable navigation with active links and a compact mobile menu.
- Course/page editors, approval and publication, revision history, preview links and scheduled publishing.
- Admissions, teacher assignment, student enrollment, time-zone scheduling, attendance and progress records.
- Invoices, partial payments, PDF downloads, reports, CSV exports and staff notifications.
- MFA, role permissions, secure sessions, CSRF protection and audit logging from the supplied project.
- **New:** Supabase SQL import with migration history, repeatable updates and private application tables protected by RLS.
- **New:** atomic PostgreSQL rate limiting shared by multiple instances; Redis is optional.
- **New:** pooled web connections, separate migration/worker connections, a protected scheduler endpoint and one-shot maintenance command.
- **New:** portable Docker web/worker images, production Compose configuration and updated CI.

No domain has been connected. Set `APP_URL` to the URL assigned by your host. No Supabase cloud project has been created or changed from this workspace.

## Run locally

Requirements: **Node 24**, Docker, and pnpm **10.34.6**. From this repository root:

```sh
bash infra/scripts/setup-cloud.sh
# If pnpm is not installed, prefix pnpm commands with:
# npm exec --yes --package=pnpm@10.34.6 --
pnpm dev
# A second terminal, for notifications and scheduled publication:
pnpm worker
```

Setup starts a local PostgreSQL database, preserves existing ignored environment files, generates local development secrets only when absent, installs locked dependencies and applies SQL migrations. Redis and object storage are optional. Development uses `apps/web/.next-dev`; production builds use `.next`.

`/api/health` checks the process. `/api/ready` checks configuration, the database, migrations and the selected rate-limit service. Validate these internally; this workspace's onboarding UI does not provide a public website preview.

Use the existing checkout for future cloud tasks; it is already isolated. Do not create a worktree unless explicitly requested.

## Supabase and deployment

Follow [the deployment guide](docs/DEPLOYMENT.md). The importable database is [supabase/schema.sql](supabase/schema.sql), and server configuration is documented in [.env.supabase.example](.env.supabase.example).

This is a full-stack application: deploy to a host with Node.js 24, Docker, or compatible Next.js server support. Plain static-only hosting such as GitHub Pages cannot run the admin/API/database features. Supabase hosts the database; your chosen provider hosts the application.

## First staff account and content

There is no default admin password. Set a random `BOOTSTRAP_TOKEN` securely in the app environment, then run:

```sh
pnpm bootstrap:admin --email your-staff-address
```

The CLI prompts for a password without echo. Open the one-time setup link privately, enroll MFA and save backup codes. Remove `BOOTSTRAP_TOKEN` afterwards. Production bootstrap additionally requires `--confirm-production`.

Enter your real courses, teachers, prices, contact details and consent wording through the admin area. Existing publication and admissions checks remain in place. Business content is not fabricated. Optional media uploads need private S3-compatible storage; Supabase Storage's S3 protocol is supported through the existing storage adapter. External AI, email delivery and payment gateways are not activated; payment records are entered by staff.

## Checks

```sh
pnpm check:js
pnpm lint
pnpm test:unit
pnpm test:integration
pnpm test:e2e
pnpm build
pnpm jobs:once
```

Integration/browser tests create and remove disposable databases on the **local Docker PostgreSQL**, never your Supabase project. Browser tests require Chromium; set `CHROMIUM_PATH` when needed. Test-only synthetic data is confined to these disposable databases.

See [current validation](docs/VALIDATION.md). Documents from the uploaded project are preserved under [docs/source-reference](docs/source-reference/README.md) and describe the previous implementation.
