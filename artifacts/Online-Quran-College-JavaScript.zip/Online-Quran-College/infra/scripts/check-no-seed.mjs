import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
const root=process.cwd(); const errors=[];
async function walk(dir){for(const entry of await readdir(dir,{withFileTypes:true})){if(entry.name.startsWith(".next")||["node_modules",".runtime",".next",".git","docs","test-results","playwright-report","generated"].includes(entry.name))continue;const file=path.join(dir,entry.name);if(entry.isDirectory()){await walk(file);continue;}if(/^seed[.]/.test(entry.name))errors.push(file+": forbidden seed script");if(/\.(js|jsx|ts|tsx|json|sql|csv)$/.test(entry.name)&&!file.includes("/tests/")){const text=await readFile(file,"utf8");if(/lorem ipsum|John Doe|example teacher/i.test(text))errors.push(file+": forbidden content");if(entry.name==="package.json"&&JSON.parse(text).prisma?.seed)errors.push(file+": prisma seed");}}}
await walk(root);if(errors.length){console.error(errors.join("\n"));process.exitCode=1;}else console.log("No-seed source checks passed");
