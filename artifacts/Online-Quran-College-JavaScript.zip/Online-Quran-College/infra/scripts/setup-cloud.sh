#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
node -e 'if(Number(process.versions.node.split(".")[0])!==24)throw new Error("Node 24 required")'
export npm_config_cache="${npm_config_cache:-$PWD/.runtime/npm-cache}"
export PNPM_HOME="${PNPM_HOME:-$PWD/.runtime/pnpm-home}"
mkdir -p "$PNPM_HOME"
pnpm_cmd() { npm exec --yes --package=pnpm@10.34.6 -- pnpm "$@"; }
oqc_existing_store="$(node <<'JS'
const fs = require('node:fs');
const file = 'node_modules/.modules.yaml';
if (fs.existsSync(file)) {
  const source = fs.readFileSync(file, 'utf8');
  let store;
  try { store = JSON.parse(source).storeDir; }
  catch { store = source.match(/^storeDir: (.+)$/m)?.[1]?.trim(); }
  if (store) process.stdout.write(store.replace(/\/v[0-9]+$/, ''));
}
JS
)"
CI=true pnpm_cmd install --frozen-lockfile --store-dir "${PNPM_STORE_DIR:-${oqc_existing_store:-$PWD/.runtime/pnpm-store}}"
node infra/scripts/init-local.mjs
docker compose up -d --wait postgres
docker compose exec -T postgres psql -U oqc -d postgres -v ON_ERROR_STOP=1 <<'SQL'
SELECT 'CREATE DATABASE oqc_dev' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname='oqc_dev')\gexec
SQL
pnpm_cmd db:generate
pnpm_cmd db:migrate
pnpm_cmd check:js
pnpm_cmd check:no-seed
