import { existsSync,readFileSync,writeFileSync,chmodSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import { createRequire } from 'node:module';
const { parse }=createRequire(new URL('../../apps/web/package.json',import.meta.url))('dotenv');
if(!existsSync('.env')){let text=readFileSync('.env.example','utf8');for(const name of ['AUTH_SECRET','S3_ACCESS_KEY','S3_SECRET_KEY'])text=text.replace(new RegExp('^'+name+'=$','m'),name+'='+randomBytes(48).toString('base64url'));writeFileSync('.env',text,{mode:0o600,flag:'wx'});}
const settings=parse(readFileSync('.env'));
if(!['localhost','127.0.0.1'].includes(new URL(settings.DATABASE_URL).hostname)||settings.NODE_ENV!=='development')throw new Error('Local setup only: remote database or non-development configuration requires the staging runbook.');
if(!settings.AUTH_SECRET||settings.AUTH_SECRET.length<32)throw new Error('Configure a random AUTH_SECRET in the local ignored .env file.');
chmodSync('.env',0o600);
if(!existsSync('apps/web/.env'))writeFileSync('apps/web/.env',readFileSync('.env'),{mode:0o600,flag:'wx'});
console.log('Local configuration available; existing files preserved.');
