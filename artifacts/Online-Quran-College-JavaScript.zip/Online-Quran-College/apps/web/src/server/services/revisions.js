export {
  contentRevisions,
  restoreRevision,
  revisionResource,
} from "@/server/repositories/revisions";
