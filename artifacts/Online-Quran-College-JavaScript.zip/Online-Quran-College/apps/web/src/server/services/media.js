import {
  PutObjectCommand,
  DeleteObjectCommand,
  GetObjectCommand,
} from "@aws-sdk/client-s3";
import { createHash } from "node:crypto";
import { storage, bucket } from "@/lib/media/storage";
import { normalizeUpload } from "@/lib/media/images";
import { recordImage, imageById } from "@/server/repositories/media";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
export async function uploadImage(bytes, altText, actorId) {
  const image = await normalizeUpload(bytes),
    storageKey = "private/images/" + newId() + ".webp",
    client = storage();
  await client.send(
    new PutObjectCommand({
      Bucket: bucket(),
      Key: storageKey,
      Body: image.bytes,
      ContentType: image.mimeType,
    }),
  );
  try {
    return await recordImage(
      {
        storageKey,
        mimeType: image.mimeType,
        width: image.width,
        height: image.height,
        sizeBytes: image.bytes.length,
        checksum: createHash("sha256").update(image.bytes).digest("hex"),
        altText,
      },
      actorId,
    );
  } catch (error) {
    await client
      .send(new DeleteObjectCommand({ Bucket: bucket(), Key: storageKey }))
      .catch(() => {});
    throw error;
  }
}
export async function privateImage(id) {
  const asset = await imageById(id);
  if (!asset) throw new AppError("NOT_FOUND", 404, "Image not found.");
  const object = await storage().send(
    new GetObjectCommand({ Bucket: bucket(), Key: asset.storageKey }),
  );
  if (!object.Body) throw new AppError("NOT_FOUND", 404, "Image not found.");
  return new Response(object.Body.transformToWebStream(), {
    headers: {
      "Content-Type": asset.mimeType,
      "Content-Length": String(asset.sizeBytes),
      "Content-Disposition": "inline",
      "X-Content-Type-Options": "nosniff",
      "Content-Security-Policy": "default-src 'none'; sandbox",
      "Cache-Control": "private, no-store",
    },
  });
}
