import { database } from "@/lib/db";
import { publishDueContent } from "@/server/services/publication-schedules";
import { drainOutbox } from "@/server/repositories/outbox";

export async function runMaintenance() {
  const publication = await publishDueContent();
  const notifications = await drainOutbox();
  const expiredBuckets = await database().$executeRaw`
    DELETE FROM "RateLimitBucket" WHERE key IN (
      SELECT key FROM "RateLimitBucket" WHERE "expiresAt" < CURRENT_TIMESTAMP
      ORDER BY "expiresAt" LIMIT 1000
    )`;
  return { ...publication, ...notifications, expiredBuckets };
}
