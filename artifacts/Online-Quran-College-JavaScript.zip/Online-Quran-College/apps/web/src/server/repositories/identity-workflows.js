import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import {
  decryptSecret,
  encryptSecret,
  hashPassword,
  hashToken,
  randomToken,
  verifyPassword,
} from "@/lib/auth/crypto";
import { generateSecret, generateURI, verify } from "otplib";
import { createSession } from "@/server/repositories/identity";
import { roles } from "@/lib/rbac/policy";
export async function login(email, password, code) {
  const db = database();
  const user = await db.user.findUnique({
    where: { email },
    include: { role: true },
  });
  const dummy =
    "$argon2id$v=19$m=19456,t=2,p=1$MTIzNDU2Nzg5MDEyMzQ1Ng$YUiRtvVvjIc+/EvTMUfomRSWBrNYYb9lTdqhNKVGMhg";
  const valid = await verifyPassword(
    user?.passwordHash ?? dummy,
    password,
  ).catch(() => false);
  const now = new Date();
  if (
    !user ||
    user.deletedAt ||
    (user.lockedUntil && user.lockedUntil > now) ||
    !valid ||
    !user.isActive ||
    user.mustEnrollMfa
  ) {
    if (user) {
      await db.$transaction(async (tx) => {
        const changed = await tx.user.update({
          where: { id: user.id },
          data: { failedLogins: { increment: 1 } },
        });
        if (changed.failedLogins >= 5)
          await tx.user.update({
            where: { id: user.id },
            data: { lockedUntil: new Date(Date.now() + 15 * 60 * 1000) },
          });
        await tx.auditLog.create({
          data: {
            id: newId(),
            actorId: user.id,
            action: "identity.login_failed",
            entityType: "User",
            entityId: user.id,
          },
        });
      });
    }
    throw new AppError(
      "UNAUTHENTICATED",
      401,
      "Unable to sign in. Check your credentials and MFA code.",
    );
  }
  if (user.mfaEnabled || ["SUPER_ADMIN", "ADMIN"].includes(user.role.key)) {
    if (!code || !user.mfaSecretEnc)
      throw new AppError(
        "UNAUTHENTICATED",
        401,
        "Unable to sign in. Check your credentials and MFA code.",
      );
    const step = Math.floor(Date.now() / 30000);
    const totp = await verify({
      secret: decryptSecret(user.mfaSecretEnc),
      token: code,
    }).catch(() => ({ valid: false }));
    if (totp.valid) {
      const claim = await db.user.updateMany({
        where: {
          id: user.id,
          OR: [{ lastMfaStep: null }, { lastMfaStep: { lt: step } }],
        },
        data: { lastMfaStep: step },
      });
      if (claim.count !== 1)
        throw new AppError(
          "UNAUTHENTICATED",
          401,
          "Wait for a new MFA code and try again.",
        );
    } else {
      const claimed = await db.mfaBackupCode.updateMany({
        where: { userId: user.id, codeHash: hashToken(code), usedAt: null },
        data: { usedAt: now },
      });
      if (claimed.count !== 1) {
        await db.user.update({
          where: { id: user.id },
          data: {
            failedLogins: { increment: 1 },
            lockedUntil:
              user.failedLogins >= 4
                ? new Date(Date.now() + 15 * 60 * 1000)
                : undefined,
          },
        });
        throw new AppError(
          "UNAUTHENTICATED",
          401,
          "Unable to sign in. Check your credentials and MFA code.",
        );
      }
    }
  }
  await db.$transaction([
    db.user.update({
      where: { id: user.id },
      data: { failedLogins: 0, lockedUntil: null, lastLoginAt: now },
    }),
    db.auditLog.create({
      data: {
        id: newId(),
        actorId: user.id,
        action: "identity.login",
        entityType: "User",
        entityId: user.id,
      },
    }),
  ]);
  return createSession(user.id);
}
export async function bootstrap({
  email,
  name,
  password,
  confirmProduction = false,
}) {
  const token = process.env.BOOTSTRAP_TOKEN;
  if (!token || token.length < 43)
    throw new AppError(
      "BOOTSTRAP_DISABLED",
      403,
      "Set a random bootstrap token with at least 32 bytes.",
    );
  if (process.env.NODE_ENV === "production" && !confirmProduction)
    throw new AppError(
      "BOOTSTRAP_CONFIRMATION",
      403,
      "Production confirmation required.",
    );
  const passwordHash = await hashPassword(password),
    setupToken = randomToken();
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(713094)`;
    if (await tx.user.count({ where: { role: { key: "SUPER_ADMIN" } } }))
      throw new AppError(
        "BOOTSTRAP_COMPLETE",
        409,
        "A Super Admin already exists.",
      );
    const role = await tx.role.findUnique({ where: { key: "SUPER_ADMIN" } });
    if (!role) throw new Error("Run system-constants migration first");
    const user = await tx.user.create({
      data: {
        id: newId(),
        email,
        name,
        passwordHash,
        roleId: role.id,
        isActive: false,
        mustEnrollMfa: true,
      },
    });
    await tx.mfaSetupToken.create({
      data: {
        id: newId(),
        userId: user.id,
        tokenHash: hashToken(setupToken),
        expiresAt: new Date(Date.now() + 30 * 60 * 1000),
      },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        action: "system.bootstrap",
        entityType: "User",
        entityId: user.id,
      },
    });
    return { setupToken };
  });
}
export async function beginMfaEnrollment(token) {
  const record = await database().mfaSetupToken.findUnique({
    where: { tokenHash: hashToken(token) },
    include: { user: true },
  });
  if (
    !record ||
    record.usedAt ||
    record.expiresAt <= new Date() ||
    !record.user.mustEnrollMfa
  )
    throw new AppError(
      "UNAUTHENTICATED",
      401,
      "This setup link has expired or was already used.",
    );
  let secret = record.user.mfaSecretEnc
    ? decryptSecret(record.user.mfaSecretEnc)
    : generateSecret();
  if (!record.user.mfaSecretEnc) {
    await database().user.updateMany({
      where: { id: record.userId, mfaSecretEnc: null },
      data: { mfaSecretEnc: encryptSecret(secret) },
    });
    const latest = await database().user.findUniqueOrThrow({
      where: { id: record.userId },
    });
    secret = decryptSecret(latest.mfaSecretEnc);
  }
  return {
    secret,
    uri: generateURI({
      issuer: process.env.MFA_ISSUER ?? "Online Quran College LTD",
      label: record.user.email,
      secret,
    }),
  };
}
export async function completeMfaEnrollment(token, code) {
  const db = database();
  const record = await db.mfaSetupToken.findUnique({
    where: { tokenHash: hashToken(token) },
    include: { user: true },
  });
  if (
    !record ||
    record.usedAt ||
    record.expiresAt <= new Date() ||
    !record.user.mfaSecretEnc
  )
    throw new AppError("UNAUTHENTICATED", 401, "Invalid setup link.");
  if (
    !(
      await verify({
        secret: decryptSecret(record.user.mfaSecretEnc),
        token: code,
      })
    ).valid
  )
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "Check your authenticator code.",
    );
  const codes = Array.from({ length: 10 }, () => randomToken().slice(0, 16));
  await db.$transaction(async (tx) => {
    const used = await tx.mfaSetupToken.updateMany({
      where: { id: record.id, usedAt: null, expiresAt: { gt: new Date() } },
      data: { usedAt: new Date() },
    });
    if (used.count !== 1)
      throw new AppError("CONFLICT", 409, "Setup link already used.");
    await tx.user.update({
      where: { id: record.userId },
      data: {
        mfaEnabled: true,
        isActive: true,
        mustEnrollMfa: false,
        lastMfaStep: Math.floor(Date.now() / 30000),
      },
    });
    await tx.mfaBackupCode.createMany({
      data: codes.map((code) => ({
        id: newId(),
        userId: record.userId,
        codeHash: hashToken(code),
      })),
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId: record.userId,
        action: "identity.mfa_enrolled",
        entityType: "User",
        entityId: record.userId,
      },
    });
  });
  return { backupCodes: codes };
}
export async function assertProductionBootstrapRemoved() {
  if (
    process.env.NODE_ENV === "production" &&
    process.env.BOOTSTRAP_TOKEN &&
    (await database().user.count({ where: { role: { key: "SUPER_ADMIN" } } }))
  )
    throw new Error("Remove BOOTSTRAP_TOKEN after initial setup");
}
export function validRole(value) {
  return roles.includes(value);
}
