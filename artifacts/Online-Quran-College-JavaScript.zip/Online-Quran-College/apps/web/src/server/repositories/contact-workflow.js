import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import { can } from "@/lib/rbac/policy";
import {
  contactWorkflowSchema,
  contactTransitions,
} from "@/lib/validation/contact-workflow";
export async function contactAssignees() {
  const users = await database().user.findMany({
    where: { isActive: true, mustEnrollMfa: false, deletedAt: null },
    orderBy: { name: "asc" },
    take: 200,
    select: { id: true, name: true, role: { select: { key: true } } },
  });
  return users
    .filter((user) => can(user.role.key, "contact-messages:update"))
    .map(({ id, name }) => ({ id, name }));
}
export async function updateContactWorkflow(id, input, actorId) {
  const data = contactWorkflowSchema.parse(input);
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${id},0))`;
    const current = await tx.contactMessage.findFirst({
      where: { id, deletedAt: null },
    });
    if (!current)
      throw new AppError("NOT_FOUND", 404, "Contact message not found.");
    if (current.updatedAt.getTime() !== new Date(data.updatedAt).getTime())
      throw new AppError(
        "CONFLICT",
        409,
        "This message changed. Refresh before saving.",
      );
    if (
      current.status !== data.status &&
      !contactTransitions[current.status]?.includes(data.status)
    )
      throw new AppError(
        "CONFLICT",
        409,
        "This status transition is not available.",
      );
    if (data.assignedToUserId) {
      const user = await tx.user.findFirst({
        where: {
          id: data.assignedToUserId,
          isActive: true,
          mustEnrollMfa: false,
          deletedAt: null,
        },
        select: { role: { select: { key: true } } },
      });
      if (!user || !can(user.role.key, "contact-messages:update"))
        throw new AppError(
          "VALIDATION_ERROR",
          400,
          "Choose an active admissions operator.",
        );
    }
    const changed = await tx.contactMessage.updateMany({
      where: { id, updatedAt: new Date(data.updatedAt), deletedAt: null },
      data: {
        status: data.status,
        assignedToUserId: data.assignedToUserId,
        updatedAt: new Date(
          Math.max(Date.now(), current.updatedAt.getTime() + 1),
        ),
        ...(data.status === "REPLIED" && current.status !== "REPLIED"
          ? { repliedAt: new Date(), repliedById: actorId }
          : {}),
      },
    });
    if (!changed.count)
      throw new AppError(
        "CONFLICT",
        409,
        "This message changed. Refresh before saving.",
      );
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "contact.workflow_updated",
        entityType: "ContactMessage",
        entityId: id,
        before: {
          status: current.status,
          assignedToUserId: current.assignedToUserId,
        },
        after: { status: data.status, assignedToUserId: data.assignedToUserId },
      },
    });
    return { id };
  });
}
