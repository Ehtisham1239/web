import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import { pricesSchema } from "@/lib/validation/prices";
export function planPrices(id) {
  return database().pricingPlanPrice.findMany({
    where: { planId: id },
    orderBy: { currency: "asc" },
    select: { id: true, currency: true, amountMinor: true, isPublic: true },
  });
}
export async function replacePlanPrices(id, input, actorId) {
  const data = pricesSchema.parse(input);
  return database().$transaction(async (tx) => {
    const plan = await tx.pricingPlan.findFirst({
      where: { id, deletedAt: null },
    });
    if (!plan) throw new AppError("NOT_FOUND", 404, "Pricing plan not found.");
    if (plan.status === "PUBLISHED")
      throw new AppError(
        "CONFLICT",
        409,
        "Return the plan to draft before changing its prices.",
      );
    const updated = await tx.pricingPlan.updateMany({
      where: { id, version: data.version, deletedAt: null },
      data: { version: { increment: 1 }, status: "DRAFT" },
    });
    if (!updated.count)
      throw new AppError(
        "CONFLICT",
        409,
        "This pricing plan changed. Refresh before saving.",
      );
    const before = await tx.pricingPlanPrice.findMany({
      where: { planId: id },
      select: { currency: true, amountMinor: true, isPublic: true },
    });
    await tx.contentRevision.create({
      data: {
        id: newId(),
        authorId: actorId,
        entityType: "plan-prices",
        entityId: id,
        snapshot: { prices: before },
      },
    });
    await tx.pricingPlanPrice.deleteMany({ where: { planId: id } });
    await tx.pricingPlanPrice.createMany({
      data: data.prices.map((price) => ({ id: newId(), planId: id, ...price })),
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "pricing.prices_updated",
        entityType: "PricingPlan",
        entityId: id,
        after: { priceCount: data.prices.length },
      },
    });
    return { id, version: data.version + 1 };
  });
}
