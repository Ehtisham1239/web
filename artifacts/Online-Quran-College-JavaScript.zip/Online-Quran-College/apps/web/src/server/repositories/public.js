import { database } from "@/lib/db";
import { AppError } from "@/lib/platform/errors";
import { publicPageLabels } from "@/lib/content/public-pages";
export async function publishedCourses() {
  return database().course.findMany({
    where: { status: "PUBLISHED", deletedAt: null },
    orderBy: [{ sortOrder: "asc" }, { id: "asc" }],
    select: {
      id: true,
      slug: true,
      title: true,
      summary: true,
      ageGroup: true,
      level: true,
      durationText: true,
      category: true,
    },
  });
}
export async function publishedCourse(slug) {
  return database().course.findFirst({
    where: { slug, status: "PUBLISHED", deletedAt: null },
    include: { courseModule_courseId: { orderBy: { sortOrder: "asc" } } },
  });
}
export async function courseRecommendations(course) {
  const db = database();
  const [courses, teachers] = await Promise.all([
    db.course.findMany({
      where: {
        status: "PUBLISHED",
        deletedAt: null,
        id: { not: course.id },
        OR: [{ ageGroup: course.ageGroup }, { level: course.level }],
      },
      orderBy: [{ sortOrder: "asc" }, { id: "asc" }],
      take: 3,
      select: { id: true, slug: true, title: true, summary: true },
    }),
    db.teacher.findMany({
      where: {
        isPublic: true,
        isActive: true,
        deletedAt: null,
        verificationNote: { not: null },
        NOT: { verificationNote: "" },
        teacherCourse_teacherId: { some: { courseId: course.id } },
      },
      orderBy: [{ displayName: "asc" }, { id: "asc" }],
      take: 6,
      select: {
        id: true,
        slug: true,
        displayName: true,
        bio: true,
        languages: true,
      },
    }),
  ]);
  return { courses, teachers };
}
export async function relatedPosts(slug, tags) {
  if (!tags.length) return [];
  return database().blogPost.findMany({
    where: {
      status: "PUBLISHED",
      locale: "en",
      slug: { not: slug },
      tags: { hasSome: tags },
    },
    orderBy: [{ publishedAt: "desc" }, { id: "asc" }],
    take: 3,
    select: { id: true, slug: true, title: true, excerpt: true },
  });
}
export async function publicTeachers() {
  return database().teacher.findMany({
    where: {
      isPublic: true,
      isActive: true,
      deletedAt: null,
      verificationNote: { not: null },
      NOT: { verificationNote: "" },
    },
    orderBy: { displayName: "asc" },
    select: {
      id: true,
      slug: true,
      displayName: true,
      gender: true,
      bio: true,
      languages: true,
      qualificationsText: true,
    },
  });
}
export async function publicContent(kind) {
  const db = database();
  switch (kind) {
    case "faq":
      return db.fAQ.findMany({
        where: { status: "PUBLISHED", locale: "en" },
        orderBy: { sortOrder: "asc" },
        select: { id: true, question: true, answer: true, category: true },
      });
    case "testimonials":
      return db.testimonial.findMany({
        where: { status: "PUBLISHED", consentRecordedAt: { not: null } },
        select: {
          id: true,
          name: true,
          role: true,
          country: true,
          quote: true,
        },
      });
    case "blog":
      return db.blogPost.findMany({
        where: { status: "PUBLISHED", locale: "en" },
        orderBy: { publishedAt: "desc" },
        select: {
          id: true,
          slug: true,
          title: true,
          excerpt: true,
          publishedAt: true,
        },
      });
    case "pricing":
      return db.pricingPlan.findMany({
        where: {
          status: "PUBLISHED",
          isPublic: true,
          deletedAt: null,
          pricingPlanPrice_planId: { some: { isPublic: true } },
        },
        include: { pricingPlanPrice_planId: { where: { isPublic: true } } },
      });
    default:
      return [];
  }
}
export async function publicPage(slug) {
  return database().cMSPage.findFirst({
    where: { slug, locale: "en", status: "PUBLISHED" },
    include: {
      pageSection_pageId: {
        where: { isVisible: true },
        orderBy: { sortOrder: "asc" },
      },
    },
  });
}
export async function publicSettings() {
  return database().setting.findMany({
    where: { isPublic: true },
    select: { key: true, value: true },
  });
}
export async function publicMenu(menu) {
  const items = await database().menuItem.findMany({
    where: { menu, parentId: null },
    orderBy: [{ sortOrder: "asc" }, { id: "asc" }],
    take: 40,
    select: { label: true, href: true },
  });
  return items.filter((item) => /^\/(?!\/)[a-zA-Z0-9/_-]*$/.test(item.href));
}
export async function publicDetailExists(resource, slug) {
  const db = database();
  if (resource === "courses")
    return (
      !!(await db.course.findFirst({
        where: { slug, status: "PUBLISHED", deletedAt: null },
        select: { id: true },
      })) || !!(await redirectFor("/courses/" + slug))
    );
  if (resource === "teachers")
    return !!(await db.teacher.findFirst({
      where: {
        slug,
        isPublic: true,
        isActive: true,
        deletedAt: null,
        verificationNote: { not: null },
        NOT: { verificationNote: "" },
      },
      select: { id: true },
    }));
  if (resource === "blog")
    return !!(await db.blogPost.findFirst({
      where: { slug, locale: "en", status: "PUBLISHED" },
      select: { id: true },
    }));
  return false;
}
export async function publicRouteExists(pathname) {
  if (
    pathname === "/admin" ||
    pathname.startsWith("/admin/") ||
    pathname.startsWith("/_next/")
  )
    return true;
  const path = pathname.replace(/\/$/, "") || "/";
  if (
    [
      "/",
      "/rss.xml",
      ...Object.keys(publicPageLabels).map((slug) => "/" + slug),
    ].includes(path)
  )
    return true;
  const detail = path.match(/^\/(courses|teachers|blog)\/([^/]+)$/);
  try {
    if (detail)
      return publicDetailExists(detail[1], decodeURIComponent(detail[2]));
    const single = path.match(/^\/([^/]+)$/);
    return single ? !!(await publicPage(decodeURIComponent(single[1]))) : false;
  } catch (error) {
    if (error instanceof URIError) return false;
    throw error;
  }
}
export async function publicTeacher(slug) {
  return database().teacher.findFirst({
    where: {
      slug,
      isPublic: true,
      isActive: true,
      deletedAt: null,
      verificationNote: { not: null },
      NOT: { verificationNote: "" },
    },
    select: {
      displayName: true,
      bio: true,
      qualificationsText: true,
      languages: true,
    },
  });
}
export async function publicPost(slug) {
  return database().blogPost.findFirst({
    where: { slug, locale: "en", status: "PUBLISHED" },
    select: {
      title: true,
      excerpt: true,
      renderedHtml: true,
      publishedAt: true,
      seoTitle: true,
      seoDescription: true,
      tags: true,
      author: { select: { name: true } },
    },
  });
}
export async function publishedPaths() {
  const [courses, teachers, pages, posts] = await Promise.all([
    database().course.findMany({
      where: { status: "PUBLISHED", deletedAt: null },
      select: { slug: true, updatedAt: true },
    }),
    database().teacher.findMany({
      where: {
        isPublic: true,
        isActive: true,
        deletedAt: null,
        verificationNote: { not: null },
        NOT: { verificationNote: "" },
      },
      select: { slug: true, updatedAt: true },
    }),
    database().cMSPage.findMany({
      where: { status: "PUBLISHED", locale: "en" },
      select: { slug: true, updatedAt: true },
    }),
    database().blogPost.findMany({
      where: { status: "PUBLISHED", locale: "en" },
      select: { slug: true, updatedAt: true },
    }),
  ]);
  return [
    ...courses.map((x) => ({
      path: "/courses/" + x.slug,
      updatedAt: x.updatedAt,
    })),
    ...teachers.map((x) => ({
      path: "/teachers/" + x.slug,
      updatedAt: x.updatedAt,
    })),
    ...pages.map((x) => ({ path: "/" + x.slug, updatedAt: x.updatedAt })),
    ...posts.map((x) => ({ path: "/blog/" + x.slug, updatedAt: x.updatedAt })),
  ];
}
export async function redirectFor(path) {
  return database().redirect.findUnique({
    where: { fromPath: path },
    select: { toPath: true },
  });
}
export async function publicCatalog(resource, query) {
  const db = database();
  const definitions = {
    courses: {
      model: "course",
      where: { status: "PUBLISHED", deletedAt: null },
      fields: ["title", "summary"],
      select: {
        id: true,
        slug: true,
        title: true,
        summary: true,
        ageGroup: true,
        level: true,
        durationText: true,
        category: true,
      },
      orderBy: [{ sortOrder: "asc" }, { id: "asc" }],
    },
    teachers: {
      model: "teacher",
      where: {
        isPublic: true,
        isActive: true,
        deletedAt: null,
        verificationNote: { not: null },
        NOT: { verificationNote: "" },
      },
      fields: ["displayName", "bio"],
      select: {
        id: true,
        slug: true,
        displayName: true,
        gender: true,
        bio: true,
        languages: true,
        qualificationsText: true,
      },
      orderBy: [{ displayName: "asc" }, { id: "asc" }],
    },
    faqs: {
      model: "fAQ",
      where: { status: "PUBLISHED", locale: "en" },
      fields: ["question", "answer"],
      select: { id: true, question: true, answer: true, category: true },
      orderBy: [{ sortOrder: "asc" }, { id: "asc" }],
    },
    testimonials: {
      model: "testimonial",
      where: { status: "PUBLISHED", consentRecordedAt: { not: null } },
      fields: ["name", "quote"],
      select: { id: true, name: true, role: true, country: true, quote: true },
      orderBy: [{ createdAt: "desc" }, { id: "asc" }],
    },
    blog: {
      model: "blogPost",
      where: { status: "PUBLISHED", locale: "en" },
      fields: ["title", "excerpt"],
      select: {
        id: true,
        slug: true,
        title: true,
        excerpt: true,
        publishedAt: true,
      },
      orderBy: [{ publishedAt: "desc" }, { id: "asc" }],
    },
    pricing: {
      model: "pricingPlan",
      where: {
        status: "PUBLISHED",
        isPublic: true,
        deletedAt: null,
        pricingPlanPrice_planId: { some: { isPublic: true } },
      },
      fields: ["name"],
      select: {
        id: true,
        name: true,
        billingPeriod: true,
        classesPerWeek: true,
        durationMin: true,
        pricingPlanPrice_planId: {
          where: {
            isPublic: true,
            ...(query.currency ? { currency: query.currency } : {}),
          },
          select: {
            id: true,
            currency: true,
            amountMinor: true,
          },
        },
      },
      orderBy: [{ createdAt: "desc" }, { id: "asc" }],
    },
  };
  const definition = definitions[resource];
  if (!definition) throw new Error("Unsupported public catalog");
  const allowed = {
    courses: ["ageGroup", "level"],
    teachers: ["gender", "language", "courseId"],
    faqs: ["category"],
    blog: ["tag"],
    pricing: ["currency"],
    testimonials: [],
  };
  for (const key of [
    "ageGroup",
    "level",
    "gender",
    "language",
    "courseId",
    "category",
    "tag",
    "currency",
  ])
    if (query[key] !== undefined && !allowed[resource].includes(key))
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "This filter is not available for this catalog.",
      );
  const filters =
    resource === "courses"
      ? {
          ...(query.ageGroup ? { ageGroup: query.ageGroup } : {}),
          ...(query.level ? { level: query.level } : {}),
        }
      : resource === "teachers"
        ? {
            ...(query.gender ? { gender: query.gender } : {}),
            ...(query.language ? { languages: { has: query.language } } : {}),
            ...(query.courseId
              ? {
                  teacherCourse_teacherId: {
                    some: {
                      courseId: query.courseId,
                      course: { status: "PUBLISHED", deletedAt: null },
                    },
                  },
                }
              : {}),
          }
        : resource === "faqs" && query.category
          ? { category: query.category }
          : resource === "blog" && query.tag
            ? { tags: { has: query.tag } }
            : resource === "pricing" && query.currency
              ? {
                  pricingPlanPrice_planId: {
                    some: { isPublic: true, currency: query.currency },
                  },
                }
              : {};
  const repository = db[definition.model];
  const where = {
    ...definition.where,
    ...filters,
    ...(query.q
      ? {
          OR: definition.fields.map((field) => ({
            [field]: { contains: query.q, mode: "insensitive" },
          })),
        }
      : {}),
  };
  const [data, total] = await Promise.all([
    repository.findMany({
      where,
      select: definition.select,
      orderBy: definition.orderBy,
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
    }),
    repository.count({ where }),
  ]);
  return { data, meta: { page: query.page, pageSize: query.pageSize, total } };
}
export async function catalogFilterOptions(resource) {
  const db = database();
  if (resource === "courses") {
    const courses = await db.course.findMany({
      where: { status: "PUBLISHED", deletedAt: null },
      select: { ageGroup: true, level: true },
      distinct: ["ageGroup", "level"],
      take: 200,
    });
    return {
      ageGroup: [...new Set(courses.map((item) => item.ageGroup))].sort(),
      level: [...new Set(courses.map((item) => item.level))].sort(),
    };
  }
  if (resource === "teachers") {
    const teachers = await publicTeachers(),
      courses = await publishedCourses();
    return {
      gender: [...new Set(teachers.map((item) => item.gender))]
        .filter(Boolean)
        .sort(),
      language: [...new Set(teachers.flatMap((item) => item.languages))].sort(),
      courses: courses.map((item) => ({ id: item.id, title: item.title })),
    };
  }
  if (resource === "faqs") {
    const rows = await db.fAQ.findMany({
      where: { status: "PUBLISHED", locale: "en" },
      select: { category: true },
      distinct: ["category"],
      take: 200,
    });
    return {
      category: rows
        .map((item) => item.category)
        .filter((value) => !!value)
        .sort(),
    };
  }
  if (resource === "blog") {
    const posts = await db.blogPost.findMany({
      where: { status: "PUBLISHED", locale: "en" },
      select: { tags: true },
      take: 200,
      orderBy: { publishedAt: "desc" },
    });
    return { tag: [...new Set(posts.flatMap((item) => item.tags))].sort() };
  }
  if (resource === "pricing") {
    const rows = await db.pricingPlanPrice.findMany({
      where: {
        isPublic: true,
        plan: { status: "PUBLISHED", isPublic: true, deletedAt: null },
      },
      select: { currency: true },
      distinct: ["currency"],
      take: 200,
    });
    return { currency: rows.map((item) => item.currency).sort() };
  }
  return {};
}
