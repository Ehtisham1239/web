import { database } from "@/lib/db";
export async function verifyDatabase() {
  await database().$queryRaw`SELECT 1`;
  await database().$queryRaw`SELECT key FROM "RateLimitBucket" LIMIT 0`;
  const roles = await database().role.count();
  const migrations = await database()
    .$queryRaw`SELECT COUNT(*) as count FROM _prisma_migrations WHERE finished_at IS NOT NULL AND rolled_back_at IS NULL`;
  return roles === 5 && Number(migrations[0].count) >= 5;
}
