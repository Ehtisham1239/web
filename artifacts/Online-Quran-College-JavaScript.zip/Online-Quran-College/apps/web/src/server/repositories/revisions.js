import { database } from "@/lib/db";
import { adminSchemas } from "@/lib/validation/admin";
import { courseModulesSchema } from "@/lib/validation/course-modules";
import { sectionsSchema } from "@/lib/validation/content";
import { AppError } from "@/lib/platform/errors";
import { newId } from "@/lib/platform/ids";
const models = {
  courses: "course",
  blog: "blogPost",
  pages: "cMSPage",
};
export function revisionResource(value) {
  return Object.hasOwn(models, value);
}
function repository(tx, resource) {
  return tx[models[resource]];
}
export async function contentRevisions(resource, id) {
  return database().contentRevision.findMany({
    where: {
      entityId: id,
      entityType: {
        in: resource === "courses" ? [resource, "course-modules"] : [resource],
      },
    },
    take: 30,
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    select: {
      id: true,
      entityType: true,
      snapshot: true,
      createdAt: true,
      author: { select: { name: true } },
    },
  });
}
export async function restoreRevision(
  resource,
  id,
  input,
  actorId,
  fullPermission,
) {
  return database().$transaction(async (tx) => {
    const current = await repository(tx, resource).findFirst({
      where: { id, ...(resource === "courses" ? { deletedAt: null } : {}) },
    });
    if (!current) throw new AppError("NOT_FOUND", 404, "Content not found.");
    if (current.version !== input.version)
      throw new AppError(
        "CONFLICT",
        409,
        "Refresh this content before restoring a revision.",
      );
    const revision = await tx.contentRevision.findFirst({
      where: {
        id: input.revisionId,
        entityId: id,
        entityType: {
          in:
            resource === "courses" ? [resource, "course-modules"] : [resource],
        },
      },
    });
    if (
      !revision ||
      !revision.snapshot ||
      typeof revision.snapshot !== "object" ||
      Array.isArray(revision.snapshot)
    )
      throw new AppError(
        "NOT_FOUND",
        404,
        "Revision not found for this content.",
      );
    const snapshot = revision.snapshot;
    const source = {},
      nullable = {};
    const keys = Object.keys(adminSchemas[resource].shape).filter(
      (key) =>
        resource !== "courses" ||
        fullPermission ||
        [
          "title",
          "summary",
          "description",
          "seoTitle",
          "seoDescription",
        ].includes(key),
    );
    if (revision.entityType !== "course-modules")
      for (const key of keys) {
        if (!Object.hasOwn(snapshot, key)) continue;
        if (
          snapshot[key] === null &&
          ["durationText", "seoTitle", "seoDescription"].includes(key)
        )
          nullable[key] = null;
        else
          source[key] =
            key === "description" &&
            snapshot[key] &&
            typeof snapshot[key] === "object" &&
            Object.keys(snapshot[key]).length === 0
              ? { type: "doc", content: [] }
              : snapshot[key];
      }
    const parsed = adminSchemas[resource].partial().safeParse(source);
    if (!parsed.success)
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "This revision cannot be restored with the current content schema.",
      );
    let modules;
    if (revision.entityType === "course-modules") {
      const result = courseModulesSchema.safeParse({
        version: input.version,
        modules: snapshot.modules,
      });
      if (!result.success)
        throw new AppError(
          "VALIDATION_ERROR",
          400,
          "This syllabus revision is incompatible.",
        );
      modules = result.data.modules;
    }
    let sections;
    if (resource === "pages" && Array.isArray(snapshot.pageSection_pageId)) {
      const result = sectionsSchema.safeParse({
        version: input.version,
        sections: snapshot.pageSection_pageId.map((item) => {
          const row = item;
          return {
            section: { type: row.type, data: row.data },
            isVisible: row.isVisible,
          };
        }),
      });
      if (!result.success)
        throw new AppError(
          "VALIDATION_ERROR",
          400,
          "This page-section revision is incompatible.",
        );
      sections = result.data.sections;
    }
    const changed = await repository(tx, resource).updateMany({
      where: { id, version: input.version },
      data: {
        ...parsed.data,
        ...nullable,
        status: "DRAFT",
        publishedAt: null,
        version: { increment: 1 },
        ...(resource === "blog" ? { scheduledAt: null } : {}),
      },
    });
    if (changed.count !== 1)
      throw new AppError(
        "CONFLICT",
        409,
        "This content changed while restoring. Refresh and try again.",
      );
    await tx.setting.deleteMany({
      where: { key: "publication.schedule." + resource + "." + id },
    });
    const before = modules
      ? {
          modules: await tx.courseModule.findMany({
            where: { courseId: id },
            select: { title: true, objectives: true },
            orderBy: { sortOrder: "asc" },
          }),
        }
      : sections
        ? {
            ...current,
            pageSection_pageId: await tx.pageSection.findMany({
              where: { pageId: id },
              orderBy: { sortOrder: "asc" },
            }),
          }
        : current;
    await tx.contentRevision.create({
      data: {
        id: newId(),
        entityType: modules ? "course-modules" : resource,
        entityId: id,
        authorId: actorId,
        snapshot: JSON.parse(JSON.stringify(before)),
      },
    });
    if (modules) {
      await tx.courseModule.deleteMany({ where: { courseId: id } });
      await tx.courseModule.createMany({
        data: modules.map((module, sortOrder) => ({
          id: newId(),
          courseId: id,
          ...module,
          sortOrder,
        })),
      });
    }
    if (sections) {
      await tx.pageSection.deleteMany({ where: { pageId: id } });
      await tx.pageSection.createMany({
        data: sections.map((item, sortOrder) => ({
          id: newId(),
          pageId: id,
          type: item.section.type,
          data: item.section.data,
          isVisible: item.isVisible,
          sortOrder,
        })),
      });
    }
    if (resource === "blog" && "body" in parsed.data) {
      const { renderRichHtml } = await import("@/lib/validation/richtext");
      await tx.blogPost.update({
        where: { id },
        data: { renderedHtml: renderRichHtml(parsed.data.body) },
      });
    }
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "content.revision_restored",
        entityType: resource,
        entityId: id,
        after: {
          revisionId: revision.id,
          status: "DRAFT",
          version: input.version + 1,
        },
      },
    });
    return { id, version: input.version + 1, status: "DRAFT" };
  });
}
