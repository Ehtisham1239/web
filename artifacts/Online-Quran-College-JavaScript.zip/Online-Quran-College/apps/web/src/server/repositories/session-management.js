import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
export async function ownSessions(userId, currentId) {
  const now = new Date();
  const rows = await database().session.findMany({
    where: {
      userId,
      expiresAt: { gt: now },
      lastSeenAt: { gt: new Date(now.getTime() - 30 * 60000) },
    },
    orderBy: { lastSeenAt: "desc" },
    select: { id: true, createdAt: true, lastSeenAt: true, expiresAt: true },
  });
  return rows.map((row) => ({ ...row, isCurrent: row.id === currentId }));
}
export async function revokeOwnSessions(userId, target) {
  return database().$transaction(async (tx) => {
    const result = await tx.session.deleteMany({
      where: { userId, ...(target === "all" ? {} : { id: target }) },
    });
    if (target !== "all" && result.count !== 1)
      throw new AppError("NOT_FOUND", 404, "Session not found.");
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId: userId,
        action:
          target === "all"
            ? "identity.all_sessions_revoked"
            : "identity.session_revoked",
        entityType: "User",
        entityId: userId,
        after: { revokedCount: result.count },
      },
    });
    return { revoked: result.count };
  });
}
