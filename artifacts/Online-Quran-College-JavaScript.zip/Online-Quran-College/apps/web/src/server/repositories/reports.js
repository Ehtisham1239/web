import { database } from "@/lib/db";
import { can } from "@/lib/rbac/policy";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import { encodeCsv } from "@/lib/reports/csv";
export const exportPermissions = {
  trials: "exports:admissions",
  "contact-messages": "exports:admissions",
  students: "exports:academic",
  courses: "exports:content",
};
export async function reportingSummary(role) {
  const db = database();
  const data = {};
  const all = can(role, "reports:read");
  if (all || can(role, "reports:admissions")) {
    const [states, duplicateCount] = await Promise.all([
      db.trialApplication.groupBy({
        by: ["status"],
        where: { deletedAt: null },
        _count: { _all: true },
      }),
      db.trialApplication.count({
        where: { deletedAt: null, duplicateOfId: { not: null } },
      }),
    ]);
    data.admissions = {
      states: states.map((x) => ({ status: x.status, count: x._count._all })),
      duplicateCount,
    };
  }
  if (all || can(role, "reports:academic")) {
    const [activeEnrollments, attendance, upcomingClasses] = await Promise.all([
      db.enrollment.count({ where: { status: "ACTIVE", deletedAt: null } }),
      db.attendance.groupBy({ by: ["status"], _count: { _all: true } }),
      db.classSession.count({
        where: {
          status: "PLANNED",
          startsAtUtc: {
            gte: new Date(),
            lt: new Date(Date.now() + 7 * 86400000),
          },
        },
      }),
    ]);
    data.academic = {
      activeEnrollments,
      upcomingClasses,
      attendance: attendance.map((x) => ({
        status: x.status,
        count: x._count._all,
      })),
    };
  }
  if (all || can(role, "reports:content")) {
    const [courses, pages] = await Promise.all([
      db.course.groupBy({
        by: ["status"],
        where: { deletedAt: null },
        _count: { _all: true },
      }),
      db.cMSPage.groupBy({ by: ["status"], _count: { _all: true } }),
    ]);
    data.content = {
      courses: courses.map((x) => ({ status: x.status, count: x._count._all })),
      pages: pages.map((x) => ({ status: x.status, count: x._count._all })),
    };
  }
  if (all) {
    const invoices = await db.invoice.groupBy({
      by: ["currency", "status"],
      where: { deletedAt: null },
      _sum: { totalMinor: true },
      _count: { _all: true },
    });
    data.finance = {
      invoices: invoices.map((x) => ({
        currency: x.currency,
        status: x.status,
        amountMinor: x._sum.totalMinor ?? 0,
        count: x._count._all,
      })),
    };
  }
  if (!Object.keys(data).length)
    throw new AppError(
      "FORBIDDEN",
      403,
      "Reports are not available for this role.",
    );
  return data;
}
export async function exportRecords(resource, filters, actorId) {
  const db = database();
  const date = {
    ...(filters.from ? { gte: new Date(filters.from + "T00:00:00Z") } : {}),
    ...(filters.to
      ? {
          lt: new Date(
            new Date(filters.to + "T00:00:00Z").getTime() + 86400000,
          ),
        }
      : {}),
  };
  const where = {
    deletedAt: null,
    ...(Object.keys(date).length ? { createdAt: date } : {}),
  };
  return db.$transaction(async (tx) => {
    let rows, columns;
    switch (resource) {
      case "trials":
        columns = [
          "reference",
          "learnerName",
          "guardianName",
          "email",
          "phoneE164",
          "country",
          "timezone",
          "status",
          "createdAt",
        ];
        rows = await tx.trialApplication.findMany({
          where,
          take: 1001,
          orderBy: { createdAt: "desc" },
          select: {
            reference: true,
            learnerName: true,
            guardianName: true,
            email: true,
            phoneE164: true,
            country: true,
            timezone: true,
            status: true,
            createdAt: true,
          },
        });
        break;
      case "contact-messages":
        columns = ["name", "email", "phone", "subject", "status", "createdAt"];
        rows = await tx.contactMessage.findMany({
          where,
          take: 1001,
          orderBy: { createdAt: "desc" },
          select: {
            name: true,
            email: true,
            phone: true,
            subject: true,
            status: true,
            createdAt: true,
          },
        });
        break;
      case "students":
        columns = ["fullName", "ageBand", "country", "timezone", "createdAt"];
        rows = await tx.student.findMany({
          where,
          take: 1001,
          orderBy: { createdAt: "desc" },
          select: {
            fullName: true,
            ageBand: true,
            country: true,
            timezone: true,
            createdAt: true,
          },
        });
        break;
      case "courses":
        columns = [
          "title",
          "slug",
          "summary",
          "ageGroup",
          "level",
          "status",
          "createdAt",
        ];
        rows = await tx.course.findMany({
          where,
          take: 1001,
          orderBy: { createdAt: "desc" },
          select: {
            title: true,
            slug: true,
            summary: true,
            ageGroup: true,
            level: true,
            status: true,
            createdAt: true,
          },
        });
        break;
      default:
        throw new AppError("NOT_FOUND", 404, "Export not available.");
    }
    if (rows.length > 1000)
      throw new AppError(
        "EXPORT_TOO_LARGE",
        422,
        "Choose a narrower date range. Exports are limited to 1,000 records.",
      );
    const csv = encodeCsv(columns, rows);
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "export.downloaded",
        entityType: resource,
        after: { recordCount: rows.length },
      },
    });
    return { csv, count: rows.length };
  });
}
