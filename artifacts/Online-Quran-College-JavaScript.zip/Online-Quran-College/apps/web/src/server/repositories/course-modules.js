import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import { courseModulesSchema } from "@/lib/validation/course-modules";
export function courseModules(id) {
  return database().courseModule.findMany({
    where: { courseId: id },
    orderBy: { sortOrder: "asc" },
    select: { id: true, title: true, objectives: true },
  });
}
export async function replaceCourseModules(id, input, actorId) {
  const data = courseModulesSchema.parse(input);
  return database().$transaction(async (tx) => {
    const course = await tx.course.findFirst({
      where: { id, deletedAt: null },
    });
    if (!course) throw new AppError("NOT_FOUND", 404, "Course not found.");
    if (course.status === "PUBLISHED")
      throw new AppError(
        "CONFLICT",
        409,
        "Return the course to draft before editing its syllabus.",
      );
    const changed = await tx.course.updateMany({
      where: { id, version: data.version, deletedAt: null },
      data: { version: { increment: 1 }, status: "DRAFT" },
    });
    if (!changed.count)
      throw new AppError(
        "CONFLICT",
        409,
        "This course changed. Refresh before saving.",
      );
    const before = await tx.courseModule.findMany({
      where: { courseId: id },
      orderBy: { sortOrder: "asc" },
    });
    await tx.contentRevision.create({
      data: {
        id: newId(),
        entityType: "course-modules",
        entityId: id,
        authorId: actorId,
        snapshot: {
          modules: before.map(({ title, objectives }) => ({
            title,
            objectives,
          })),
        },
      },
    });
    await tx.courseModule.deleteMany({ where: { courseId: id } });
    await tx.courseModule.createMany({
      data: data.modules.map((module, sortOrder) => ({
        id: newId(),
        courseId: id,
        ...module,
        sortOrder,
      })),
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "course.modules_updated",
        entityType: "Course",
        entityId: id,
        after: { moduleCount: data.modules.length },
      },
    });
    return { id, version: data.version + 1 };
  });
}
