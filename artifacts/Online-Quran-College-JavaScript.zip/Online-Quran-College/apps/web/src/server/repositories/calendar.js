import { DateTime } from "luxon";
import { database } from "@/lib/db";
import { AppError } from "@/lib/platform/errors";
import { calendarSchema } from "@/lib/validation/calendar";
export function calendarRange(input) {
  const from = input.from ?? DateTime.now().setZone(input.timezone).toISODate();
  const start = DateTime.fromISO(from, { zone: input.timezone }).startOf("day");
  if (!start.isValid || start.toISODate() !== from)
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "Choose a valid calendar date and time zone.",
    );
  const end = start.plus({ days: Number(input.days) });
  return {
    from,
    startsAtUtc: start.toUTC().toJSDate(),
    endsAtUtc: end.toUTC().toJSDate(),
    dates: Array.from({ length: Number(input.days) }, (_, day) =>
      start.plus({ days: day }).toISODate(),
    ),
  };
}
export async function classCalendar(raw) {
  const parsed = calendarSchema.safeParse(raw);
  if (!parsed.success)
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "Choose a valid date, time zone and calendar filter.",
    );
  const input = parsed.data,
    range = calendarRange(input);
  const [records, teachers] = await Promise.all([
    database().classSession.findMany({
      where: {
        startsAtUtc: { lt: range.endsAtUtc },
        endsAtUtc: { gt: range.startsAtUtc },
        ...(input.teacherId ? { teacherId: input.teacherId } : {}),
      },
      take: 501,
      orderBy: [{ startsAtUtc: "asc" }, { id: "asc" }],
      select: {
        id: true,
        kind: true,
        status: true,
        startsAtUtc: true,
        endsAtUtc: true,
        teacher: {
          select: {
            displayName: true,
            teacherAvailability_teacherId: {
              select: { timezone: true },
              take: 1,
            },
          },
        },
        student: { select: { fullName: true, timezone: true } },
        trial: { select: { learnerName: true, timezone: true } },
        schedule: {
          select: {
            enrollment: { select: { course: { select: { title: true } } } },
          },
        },
      },
    }),
    database().teacher.findMany({
      where: { deletedAt: null },
      take: 200,
      orderBy: [{ displayName: "asc" }, { id: "asc" }],
      select: { id: true, displayName: true },
    }),
  ]);
  return {
    from: range.from,
    timezone: input.timezone,
    days: input.days,
    teacherId: input.teacherId ?? "",
    dates: range.dates,
    truncated: records.length > 500,
    teachers,
    sessions: records.slice(0, 500).map((record) => ({
      id: record.id,
      kind: record.kind,
      status: record.status,
      startsAtUtc: record.startsAtUtc.toISOString(),
      endsAtUtc: record.endsAtUtc.toISOString(),
      teacher: {
        name: record.teacher.displayName,
        timezone:
          record.teacher.teacherAvailability_teacherId[0]?.timezone ?? "UTC",
      },
      learner: record.student
        ? { name: record.student.fullName, timezone: record.student.timezone }
        : record.trial
          ? {
              name: record.trial.learnerName,
              timezone: record.trial.timezone,
            }
          : null,
      course: record.schedule?.enrollment.course.title ?? "Trial class",
    })),
  };
}
