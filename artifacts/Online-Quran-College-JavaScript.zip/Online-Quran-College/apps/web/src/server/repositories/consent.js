import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import { consentSchema, storedConsentSchema } from "@/lib/validation/consent";
export async function activeConsent() {
  const current = await database().setting.findUnique({
    where: { key: "legal.activeConsentVersion" },
  });
  if (!current || typeof current.value !== "string") return null;
  const row = await database().setting.findUnique({
    where: { key: "consent.version." + current.value },
  });
  const parsed = storedConsentSchema.safeParse(row?.value);
  return parsed.success && parsed.data.version === current.value
    ? parsed.data
    : null;
}
export async function publishConsent(input, actorId) {
  const { ownerApproved: _approved, ...data } = consentSchema.parse(input);
  void _approved;
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(713096)`;
    const key = "consent.version." + data.version;
    if (await tx.setting.findUnique({ where: { key } }))
      throw new AppError(
        "CONFLICT",
        409,
        "This consent version already exists. Use a new version for changed wording.",
      );
    await tx.setting.create({
      data: { id: newId(), key, value: data, isPublic: false },
    });
    await tx.setting.upsert({
      where: { key: "legal.activeConsentVersion" },
      create: {
        id: newId(),
        key: "legal.activeConsentVersion",
        value: data.version,
        isPublic: false,
      },
      update: { value: data.version },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "consent.approved",
        entityType: "ConsentVersion",
        entityId: data.version,
        after: { version: data.version },
      },
    });
    return data;
  });
}
export async function verifyConsentVersion(version) {
  const current = await activeConsent();
  if (current && current.version === version) return;
  if (
    !current &&
    process.env.NODE_ENV !== "production" &&
    version === "v1-draft"
  )
    return;
  throw new AppError(
    "CONSENT_VERSION_CHANGED",
    409,
    "The privacy consent notice has changed or is awaiting approval. Refresh before submitting.",
  );
}
