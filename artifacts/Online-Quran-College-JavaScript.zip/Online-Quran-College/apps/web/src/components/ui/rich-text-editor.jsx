"use client";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
export function RichTextEditor({ name, label, onChange, initial }) {
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: { levels: [2, 3] },
        link: false,
        underline: false,
      }),
    ],
    content: initial ?? "",
    immediatelyRender: false,
    editorProps: {
      attributes: {
        role: "textbox",
        "aria-label": label,
        "aria-multiline": "true",
        class: "rich-editor-body",
      },
    },
    onUpdate: ({ editor }) => onChange?.(editor.getJSON()),
  });
  return (
    <div className="field">
      <span id={name + "-label"}>{label}</span>
      <div className="rich-editor">
        <div role="toolbar" aria-label="Formatting" className="toolbar">
          {editor && (
            <>
              <button
                type="button"
                className="button button-secondary"
                aria-pressed={editor.isActive("bold")}
                onClick={() => editor.chain().focus().toggleBold().run()}
              >
                Bold
              </button>
              <button
                type="button"
                className="button button-secondary"
                aria-pressed={editor.isActive("italic")}
                onClick={() => editor.chain().focus().toggleItalic().run()}
              >
                Italic
              </button>
              <button
                type="button"
                className="button button-secondary"
                onClick={() =>
                  editor.chain().focus().toggleHeading({ level: 2 }).run()
                }
              >
                Heading
              </button>
              <button
                type="button"
                className="button button-secondary"
                onClick={() => editor.chain().focus().toggleBulletList().run()}
              >
                List
              </button>
              <button
                type="button"
                className="button button-secondary"
                disabled={!editor.can().undo()}
                onClick={() => editor.chain().focus().undo().run()}
              >
                Undo
              </button>
            </>
          )}
        </div>
        <EditorContent editor={editor} />
      </div>
    </div>
  );
}
