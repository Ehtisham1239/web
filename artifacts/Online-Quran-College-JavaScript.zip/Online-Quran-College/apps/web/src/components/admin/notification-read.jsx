"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function NotificationRead({ id }) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [pending, startTransition] = useTransition();
  const router = useRouter();
  return (
    <div>
      <button
        className="button button-secondary"
        disabled={busy || pending}
        onClick={async () => {
          setBusy(true);
          setError("");
          try {
            const response = await fetch(
              `/api/v1/admin/notifications/${id}/read`,
              {
                method: "POST",
                headers: { "X-CSRF-Token": await getCsrfToken() },
              },
            );
            if (!response.ok) throw new Error("Unable to update notification.");
            startTransition(() => router.refresh());
          } catch (error) {
            setError(
              error instanceof Error ? error.message : "Unable to update.",
            );
          } finally {
            setBusy(false);
          }
        }}
      >
        Mark as read
      </button>
      {error && <p role="alert">{error}</p>}
    </div>
  );
}
