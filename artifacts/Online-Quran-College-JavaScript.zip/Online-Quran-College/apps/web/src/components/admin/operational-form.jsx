"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
import { majorToMinor } from "@/lib/platform/money";
export function OperationalForm({ resource, choices, timezone }) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const title = {
    schedules: "Create a weekly schedule",
    invoices: "Issue an invoice",
    payments: "Record a received payment",
    progress: "Record learner progress",
  }[resource];
  return (
    <details className="card" style={{ marginBlock: 24 }}>
      <summary>{title}</summary>
      {choices.length ? (
        <form
          className="form"
          style={{ marginTop: 24 }}
          onSubmit={async (event) => {
            event.preventDefault();
            const form = event.currentTarget,
              data = new FormData(form);
            setBusy(true);
            setError("");
            try {
              const id = String(data.get("selection"));
              let body = { enrollmentId: id };
              if (resource === "schedules") {
                const [hour, minute] = String(data.get("time"))
                  .split(":")
                  .map(Number);
                body = {
                  ...body,
                  weekday: Number(data.get("weekday")),
                  startMinute: hour * 60 + minute,
                  durationMin: Number(data.get("durationMin")),
                  timezone: data.get("timezone"),
                  from: data.get("from"),
                  to: data.get("to"),
                };
              } else if (resource === "invoices") {
                const currency = String(data.get("currency"));
                body = {
                  ...body,
                  currency,
                  totalMinor: majorToMinor(
                    String(data.get("amount")),
                    currency,
                  ),
                  dueAt: String(data.get("dueAt")) + "T23:59:00.000Z",
                };
              } else if (resource === "payments") {
                const currency = choices.find(
                  (choice) => choice.id === id,
                )?.currency;
                if (!currency) throw new Error("Choose an invoice.");
                body = {
                  invoiceId: id,
                  amountMinor: majorToMinor(
                    String(data.get("amount")),
                    currency,
                  ),
                  method: data.get("method"),
                  reference: data.get("reference") || undefined,
                  receivedAt: String(data.get("receivedAt")) + "T12:00:00.000Z",
                };
              } else
                body = {
                  ...body,
                  summary: data.get("summary"),
                  lessonRef: data.get("lessonRef") || undefined,
                };
              const response = await fetch("/api/v1/admin/" + resource, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "X-CSRF-Token": await getCsrfToken(),
                },
                body: JSON.stringify(body),
              });
              const result = await response.json();
              if (!response.ok)
                throw new Error(result.error?.message ?? "Unable to save.");
              form.reset();
              startTransition(() => router.refresh());
            } catch (error) {
              setError(
                error instanceof Error ? error.message : "Unable to save.",
              );
            } finally {
              setBusy(false);
            }
          }}
        >
          <div className="field">
            <label htmlFor={resource + "-selection"}>
              {resource === "payments" ? "Unpaid invoice" : "Active enrollment"}
            </label>
            <select id={resource + "-selection"} name="selection" required>
              {choices.map((choice) => (
                <option key={choice.id} value={choice.id}>
                  {choice.label}
                </option>
              ))}
            </select>
          </div>
          {resource === "schedules" ? (
            <>
              <label>
                Weekday{" "}
                <select name="weekday">
                  {[
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                    "Sunday",
                  ].map((day, index) => (
                    <option key={day} value={index + 1}>
                      {day}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Local start time <input name="time" type="time" required />
              </label>
              <label>
                Class duration in minutes{" "}
                <input
                  name="durationMin"
                  type="number"
                  min={1}
                  max={240}
                  required
                />
              </label>
              <label>
                Time zone{" "}
                <input name="timezone" defaultValue={timezone} required />
              </label>
              <label>
                First date <input name="from" type="date" required />
              </label>
              <label>
                Last date <input name="to" type="date" required />
              </label>
              <p>
                Classes retain their local time through daylight-saving changes.
                Conflicting or invalid dates are rejected.
              </p>
            </>
          ) : resource === "invoices" ? (
            <>
              <div className="field">
                <label htmlFor="invoice-currency">Currency</label>
                <select
                  id="invoice-currency"
                  name="currency"
                  required
                  defaultValue=""
                >
                  <option value="">Choose a currency</option>
                  {Intl.supportedValuesOf("currency").map((currency) => (
                    <option key={currency} value={currency}>
                      {currency}
                    </option>
                  ))}
                </select>
              </div>
              <label>
                Invoice amount{" "}
                <input
                  name="amount"
                  type="number"
                  min="0"
                  step="any"
                  required
                />
              </label>
              <label>
                Due date <input name="dueAt" type="date" required />
              </label>
            </>
          ) : resource === "payments" ? (
            <>
              <label>
                Received amount (invoice currency){" "}
                <input
                  name="amount"
                  type="number"
                  min="0"
                  step="any"
                  required
                />
              </label>
              <div className="field">
                <label htmlFor="payment-method">Payment method</label>
                <select id="payment-method" name="method">
                  {["BANK", "CARD_EXTERNAL", "CASH", "OTHER"].map((method) => (
                    <option key={method}>{method}</option>
                  ))}
                </select>
              </div>
              <label>
                Payment reference <input name="reference" maxLength={150} />
              </label>
              <label>
                Received date <input name="receivedAt" type="date" required />
              </label>
              <p>
                This records a payment received outside this platform. It does
                not charge a card or initiate a transfer.
              </p>
            </>
          ) : (
            <>
              <label>
                Progress summary{" "}
                <textarea name="summary" required maxLength={2000} />
              </label>
              <label>
                Lesson reference <input name="lessonRef" maxLength={200} />
              </label>
            </>
          )}
          {error && (
            <p role="alert" className="error-summary">
              {error}
            </p>
          )}
          <button className="button button-primary" disabled={busy || pending}>
            {busy ? "Saving…" : title}
          </button>
        </form>
      ) : (
        <p>
          {resource === "payments"
            ? "No unpaid invoices."
            : "No active enrollments. Enroll a learner before continuing."}
        </p>
      )}
    </details>
  );
}
