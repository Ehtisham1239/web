"use client";
import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
export function AcceptInvite() {
  const token = useRef("");
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const router = useRouter();
  useEffect(() => {
    if (!token.current)
      token.current =
        new URLSearchParams(window.location.hash.slice(1)).get("token") ?? "";
    window.history.replaceState(null, "", window.location.pathname);
  }, []);
  return (
    <form
      className="card form"
      onSubmit={async (event) => {
        event.preventDefault();
        setBusy(true);
        setError("");
        const data = new FormData(event.currentTarget);
        if (data.get("password") !== data.get("confirmation")) {
          setError("Passwords must match.");
          setBusy(false);
          return;
        }
        try {
          const response = await fetch("/api/v1/auth/invite", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              token: token.current,
              password: data.get("password"),
            }),
          });
          const body = await response.json();
          if (!response.ok)
            throw new Error(
              body.error?.message ?? "Unable to accept invitation.",
            );
          router.replace("/admin/setup#token=" + body.data.setupToken);
        } catch (error) {
          setError(
            error instanceof Error
              ? error.message
              : "Unable to accept invitation.",
          );
          setBusy(false);
        }
      }}
    >
      <p>
        Create your own passphrase, then enroll your authenticator. The account
        remains inactive until MFA enrollment is complete.
      </p>
      <label>
        Passphrase{" "}
        <input
          name="password"
          type="password"
          autoComplete="new-password"
          minLength={12}
          maxLength={128}
          required
        />
      </label>
      <label>
        Confirm passphrase{" "}
        <input
          name="confirmation"
          type="password"
          autoComplete="new-password"
          required
        />
      </label>
      {error && <p role="alert">{error}</p>}
      <button className="button button-primary" disabled={busy}>
        {busy ? "Continuing…" : "Continue to MFA setup"}
      </button>
    </form>
  );
}
