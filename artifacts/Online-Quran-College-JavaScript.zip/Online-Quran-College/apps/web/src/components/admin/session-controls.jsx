"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function SessionControls({ name }) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const router = useRouter();
  async function logout() {
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/v1/auth/logout", {
        method: "POST",
        headers: { "X-CSRF-Token": await getCsrfToken() },
      });
      if (!response.ok) throw new Error("Unable to sign out. Try again.");
      sessionStorage.removeItem("oqc-csrf");
      router.replace("/admin/login");
      router.refresh();
    } catch (error) {
      setError(error instanceof Error ? error.message : "Unable to sign out.");
      setBusy(false);
    }
  }
  return (
    <div>
      <p>{name}</p>
      <button
        className="button button-secondary"
        disabled={busy}
        onClick={logout}
      >
        {busy ? "Signing out…" : "Sign out"}
      </button>
      {error && <p role="alert">{error}</p>}
    </div>
  );
}
