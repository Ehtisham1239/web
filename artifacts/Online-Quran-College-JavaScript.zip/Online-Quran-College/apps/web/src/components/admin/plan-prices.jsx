"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
import { majorToMinor } from "@/lib/platform/money";
function digits(currency) {
  return (
    new Intl.NumberFormat("en", {
      style: "currency",
      currency,
    }).resolvedOptions().maximumFractionDigits ?? 2
  );
}
export function PlanPrices({ id, version, status, initial }) {
  const [items, setItems] = useState(
    initial.map((row) => ({
      ...row,
      amount: (row.amountMinor / 10 ** digits(row.currency)).toFixed(
        digits(row.currency),
      ),
    })),
  );
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  function update(index, data) {
    setItems((current) =>
      current.map((item, i) => (i === index ? { ...item, ...data } : item)),
    );
  }
  return (
    <section className="card" style={{ marginBlock: 24 }}>
      <h2>Plan prices</h2>
      {status === "PUBLISHED" ? (
        <p>Return the plan to draft before changing its prices.</p>
      ) : (
        <form
          className="form"
          onSubmit={async (event) => {
            event.preventDefault();
            setBusy(true);
            setError("");
            try {
              const prices = items.map(({ currency, amount, isPublic }) => ({
                currency,
                amountMinor: majorToMinor(amount, currency, true),
                isPublic,
              }));
              const response = await fetch(
                `/api/v1/admin/pricing-plans/${id}/prices`,
                {
                  method: "PUT",
                  headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-Token": await getCsrfToken(),
                  },
                  body: JSON.stringify({ version, prices }),
                },
              );
              const payload = await response.json();
              if (!response.ok)
                throw new Error(
                  payload.error?.message ?? "Unable to save prices.",
                );
              startTransition(() => router.refresh());
            } catch (error) {
              setError(
                error instanceof Error
                  ? error.message
                  : "Unable to save prices.",
              );
            } finally {
              setBusy(false);
            }
          }}
        >
          <p>
            Enter an owner-approved fee for each currency. Visible prices appear
            after the plan is approved, published and made public.
          </p>
          <fieldset disabled={busy || pending}>
            <legend>Fees by currency</legend>
            {!items.length && <p>No fees entered.</p>}
            {items.map((item, index) => (
              <div className="card form" key={item.id}>
                <div className="field">
                  <label htmlFor={"price-currency-" + item.id}>
                    Price {index + 1} currency
                  </label>
                  <select
                    id={"price-currency-" + item.id}
                    required
                    value={item.currency}
                    onChange={(event) =>
                      update(index, { currency: event.target.value })
                    }
                  >
                    <option value="">Choose a currency</option>
                    {Intl.supportedValuesOf("currency").map((code) => (
                      <option key={code} value={code}>
                        {code}
                      </option>
                    ))}
                  </select>
                </div>
                <label className="field">
                  <span>Price {index + 1} amount</span>
                  <input
                    required
                    inputMode="decimal"
                    pattern="[0-9]+([.][0-9]+)?"
                    maxLength={20}
                    value={item.amount}
                    onChange={(event) =>
                      update(index, { amount: event.target.value })
                    }
                  />
                </label>
                <label>
                  <input
                    type="checkbox"
                    checked={item.isPublic}
                    onChange={(event) =>
                      update(index, { isPublic: event.target.checked })
                    }
                  />{" "}
                  Visible when published
                </label>
                <button
                  type="button"
                  className="button button-secondary"
                  aria-label={`Remove price ${index + 1}`}
                  onClick={() =>
                    setItems((current) => current.filter((_, i) => i !== index))
                  }
                >
                  Remove price
                </button>
              </div>
            ))}
            <button
              type="button"
              className="button button-secondary"
              disabled={items.length >= 20}
              onClick={() =>
                setItems((current) => [
                  ...current,
                  {
                    id: crypto.randomUUID(),
                    currency: "",
                    amount: "",
                    isPublic: false,
                  },
                ])
              }
            >
              Add price
            </button>
          </fieldset>
          {error && <p role="alert">{error}</p>}
          <button className="button button-primary" disabled={busy || pending}>
            {busy ? "Saving…" : "Save prices"}
          </button>
        </form>
      )}
    </section>
  );
}
