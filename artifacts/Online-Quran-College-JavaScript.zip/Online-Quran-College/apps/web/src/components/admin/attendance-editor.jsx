"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { DateTime } from "luxon";
import { getCsrfToken } from "@/lib/auth/client";
export function AttendanceEditor({ workspace, editable }) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  function time(zone) {
    return `${DateTime.fromISO(workspace.startsAtUtc).setZone(zone).toFormat("dd LLL yyyy, HH:mm")}–${DateTime.fromISO(workspace.endsAtUtc).setZone(zone).toFormat("HH:mm")} (${zone})`;
  }
  return (
    <section className="card" style={{ marginBlock: 24 }}>
      <h2>Class attendance</h2>
      <p>
        {workspace.student.fullName} · {workspace.course}
      </p>
      <p>Learner time: {time(workspace.student.timezone)}</p>
      <p>
        Teacher: {workspace.teacher.displayName} ·{" "}
        {time(workspace.teacher.timezone)}
      </p>
      {workspace.cancelled ? (
        <p>Attendance cannot be recorded for a cancelled class.</p>
      ) : editable ? (
        <form
          className="form"
          onSubmit={async (event) => {
            event.preventDefault();
            const data = new FormData(event.currentTarget);
            setBusy(true);
            setError("");
            try {
              const response = await fetch("/api/v1/admin/attendance", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "X-CSRF-Token": await getCsrfToken(),
                },
                body: JSON.stringify({
                  sessionId: workspace.sessionId,
                  enrollmentId: workspace.enrollmentId,
                  sessionVersion: workspace.sessionVersion,
                  expectedUpdatedAt: workspace.attendance?.updatedAt ?? null,
                  status: data.get("status"),
                  note: data.get("note"),
                }),
              });
              const payload = await response.json();
              if (!response.ok)
                throw new Error(
                  payload.error?.message ?? "Unable to save attendance.",
                );
              startTransition(() => router.refresh());
            } catch (error) {
              setError(
                error instanceof Error
                  ? error.message
                  : "Unable to save attendance.",
              );
            } finally {
              setBusy(false);
            }
          }}
        >
          <fieldset disabled={busy || pending}>
            <legend>Record attendance</legend>
            <div className="field">
              <label htmlFor="attendance-status">Attendance status</label>
              <select
                id="attendance-status"
                name="status"
                required
                defaultValue={workspace.attendance?.status ?? ""}
              >
                <option value="" disabled>
                  Choose a status
                </option>
                <option value="PRESENT">Present</option>
                <option value="ABSENT">Absent</option>
                <option value="LATE">Late</option>
                <option value="EXCUSED">Excused</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="attendance-note">Private attendance note</label>
              <textarea
                id="attendance-note"
                name="note"
                maxLength={1000}
                defaultValue={workspace.attendance?.note ?? ""}
              />
            </div>
            <button className="button" type="submit">
              {busy || pending ? "Saving…" : "Save attendance"}
            </button>
          </fieldset>
          {error && <p role="alert">{error}</p>}
        </form>
      ) : (
        <>
          <p>
            Status:{" "}
            {workspace.attendance?.status.toLowerCase() ?? "Not recorded"}
          </p>
          {workspace.attendance?.note && <p>{workspace.attendance.note}</p>}
        </>
      )}
    </section>
  );
}
