"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { RichTextEditor } from "@/components/ui/rich-text-editor";
import { getCsrfToken } from "@/lib/auth/client";
import { SectionFields } from "@/components/admin/section-fields";
export function PageEditor({ id, version, status, sections }) {
  const [items, setItems] = useState(sections),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const router = useRouter();
  const [newType, setNewType] = useState("HERO");
  const [pending, startTransition] = useTransition();
  function update(index, data) {
    setItems((current) =>
      current.map((item, i) => (i === index ? { ...item, ...data } : item)),
    );
  }
  async function save() {
    setBusy(true);
    setError("");
    try {
      const response = await fetch(`/api/v1/admin/pages/${id}/sections`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": await getCsrfToken(),
        },
        body: JSON.stringify({
          version,
          sections: items.map((item) => ({
            section: { type: item.type, data: item.data },
            isVisible: item.isVisible,
          })),
        }),
      });
      const payload = await response.json();
      if (!response.ok)
        throw new Error(payload.error?.message ?? "Unable to save.");
      startTransition(() => router.refresh());
    } catch (error) {
      setError(error instanceof Error ? error.message : "Unable to save.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="card" style={{ marginBlock: 24 }}>
      <h2>Page sections</h2>
      {status === "PUBLISHED" ? (
        <p>Return the page to draft before editing its sections.</p>
      ) : (
        <>
          <p>Sections appear publicly after approval and publication.</p>
          {items.map((item, index) => (
            <div className="card form" key={item.id}>
              <h3>
                Section {index + 1}: {item.type.replaceAll("_", " ")}
              </h3>
              <label>
                <input
                  type="checkbox"
                  checked={item.isVisible}
                  onChange={(event) =>
                    update(index, { isVisible: event.target.checked })
                  }
                />{" "}
                Visible when published
              </label>
              {item.type === "RICH_TEXT" ? (
                <RichTextEditor
                  name={item.id}
                  label="Page text"
                  initial={
                    item.data.document ??
                    (typeof item.data.text === "string"
                      ? {
                          type: "doc",
                          content: [
                            {
                              type: "paragraph",
                              content: [{ type: "text", text: item.data.text }],
                            },
                          ],
                        }
                      : undefined)
                  }
                  onChange={(document) => update(index, { data: { document } })}
                />
              ) : (
                <SectionFields
                  type={item.type}
                  data={item.data}
                  index={index}
                  onChange={(data) => update(index, { data })}
                />
              )}
              <div className="toolbar">
                <button
                  className="button button-secondary"
                  type="button"
                  disabled={index === 0}
                  onClick={() =>
                    setItems((current) => {
                      const next = [...current];
                      [next[index - 1], next[index]] = [
                        next[index],
                        next[index - 1],
                      ];
                      return next;
                    })
                  }
                >
                  Move up
                </button>
                <button
                  className="button button-secondary"
                  type="button"
                  onClick={() =>
                    setItems((current) => current.filter((_, i) => i !== index))
                  }
                >
                  Remove section
                </button>
              </div>
            </div>
          ))}
          <div className="toolbar">
            <div className="field">
              <label htmlFor="new-section-type">New page section</label>
              <select
                id="new-section-type"
                value={newType}
                onChange={(event) => setNewType(event.target.value)}
              >
                {[
                  "HERO",
                  "FEATURES",
                  "CTA",
                  "COURSES_GRID",
                  "TEACHERS",
                  "PRICING_TEASER",
                  "TESTIMONIALS",
                  "FAQ",
                ].map((type) => (
                  <option key={type} value={type}>
                    {type.replaceAll("_", " ")}
                  </option>
                ))}
              </select>
            </div>
            <button
              className="button button-secondary"
              type="button"
              disabled={items.length >= 30}
              onClick={() =>
                setItems((current) => [
                  ...current,
                  {
                    id: crypto.randomUUID(),
                    type: newType,
                    data:
                      newType === "HERO"
                        ? {
                            title: "",
                            body: "",
                            ctaLabel: "",
                            ctaHref: "/free-trial",
                          }
                        : newType === "CTA"
                          ? {
                              title: "",
                              body: "",
                              label: "",
                              href: "/free-trial",
                            }
                          : newType === "FEATURES"
                            ? { items: [] }
                            : { title: "" },
                    isVisible: true,
                  },
                ])
              }
            >
              Add selected section
            </button>
            <button
              className="button button-secondary"
              type="button"
              disabled={items.length >= 30}
              onClick={() =>
                setItems((current) => [
                  ...current,
                  {
                    id: crypto.randomUUID(),
                    type: "RICH_TEXT",
                    data: {
                      document: {
                        type: "doc",
                        content: [{ type: "paragraph" }],
                      },
                    },
                    isVisible: true,
                  },
                ])
              }
            >
              Add text section
            </button>
            <button
              className="button button-primary"
              type="button"
              onClick={() => void save()}
              disabled={busy || pending}
            >
              {busy ? "Saving…" : "Save sections"}
            </button>
          </div>
        </>
      )}
      {error && (
        <p className="error-summary" role="alert">
          {error}
        </p>
      )}
    </section>
  );
}
