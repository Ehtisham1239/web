"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
const time = (minute) =>
  String(Math.floor(minute / 60)).padStart(2, "0") +
  ":" +
  String(minute % 60).padStart(2, "0");
const minutes = (value) => {
  const [h, m] = value.split(":").map(Number);
  return h * 60 + m;
};
export function TeacherAvailability({ id, version, initial }) {
  const [slots, setSlots] = useState(initial),
    [zone, setZone] = useState(initial[0]?.timezone ?? ""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [pending, startTransition] = useTransition();
  const router = useRouter();
  return (
    <section className="card form" style={{ marginBlock: 24 }}>
      <h2>Weekly teacher availability</h2>
      <label>
        Teacher time zone{" "}
        <input
          value={zone}
          onChange={(event) => setZone(event.target.value)}
          placeholder="Select the teacher’s IANA time zone"
        />
      </label>
      {slots.map((slot, index) => (
        <div className="form-grid" key={index}>
          <label>
            Weekday{" "}
            <select
              value={slot.weekday}
              onChange={(event) =>
                setSlots((current) =>
                  current.map((item, i) =>
                    i === index
                      ? { ...item, weekday: Number(event.target.value) }
                      : item,
                  ),
                )
              }
            >
              {[
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday",
                "Sunday",
              ].map((day, i) => (
                <option value={i + 1} key={day}>
                  {day}
                </option>
              ))}
            </select>
          </label>
          <label>
            From{" "}
            <input
              type="time"
              value={time(slot.startMinute)}
              onChange={(event) =>
                setSlots((current) =>
                  current.map((item, i) =>
                    i === index
                      ? { ...item, startMinute: minutes(event.target.value) }
                      : item,
                  ),
                )
              }
            />
          </label>
          <label>
            Through{" "}
            <input
              type="text"
              inputMode="numeric"
              value={time(slot.endMinute)}
              onChange={(event) =>
                setSlots((current) =>
                  current.map((item, i) =>
                    i === index
                      ? { ...item, endMinute: minutes(event.target.value) }
                      : item,
                  ),
                )
              }
            />
          </label>
          <button
            className="button button-secondary"
            type="button"
            onClick={() =>
              setSlots((current) => current.filter((_, i) => i !== index))
            }
          >
            Remove slot
          </button>
        </div>
      ))}
      <div className="toolbar">
        <button
          className="button button-secondary"
          disabled={slots.length >= 21}
          onClick={() =>
            setSlots((current) => [
              ...current,
              { weekday: 1, startMinute: 0, endMinute: 0, timezone: zone },
            ])
          }
        >
          Add availability slot
        </button>
        <button
          className="button button-primary"
          disabled={busy || pending}
          onClick={async () => {
            setBusy(true);
            setError("");
            try {
              const response = await fetch(
                `/api/v1/admin/teachers/${id}/availability`,
                {
                  method: "PUT",
                  headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-Token": await getCsrfToken(),
                  },
                  body: JSON.stringify({
                    version,
                    slots: slots.map((slot) => ({ ...slot, timezone: zone })),
                  }),
                },
              );
              const result = await response.json();
              if (!response.ok)
                throw new Error(result.error?.message ?? "Unable to save.");
              startTransition(() => router.refresh());
            } catch (error) {
              setError(
                error instanceof Error ? error.message : "Unable to save.",
              );
            } finally {
              setBusy(false);
            }
          }}
        >
          Save availability
        </button>
      </div>
      <p>
        Existing booked classes remain scheduled; staff must review those
        bookings when availability changes.
      </p>
      {error && (
        <p className="error-summary" role="alert">
          {error}
        </p>
      )}
    </section>
  );
}
