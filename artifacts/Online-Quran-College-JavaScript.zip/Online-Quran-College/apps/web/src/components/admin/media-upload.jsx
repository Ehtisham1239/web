"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function MediaUpload() {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  return (
    <form
      className="card form"
      style={{ marginBlock: 24 }}
      onSubmit={async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        setBusy(true);
        setError("");
        try {
          const response = await fetch("/api/v1/admin/media", {
            method: "POST",
            headers: { "X-CSRF-Token": await getCsrfToken() },
            body: new FormData(form),
          });
          const body = await response.json();
          if (!response.ok)
            throw new Error(body.error?.message ?? "Unable to upload.");
          form.reset();
          startTransition(() => router.refresh());
        } catch (error) {
          setError(
            error instanceof Error ? error.message : "Unable to upload.",
          );
        } finally {
          setBusy(false);
        }
      }}
    >
      <h2>Upload a content image</h2>
      <p>
        JPEG, PNG or WebP, up to 4 MB. Add alternative text for readers using
        assistive technology.
      </p>
      <div className="field">
        <label htmlFor="media-file">Image file</label>
        <input
          id="media-file"
          name="file"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          required
        />
      </div>
      <div className="field">
        <label htmlFor="media-alt">Alternative text</label>
        <input
          id="media-alt"
          name="altText"
          maxLength={300}
          minLength={2}
          required
        />
      </div>
      {error && (
        <p className="error-summary" role="alert">
          {error}
        </p>
      )}
      <button className="button button-primary" disabled={busy || pending}>
        {busy ? "Uploading…" : "Upload image"}
      </button>
    </form>
  );
}
