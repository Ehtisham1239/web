"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
import { roles, canAssignRole } from "@/lib/rbac/policy";
export function StaffUsers({ users, actorRole }) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [invite, setInvite] = useState("");
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  async function send(url, method, body) {
    setBusy(true);
    setError("");
    try {
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": await getCsrfToken(),
        },
        body: JSON.stringify(body),
      });
      const result = await response.json();
      if (!response.ok)
        throw new Error(result.error?.message ?? "Unable to save.");
      if (result.data?.resetToken)
        setInvite(
          window.location.origin +
            "/admin/reset#token=" +
            result.data.resetToken,
        );
      if (result.data?.inviteToken)
        setInvite(
          window.location.origin +
            "/admin/invite#token=" +
            result.data.inviteToken,
        );
      startTransition(() => router.refresh());
    } catch (error) {
      setError(error instanceof Error ? error.message : "Unable to save.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      {error && (
        <p className="error-summary" role="alert">
          {error}
        </p>
      )}
      <form
        className="card form"
        onSubmit={(event) => {
          event.preventDefault();
          const data = new FormData(event.currentTarget);
          void send("/api/v1/admin/users", "POST", {
            name: data.get("name"),
            email: data.get("email"),
            role: data.get("role"),
          });
        }}
      >
        <h2>Invite a staff member</h2>
        <p>
          Recent password/MFA confirmation is required. Invitation links expire
          after 48 hours and are shown only once.
        </p>
        <div className="field">
          <label htmlFor="invite-name">Name</label>
          <input id="invite-name" name="name" required />
        </div>
        <div className="field">
          <label htmlFor="invite-email">Staff email</label>
          <input id="invite-email" name="email" type="email" required />
        </div>
        <div className="field">
          <label htmlFor="invite-role">Role</label>
          <select id="invite-role" name="role">
            {roles
              .filter((role) => canAssignRole(actorRole, role))
              .map((role) => (
                <option key={role}>{role}</option>
              ))}
          </select>
        </div>
        <button className="button button-primary" disabled={busy || pending}>
          Create invitation
        </button>
        {invite && (
          <div role="status">
            <p>
              Deliver this one-time link through an approved secure channel. No
              invitation email has been sent.
            </p>
            <textarea
              readOnly
              aria-label="One-time invitation link"
              value={invite}
            />
            <button
              className="button button-secondary"
              type="button"
              onClick={() => setInvite("")}
            >
              Clear link
            </button>
          </div>
        )}
      </form>
      <section>
        <h2>Staff accounts</h2>
        {users.map((user) => (
          <form
            className="card form"
            style={{ marginBlock: 16 }}
            key={user.id + "-" + user.role.key + "-" + user.isActive}
            onSubmit={(event) => {
              event.preventDefault();
              const data = new FormData(event.currentTarget);
              void send("/api/v1/admin/users/" + user.id, "PATCH", {
                role: data.get("role"),
                isActive: data.get("isActive") === "on",
              });
            }}
          >
            <h3>{user.name}</h3>
            <p>
              {user.email} · MFA {user.mfaEnabled ? "enrolled" : "pending"}
            </p>
            <label>
              Role{" "}
              <select name="role" defaultValue={user.role.key}>
                {roles
                  .filter(
                    (role) =>
                      role === user.role.key || canAssignRole(actorRole, role),
                  )
                  .map((role) => (
                    <option key={role}>{role}</option>
                  ))}
              </select>
            </label>
            <label>
              <input
                type="checkbox"
                name="isActive"
                defaultChecked={user.isActive}
              />{" "}
              Active
            </label>
            <button
              className="button button-secondary"
              disabled={
                busy ||
                (user.role.key === "SUPER_ADMIN" && actorRole !== "SUPER_ADMIN")
              }
            >
              Save account and revoke sessions
            </button>
            <button
              className="button button-secondary"
              type="button"
              disabled={
                busy ||
                pending ||
                !user.isActive ||
                (user.role.key === "SUPER_ADMIN" && actorRole !== "SUPER_ADMIN")
              }
              onClick={() =>
                void send(
                  "/api/v1/admin/users/" + user.id + "/reset",
                  "POST",
                  {},
                )
              }
            >
              Create password reset link
            </button>
          </form>
        ))}
      </section>
      <Reauthenticate />
    </>
  );
}
export function Reauthenticate() {
  const [error, setError] = useState(""),
    [success, setSuccess] = useState(false);
  return (
    <form
      className="card form"
      onSubmit={async (event) => {
        event.preventDefault();
        const form = event.currentTarget,
          data = new FormData(form);
        setError("");
        setSuccess(false);
        try {
          const response = await fetch("/api/v1/auth/reauthenticate", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-CSRF-Token": await getCsrfToken(),
            },
            body: JSON.stringify({
              password: data.get("password"),
              code: data.get("code") || undefined,
            }),
          });
          const result = await response.json();
          if (!response.ok)
            throw new Error(result.error?.message ?? "Unable to confirm.");
          form.reset();
          setSuccess(true);
        } catch (error) {
          setError(
            error instanceof Error ? error.message : "Unable to confirm.",
          );
        }
      }}
    >
      <h2>Confirm sensitive changes</h2>
      <label>
        Password{" "}
        <input
          name="password"
          type="password"
          autoComplete="current-password"
          required
        />
      </label>
      <label>
        New authenticator or unused backup code{" "}
        <input name="code" autoComplete="one-time-code" />
      </label>
      <button className="button button-secondary">Confirm identity</button>
      {success && <p role="status">Identity confirmed for five minutes.</p>}
      {error && <p role="alert">{error}</p>}
    </form>
  );
}
