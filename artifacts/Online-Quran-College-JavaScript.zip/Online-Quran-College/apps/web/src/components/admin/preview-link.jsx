"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function PreviewLink({ resource, id }) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const router = useRouter();
  return (
    <div>
      <button
        type="button"
        className="button button-secondary"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          setError("");
          try {
            const response = await fetch(
              `/api/v1/admin/${resource}/${id}/preview-link`,
              {
                method: "POST",
                headers: { "X-CSRF-Token": await getCsrfToken() },
              },
            );
            const result = await response.json();
            if (!response.ok)
              throw new Error(
                result.error?.message ?? "Unable to open preview.",
              );
            router.push(result.data.href);
          } catch (error) {
            setError(
              error instanceof Error
                ? error.message
                : "Unable to open preview.",
            );
            setBusy(false);
          }
        }}
      >
        {busy ? "Opening preview…" : "Preview content"}
      </button>
      {error && <p role="alert">{error}</p>}
    </div>
  );
}
