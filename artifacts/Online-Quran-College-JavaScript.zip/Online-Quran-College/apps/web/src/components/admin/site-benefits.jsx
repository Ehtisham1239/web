"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function SiteBenefits({ initial }) {
  const [items, setItems] = useState(initial),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const [pending, startTransition] = useTransition(),
    router = useRouter();
  return (
    <form
      className="card form"
      style={{ marginBlock: 24 }}
      onSubmit={async (event) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        setBusy(true);
        setError("");
        try {
          const response = await fetch("/api/v1/admin/settings", {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
              "X-CSRF-Token": await getCsrfToken(),
            },
            body: JSON.stringify({
              key: "site.benefits",
              value: {
                items,
                ownerApproved: data.get("ownerApproved") === "on",
              },
            }),
          });
          const result = await response.json();
          if (!response.ok)
            throw new Error(
              result.error?.message ?? "Unable to save website benefits.",
            );
          startTransition(() => router.refresh());
        } catch (error) {
          setError(
            error instanceof Error
              ? error.message
              : "Unable to save website benefits.",
          );
        } finally {
          setBusy(false);
        }
      }}
    >
      <h2>Verified website benefits</h2>
      <p>
        Publish only facts the owner has confirmed. Leave this list empty when
        the facts are unknown.
      </p>
      <fieldset disabled={busy || pending}>
        <legend>Owner-confirmed benefits</legend>
        {items.map((item, index) => (
          <div className="card" key={index}>
            <div className="field">
              <label htmlFor={`benefit-title-${index}`}>
                Benefit {index + 1} heading
              </label>
              <input
                id={`benefit-title-${index}`}
                value={item.title}
                required
                maxLength={160}
                onChange={(event) =>
                  setItems((current) =>
                    current.map((value, n) =>
                      n === index
                        ? { ...value, title: event.target.value }
                        : value,
                    ),
                  )
                }
              />
            </div>
            <div className="field">
              <label htmlFor={`benefit-body-${index}`}>
                Benefit {index + 1} description
              </label>
              <textarea
                id={`benefit-body-${index}`}
                value={item.body}
                required
                maxLength={1000}
                onChange={(event) =>
                  setItems((current) =>
                    current.map((value, n) =>
                      n === index
                        ? { ...value, body: event.target.value }
                        : value,
                    ),
                  )
                }
              />
            </div>
            <button
              className="button button-secondary"
              type="button"
              onClick={() =>
                setItems((current) => current.filter((_, n) => n !== index))
              }
            >
              Remove benefit {index + 1}
            </button>
          </div>
        ))}
        <button
          className="button button-secondary"
          type="button"
          disabled={items.length >= 8}
          onClick={() =>
            setItems((current) => [...current, { title: "", body: "" }])
          }
        >
          Add website benefit
        </button>
        <label>
          <input name="ownerApproved" type="checkbox" required /> I confirm the
          owner has approved these benefits as accurate.
        </label>
        <button className="button" type="submit">
          Save verified benefits
        </button>
      </fieldset>
      {error && <p role="alert">{error}</p>}
    </form>
  );
}
