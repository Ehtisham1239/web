"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { DateTime } from "luxon";
import { getCsrfToken } from "@/lib/auth/client";
export function ClassSessionEditor({
  id,
  version,
  startsAtUtc,
  endsAtUtc,
  meetingUrl,
  timezone,
  canMarkHeld,
}) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  async function save(action, body) {
    setError("");
    setBusy(true);
    try {
      const response = await fetch(`/api/v1/admin/sessions/${id}/${action}`, {
        method: action === "reschedule" ? "POST" : "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": await getCsrfToken(),
        },
        body: JSON.stringify({ version, ...body }),
      });
      const payload = await response.json();
      if (!response.ok)
        throw new Error(
          payload.error?.message ?? "Unable to update this class.",
        );
      startTransition(() => router.refresh());
    } catch (error) {
      setError(
        error instanceof Error ? error.message : "Unable to update this class.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="card" style={{ marginBlock: 24 }}>
      <h2>Manage this class</h2>
      <form
        className="form"
        onSubmit={async (event) => {
          event.preventDefault();
          const data = new FormData(event.currentTarget),
            input = String(data.get("starts")),
            zone = String(data.get("zone"));
          const local = DateTime.fromISO(input, { zone });
          if (
            !local.isValid ||
            local.toFormat("yyyy-MM-dd'T'HH:mm") !== input ||
            local.getPossibleOffsets().length !== 1
          ) {
            setError(
              "Choose a valid, unambiguous local time and IANA time zone.",
            );
            return;
          }
          await save("reschedule", {
            startsAtUtc: local.toUTC().toISO(),
            durationMin: Number(data.get("duration")),
            meetingUrl: String(data.get("meeting")).trim() || null,
          });
        }}
      >
        <fieldset disabled={busy || pending}>
          <legend>Reschedule one class</legend>
          <div className="field">
            <label htmlFor="class-start">New class date and time</label>
            <input
              id="class-start"
              name="starts"
              type="datetime-local"
              required
              defaultValue={DateTime.fromISO(startsAtUtc)
                .setZone(timezone)
                .toFormat("yyyy-MM-dd'T'HH:mm")}
            />
          </div>
          <div className="field">
            <label htmlFor="class-zone">Class time zone</label>
            <input
              id="class-zone"
              name="zone"
              required
              defaultValue={timezone}
            />
          </div>
          <div className="field">
            <label htmlFor="class-duration">Class duration in minutes</label>
            <input
              id="class-duration"
              name="duration"
              type="number"
              min={1}
              max={240}
              required
              defaultValue={
                (Date.parse(endsAtUtc) - Date.parse(startsAtUtc)) / 60000
              }
            />
          </div>
          <div className="field">
            <label htmlFor="class-meeting">Approved HTTPS meeting URL</label>
            <input
              id="class-meeting"
              name="meeting"
              type="url"
              maxLength={2000}
              defaultValue={meetingUrl ?? ""}
            />
            <p>Meeting hostnames must be approved in Settings.</p>
          </div>
          <button className="button" type="submit">
            Reschedule class
          </button>
        </fieldset>
      </form>
      <form
        className="form"
        style={{ marginTop: 24 }}
        onSubmit={async (event) => {
          event.preventDefault();
          const data = new FormData(event.currentTarget);
          await save("status", { status: data.get("status") });
        }}
      >
        <fieldset disabled={busy || pending}>
          <legend>Complete or cancel</legend>
          <div className="field">
            <label htmlFor="class-status">Class outcome</label>
            <select id="class-status" name="status" required defaultValue="">
              <option value="" disabled>
                Choose an outcome
              </option>
              <option value="HELD" disabled={!canMarkHeld}>
                Held
              </option>
              <option value="CANCELLED">Cancelled</option>
            </select>
          </div>
          <label>
            <input type="checkbox" required /> I confirm this class outcome.
          </label>
          <button className="button button-secondary" type="submit">
            Save class outcome
          </button>
        </fieldset>
      </form>
      {error && <p role="alert">{error}</p>}
    </section>
  );
}
