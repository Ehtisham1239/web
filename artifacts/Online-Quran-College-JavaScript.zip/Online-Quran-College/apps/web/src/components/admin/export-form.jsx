"use client";
import { useState } from "react";
import { getCsrfToken } from "@/lib/auth/client";
export function ExportForm({ resources }) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [count, setCount] = useState(null);
  return (
    <form
      className="card form"
      onSubmit={async (event) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget),
          resource = String(data.get("resource"));
        setBusy(true);
        setError("");
        setCount(null);
        try {
          const response = await fetch("/api/v1/admin/exports/" + resource, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-CSRF-Token": await getCsrfToken(),
            },
            body: JSON.stringify({
              from: data.get("from") || undefined,
              to: data.get("to") || undefined,
            }),
          });
          if (!response.ok) {
            const body = await response.json();
            throw new Error(body.error?.message ?? "Unable to export.");
          }
          const url = URL.createObjectURL(await response.blob()),
            link = document.createElement("a");
          link.href = url;
          link.download = "oqc-" + resource + ".csv";
          document.body.append(link);
          link.click();
          link.remove();
          setTimeout(() => URL.revokeObjectURL(url), 1000);
          setCount(Number(response.headers.get("X-Export-Count")));
        } catch (error) {
          setError(
            error instanceof Error ? error.message : "Unable to export.",
          );
        } finally {
          setBusy(false);
        }
      }}
    >
      <h2>Export records</h2>
      <p>
        Exports contain only fields permitted for your role and are limited to
        1,000 records. Choose dates to narrow larger exports. Recent identity
        confirmation is required.
      </p>
      <label>
        Records{" "}
        <select name="resource">
          {resources.map((resource) => (
            <option key={resource} value={resource}>
              {resource.replaceAll("-", " ")}
            </option>
          ))}
        </select>
      </label>
      <label>
        Created from (UTC date) <input name="from" type="date" />
      </label>
      <label>
        Created through (UTC date) <input name="to" type="date" />
      </label>
      <label>
        <input type="checkbox" required /> I need this download for authorized
        college work.
      </label>
      <button className="button button-secondary" disabled={busy}>
        {busy ? "Preparing…" : "Download CSV"}
      </button>
      {error && <p role="alert">{error}</p>}
      {count !== null && <p role="status">Downloaded {count} records.</p>}
    </form>
  );
}
