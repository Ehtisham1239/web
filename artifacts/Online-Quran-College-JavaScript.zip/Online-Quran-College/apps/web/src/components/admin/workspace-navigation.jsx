"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Menu, Search, X } from "lucide-react";

export function WorkspaceNavigation({ items }) {
  const pathname = usePathname();
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const filtered = items.filter((item) =>
    item.label.toLowerCase().includes(search.toLowerCase().trim()),
  );
  return (
    <>
      <button
        type="button"
        className="button button-secondary workspace-menu-toggle"
        aria-expanded={open}
        aria-controls="workspace-navigation"
        onClick={() => setOpen(!open)}
      >
        {open ? (
          <X size={18} aria-hidden="true" />
        ) : (
          <Menu size={18} aria-hidden="true" />
        )}
        {open ? "Close menu" : "Workspace menu"}
      </button>
      <div
        id="workspace-navigation"
        className={`workspace-navigation${open ? " is-open" : ""}`}
      >
        <div className="workspace-search">
          <Search size={16} aria-hidden="true" />
          <label className="sr-only" htmlFor="workspace-search">
            Find a workspace section
          </label>
          <input
            id="workspace-search"
            type="search"
            placeholder="Find a section…"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </div>
        <nav aria-label="Staff navigation">
          {filtered.map((item) => {
            const active =
              item.href === "/admin"
                ? pathname === item.href
                : pathname === item.href ||
                  pathname.startsWith(item.href + "/");
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                onClick={() => {
                  setOpen(false);
                  setSearch("");
                }}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
        {!filtered.length && (
          <p role="status" className="workspace-no-results">
            No matching section.
          </p>
        )}
      </div>
    </>
  );
}
