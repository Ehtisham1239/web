"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function AccountSecurity() {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const router = useRouter();
  return (
    <form
      className="card form"
      onSubmit={async (event) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        setError("");
        if (data.get("password") !== data.get("confirmation")) {
          setError("Passwords must match.");
          return;
        }
        setBusy(true);
        try {
          const response = await fetch("/api/v1/auth/password", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-CSRF-Token": await getCsrfToken(),
            },
            body: JSON.stringify({
              currentPassword: data.get("currentPassword"),
              password: data.get("password"),
              code: data.get("code") || undefined,
            }),
          });
          const result = await response.json();
          if (!response.ok)
            throw new Error(
              result.error?.message ?? "Unable to change password.",
            );
          sessionStorage.removeItem("oqc-csrf");
          router.replace("/admin/login");
          router.refresh();
        } catch (error) {
          setError(
            error instanceof Error
              ? error.message
              : "Unable to change password.",
          );
          setBusy(false);
        }
      }}
    >
      <h2>Change password</h2>
      <p>
        Changing your password signs out all sessions. Your authenticator
        remains enrolled.
      </p>
      <label>
        Current password{" "}
        <input
          name="currentPassword"
          type="password"
          autoComplete="current-password"
          required
        />
      </label>
      <label>
        New passphrase{" "}
        <input
          name="password"
          type="password"
          autoComplete="new-password"
          minLength={12}
          maxLength={128}
          required
        />
      </label>
      <label>
        Confirm new passphrase{" "}
        <input
          name="confirmation"
          type="password"
          autoComplete="new-password"
          required
        />
      </label>
      <label>
        Authenticator or unused backup code{" "}
        <input name="code" autoComplete="one-time-code" />
      </label>
      {error && <p role="alert">{error}</p>}
      <button className="button button-primary" disabled={busy}>
        {busy ? "Updating…" : "Change password and sign out"}
      </button>
    </form>
  );
}
