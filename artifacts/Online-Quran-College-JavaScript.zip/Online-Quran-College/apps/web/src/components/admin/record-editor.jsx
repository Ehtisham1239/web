"use client";
import { RichTextEditor } from "@/components/ui/rich-text-editor";
import { richDocumentSchema } from "@/lib/validation/richtext";
import { getCsrfToken } from "@/lib/auth/client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
export function RecordEditor({ resource, fields, id, initial = {} }) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [rich, setRich] = useState(
      Object.fromEntries(
        fields
          .filter(
            (x) =>
              x.type === "rich" &&
              richDocumentSchema.safeParse(initial[x.key]).success,
          )
          .map((x) => [x.key, initial[x.key]]),
      ),
    );
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const form = event.currentTarget,
      values = new FormData(form),
      body = {};
    for (const field of fields) {
      const value = values.get(field.key);
      if (field.type === "rich") {
        if (rich[field.key]) body[field.key] = rich[field.key];
      } else if (field.type === "checkbox") body[field.key] = value === "on";
      else if (field.type === "number" && value !== "")
        body[field.key] = Number(value);
      else if (field.type === "list")
        body[field.key] = String(value)
          .split(",")
          .map((x) => x.trim())
          .filter(Boolean);
      else if (value) body[field.key] = value;
    }
    if (id && initial.version) body.version = initial.version;
    try {
      const response = await fetch(
        "/api/v1/admin/" + resource + (id ? "/" + id : ""),
        {
          method: id ? "PATCH" : "POST",
          headers: {
            "Content-Type": "application/json",
            "X-CSRF-Token": await getCsrfToken(),
          },
          body: JSON.stringify(body),
        },
      );
      const payload = await response.json();
      if (!response.ok)
        throw new Error(
          payload.error?.details
            ?.map((x) => x.path + ": " + x.message)
            .join("; ") ||
            payload.error?.message ||
            "Unable to save.",
        );
      if (!id) form.reset();
      startTransition(() => router.refresh());
    } catch (error) {
      setError(error instanceof Error ? error.message : "Please try again.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <details className="card" style={{ marginBlock: 24 }}>
      <summary>{id ? "Edit record" : "Create a record"}</summary>
      <form className="form" onSubmit={submit} style={{ marginTop: 24 }}>
        {error && (
          <div className="error-summary" role="alert">
            {error}
          </div>
        )}
        {fields.map((field) =>
          field.type === "rich" ? (
            <RichTextEditor
              key={field.key}
              name={field.key}
              label={field.label}
              initial={
                richDocumentSchema.safeParse(initial[field.key]).success
                  ? initial[field.key]
                  : undefined
              }
              onChange={(value) =>
                setRich((current) => ({ ...current, [field.key]: value }))
              }
            />
          ) : (
            <div className="field" key={field.key}>
              <label htmlFor={"field-" + field.key}>{field.label}</label>
              {field.type === "textarea" ? (
                <textarea
                  id={"field-" + field.key}
                  name={field.key}
                  required={field.required}
                  maxLength={field.maxLength}
                  aria-describedby={
                    field.maxLength ? "hint-" + field.key : undefined
                  }
                  defaultValue={String(initial[field.key] ?? "")}
                />
              ) : field.type === "select" ? (
                <select
                  defaultValue={String(
                    initial[field.key] ??
                      (typeof field.options?.[0] === "string"
                        ? field.options[0]
                        : field.options?.[0]?.value) ??
                      "",
                  )}
                  id={"field-" + field.key}
                  name={field.key}
                  required={field.required}
                >
                  {field.options?.map((value) => (
                    <option
                      key={typeof value === "string" ? value : value.value}
                      value={typeof value === "string" ? value : value.value}
                    >
                      {typeof value === "string" ? value : value.label}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  id={"field-" + field.key}
                  name={field.key}
                  type={
                    field.type === "number"
                      ? "number"
                      : field.type === "checkbox"
                        ? "checkbox"
                        : "text"
                  }
                  required={field.required}
                  maxLength={field.maxLength}
                  aria-describedby={
                    field.maxLength ? "hint-" + field.key : undefined
                  }
                  defaultChecked={
                    field.type === "checkbox"
                      ? Boolean(initial[field.key])
                      : undefined
                  }
                  defaultValue={
                    field.type === "checkbox"
                      ? undefined
                      : field.type === "list"
                        ? initial[field.key]?.join(", ")
                        : String(initial[field.key] ?? "")
                  }
                />
              )}
              {field.maxLength && (
                <p id={"hint-" + field.key}>
                  Up to {field.maxLength} characters. Leave blank to use the
                  content title or summary.
                </p>
              )}
            </div>
          ),
        )}
        <button className="button button-primary" disabled={busy || pending}>
          {busy
            ? "Saving…"
            : id
              ? "Save changes"
              : resource === "menus"
                ? "Add navigation link"
                : "Save draft"}
        </button>
      </form>
    </details>
  );
}
export function RecordActions({ resource, id, status, version }) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const next = {
    DRAFT: "SUBMITTED",
    SUBMITTED: "APPROVED",
    APPROVED: "PUBLISHED",
    PUBLISHED: "DRAFT",
    ARCHIVED: "DRAFT",
  };
  async function update() {
    setBusy(true);
    setError("");
    try {
      const response = await fetch(`/api/v1/admin/${resource}/${id}/status`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": await getCsrfToken(),
        },
        body: JSON.stringify({ status: next[status], version }),
      });
      const payload = await response.json();
      if (!response.ok)
        throw new Error(payload.error?.message ?? "Update failed.");
      startTransition(() => router.refresh());
    } catch (error) {
      setError(error instanceof Error ? error.message : "Please try again.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div>
      {next[status] && (
        <button
          className="button button-secondary"
          onClick={update}
          disabled={busy || pending}
        >
          {busy
            ? "Updating…"
            : next[status] === "SUBMITTED"
              ? "Submit for approval"
              : next[status] === "APPROVED"
                ? "Approve"
                : next[status] === "PUBLISHED"
                  ? "Publish"
                  : "Return to draft"}
        </button>
      )}
      {error && (
        <p className="field-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
