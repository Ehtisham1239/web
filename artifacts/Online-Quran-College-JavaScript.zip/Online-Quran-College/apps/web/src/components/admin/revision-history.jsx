"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function RevisionHistory({
  resource,
  id,
  version,
  current,
  revisions,
  restorable,
}) {
  const [selected, setSelected] = useState(revisions[0]?.id ?? ""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter(),
    revision = revisions.find((item) => item.id === selected);
  return (
    <section className="card" style={{ marginBlock: 24 }}>
      <h2>Content revision history</h2>
      {!revisions.length ? (
        <p>No previous revisions.</p>
      ) : (
        <>
          <div className="field">
            <label htmlFor="revision-choice">Previous revision</label>
            <select
              id="revision-choice"
              value={selected}
              onChange={(event) => setSelected(event.target.value)}
            >
              {revisions.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.createdAt} (UTC) · {item.author}
                </option>
              ))}
            </select>
          </div>
          {revision && (
            <div className="table-scroll">
              <table className="data-table">
                <caption>
                  Current content compared with the selected revision
                </caption>
                <thead>
                  <tr>
                    <th scope="col">Field</th>
                    <th scope="col">Current</th>
                    <th scope="col">Selected revision</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.keys(revision.fields).map((field) => (
                    <tr key={field}>
                      <th scope="row">{field}</th>
                      <td style={{ whiteSpace: "pre-wrap" }}>
                        {current[field] || "—"}
                      </td>
                      <td style={{ whiteSpace: "pre-wrap" }}>
                        {revision.fields[field] || "—"}
                        {revision.fields[field] !== current[field] && (
                          <span className="badge">Changed</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {restorable && revision && (
            <form
              className="form"
              style={{ marginTop: 24 }}
              onSubmit={async (event) => {
                event.preventDefault();
                setBusy(true);
                setError("");
                try {
                  const response = await fetch(
                    `/api/v1/admin/${resource}/${id}/revisions`,
                    {
                      method: "POST",
                      headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-Token": await getCsrfToken(),
                      },
                      body: JSON.stringify({
                        revisionId: revision.id,
                        version,
                        confirmed: true,
                      }),
                    },
                  );
                  const payload = await response.json();
                  if (!response.ok)
                    throw new Error(
                      payload.error?.message ??
                        "Unable to restore this revision.",
                    );
                  startTransition(() => router.refresh());
                } catch (error) {
                  setError(
                    error instanceof Error
                      ? error.message
                      : "Unable to restore this revision.",
                  );
                } finally {
                  setBusy(false);
                }
              }}
            >
              <fieldset disabled={busy || pending}>
                <legend>Restore as draft</legend>
                <p>
                  Restored content needs review and publication. The current
                  content is retained in history.
                </p>
                <label>
                  <input type="checkbox" required /> I confirm this revision
                  should replace the current draft.
                </label>
                <button className="button button-secondary" type="submit">
                  Restore selected revision
                </button>
              </fieldset>
              {error && <p role="alert">{error}</p>}
            </form>
          )}
        </>
      )}
    </section>
  );
}
