import Link from "next/link";
import { publicCatalog, catalogFilterOptions } from "@/server/services/public";
import { publicCatalogQuery } from "@/lib/validation/public-catalog";
import { AppError } from "@/lib/platform/errors";
import { formatMinor } from "@/lib/platform/money";
import { EmptyState } from "@/components/public/empty-state";
import messages from "@/messages/en.json";
import { jsonLd } from "@/lib/platform/seo";
const text = (value) => (typeof value === "string" ? value : "");
export async function CatalogListing({ resource, searchParams }) {
  const raw = Object.fromEntries(
    Object.entries(searchParams).filter(
      ([, value]) => value !== "" && value !== undefined,
    ),
  );
  const parsed = publicCatalogQuery.safeParse(raw);
  if (!parsed.success)
    return (
      <>
        <p role="alert">Choose valid search and filter values.</p>
        <Link href={`/${resource}`}>Reset filters</Link>
      </>
    );
  const query = { ...parsed.data, pageSize: 12 },
    apiResource = resource === "faq" ? "faqs" : resource;
  let result;
  try {
    result = await publicCatalog(apiResource, query);
  } catch (error) {
    if (error instanceof AppError && error.status === 400)
      return (
        <>
          <p role="alert">{error.message}</p>
          <Link href={`/${resource}`}>Reset filters</Link>
        </>
      );
    throw error;
  }
  const options = await catalogFilterOptions(apiResource);
  const filters = {
    courses: { ageGroup: "Age group", level: "Level" },
    teachers: { gender: "Teacher gender", language: "Teaching language" },
    faq: { category: "FAQ category" },
    blog: { tag: "Article topic" },
    pricing: { currency: "Currency" },
  };
  const link = (page) =>
    `/${resource}?${new URLSearchParams({ ...Object.fromEntries(Object.entries(raw).filter(([, value]) => typeof value === "string")), page: String(page) })}`;
  return (
    <>
      {resource === "faq" && result.data.length > 0 && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: jsonLd({
              "@context": "https://schema.org",
              "@type": "FAQPage",
              mainEntity: result.data.map((value) => {
                const item = value;
                return {
                  "@type": "Question",
                  name: text(item.question),
                  acceptedAnswer: {
                    "@type": "Answer",
                    text: text(item.answer),
                  },
                };
              }),
            }),
          }}
        />
      )}
      <form
        action={`/${resource}`}
        method="GET"
        role="search"
        aria-label={`${resource} search`}
        className="card form"
        style={{ marginBottom: 24 }}
      >
        {resource !== "pricing" && (
          <div className="field">
            <label htmlFor="catalog-search">
              Search {resource === "faq" ? "questions" : resource}
            </label>
            <input
              id="catalog-search"
              name="q"
              type="search"
              maxLength={100}
              defaultValue={query.q}
            />
          </div>
        )}
        {Object.entries(filters[resource]).map(([key, label]) => {
          const values = options[key];
          if (
            !Array.isArray(values) ||
            !values.length ||
            (key === "currency" && values.length < 2)
          )
            return null;
          return (
            <div className="field" key={key}>
              <label htmlFor={`catalog-${key}`}>{label}</label>
              <select
                id={`catalog-${key}`}
                name={key}
                defaultValue={text(raw[key])}
              >
                <option value="">All {label.toLowerCase()}</option>
                {values.map((value) => (
                  <option key={text(value)} value={text(value)}>
                    {text(value)}
                  </option>
                ))}
              </select>
            </div>
          );
        })}
        {resource === "teachers" &&
          Array.isArray(options.courses) &&
          options.courses.length > 0 && (
            <div className="field">
              <label htmlFor="catalog-course">Teaching course</label>
              <select
                id="catalog-course"
                name="courseId"
                defaultValue={query.courseId ?? ""}
              >
                <option value="">All courses</option>
                {options.courses.map((course) => (
                  <option key={course.id} value={course.id}>
                    {course.title}
                  </option>
                ))}
              </select>
            </div>
          )}
        <div className="toolbar">
          <button className="button button-secondary" type="submit">
            Apply filters
          </button>
          <Link href={`/${resource}`}>Clear filters</Link>
        </div>
      </form>
      {result.meta.total > 0 && (
        <p role="status">
          {result.meta.total} {result.meta.total === 1 ? "result" : "results"}
        </p>
      )}
      {result.data.length ? (
        <div className="card-grid">
          {result.data.map((rawItem) => {
            const item = rawItem,
              id = text(item.id);
            if (resource === "faq")
              return (
                <details className="card" key={id}>
                  <summary>{text(item.question)}</summary>
                  <p>{text(item.answer)}</p>
                </details>
              );
            if (resource === "pricing")
              return (
                <article className="card" key={id}>
                  <h2>{text(item.name)}</h2>
                  <p>
                    {String(item.classesPerWeek)} classes per week ·{" "}
                    {String(item.durationMin)} minutes
                  </p>
                  {Array.isArray(item.pricingPlanPrice_planId) &&
                    item.pricingPlanPrice_planId
                      .filter(
                        (price) =>
                          !query.currency || price.currency === query.currency,
                      )
                      .map((price) => (
                        <p className="price" key={price.id}>
                          <strong>
                            {formatMinor(price.amountMinor, price.currency)}
                          </strong>{" "}
                          <span>
                            {price.currency} · {text(item.billingPeriod)}
                          </span>
                        </p>
                      ))}
                  <Link className="button button-secondary" href="/free-trial">
                    Book a Free Trial
                  </Link>
                </article>
              );
            const title = text(item.title) || text(item.displayName),
              route = resource === "blog" ? "blog" : resource;
            return (
              <article className="card" key={id}>
                {resource === "courses" && (
                  <span className="badge">{text(item.level)}</span>
                )}
                <h2>{title}</h2>
                <p>
                  {text(item.summary) || text(item.bio) || text(item.excerpt)}
                </p>
                <Link
                  href={`/${route}/${text(item.slug)}`}
                  className="button button-secondary"
                >
                  {resource === "courses"
                    ? "Explore course"
                    : resource === "teachers"
                      ? "View profile"
                      : "Read article"}
                  <span className="sr-only">: {title}</span>
                </Link>
              </article>
            );
          })}
        </div>
      ) : (
        <EmptyState
          title={
            Object.values(raw).some(Boolean)
              ? "No matching results"
              : resource === "courses"
                ? "Courses are being prepared"
                : resource === "teachers"
                  ? "Meet our teachers"
                  : resource === "pricing"
                    ? messages.empty.pricing
                    : `No published ${resource === "faq" ? "answers" : "articles"} yet`
          }
          description={
            Object.values(raw).some(Boolean)
              ? "Try another search or clear the filters."
              : messages.empty[resource]
          }
        />
      )}
      {(query.page > 1 || result.meta.total > query.pageSize) && (
        <nav aria-label="Catalog pages" className="toolbar">
          {query.page > 1 && (
            <Link href={link(query.page - 1)}>Previous page</Link>
          )}
          <span>Page {query.page}</span>
          {query.page * query.pageSize < result.meta.total && (
            <Link href={link(query.page + 1)}>Next page</Link>
          )}
        </nav>
      )}
      {resource === "blog" && (
        <p>
          <Link href="/rss.xml">Subscribe to the journal RSS feed</Link>
        </p>
      )}
    </>
  );
}
