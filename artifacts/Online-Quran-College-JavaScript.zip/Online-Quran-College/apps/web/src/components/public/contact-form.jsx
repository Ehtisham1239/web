"use client";
import { BotCheck } from "./bot-check";
import { useState, useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { contactSchema } from "@/lib/validation/admissions";
export function ContactForm({
  siteKey,
  allowWithoutProvider = false,
  consentVersion = "v1-draft",
  consentText = "I agree to the draft privacy notice and to staff reviewing my message. I understand this development form is not a live admissions channel.",
  consentAvailable = true,
}) {
  const [result, setResult] = useState("");
  const [failure, setFailure] = useState("");
  const form = useForm({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
      website: "",
      botToken:
        process.env.NODE_ENV !== "production" ? "development-bypass" : "",
      consentTextVersion: consentVersion,
    },
  });
  const botToken = useWatch({ control: form.control, name: "botToken" });
  useEffect(() => {
    form.setValue("startedAt", Date.now());
  }, [form]);
  async function submit(data) {
    setFailure("");
    try {
      const response = await fetch("/api/v1/public/contact-messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const payload = await response.json();
      if (!response.ok)
        throw new Error(
          payload.error?.message ?? "Could not send your message.",
        );
      setResult(payload.data.message);
    } catch (error) {
      setFailure(error instanceof Error ? error.message : "Please try again.");
      setTimeout(() => document.getElementById("form-errors")?.focus(), 0);
    }
  }
  if (result)
    return (
      <div className="card" role="status">
        <h2>Message received</h2>
        <p>{result}</p>
        <p>
          No automatic email is promised. Please keep this confirmation for your
          records.
        </p>
      </div>
    );
  return (
    <form
      className="form"
      onSubmit={form.handleSubmit(submit, () =>
        setTimeout(() => document.getElementById("form-errors")?.focus(), 0),
      )}
      noValidate
    >
      <div className="notice">
        Consent wording is a draft awaiting legal review. This is a development
        environment.
      </div>
      {(failure || Object.keys(form.formState.errors).length > 0) && (
        <div
          className="error-summary"
          tabIndex={-1}
          id="form-errors"
          role="alert"
        >
          {failure || "Check the form fields below."}
        </div>
      )}
      <div className="form-grid">
        {[
          ["name", "Your name"],
          ["email", "Email address"],
        ].map(([field, label]) => (
          <div className="field" key={field}>
            <label htmlFor={field}>{label}</label>
            <input
              id={field}
              type={field === "email" ? "email" : "text"}
              autoComplete={field === "email" ? "email" : "name"}
              {...form.register(field)}
              aria-invalid={!!form.formState.errors[field]}
              aria-describedby={field + "-error"}
            />
            <p className="field-error" id={field + "-error"}>
              {form.formState.errors[field]?.message}
            </p>
          </div>
        ))}
      </div>
      <div className="field">
        <label htmlFor="phone">
          Phone number (optional, international format)
        </label>
        <input
          id="phone"
          type="tel"
          autoComplete="tel"
          {...form.register("phone", {
            setValueAs: (value) => value || undefined,
          })}
        />
        <p className="field-error">{form.formState.errors.phone?.message}</p>
      </div>
      <div className="field">
        <label htmlFor="subject">Subject</label>
        <input id="subject" {...form.register("subject")} />
        <p className="field-error">{form.formState.errors.subject?.message}</p>
      </div>
      <div className="field">
        <label htmlFor="message">Your message</label>
        <textarea id="message" maxLength={2000} {...form.register("message")} />
        <p className="field-error">{form.formState.errors.message?.message}</p>
      </div>
      <div hidden>
        <label htmlFor="website">Website</label>
        <input
          id="website"
          tabIndex={-1}
          autoComplete="off"
          {...form.register("website")}
        />
      </div>
      <label className="check-row">
        <input type="checkbox" {...form.register("consentGiven")} />
        {consentText}
      </label>
      <p className="field-error">
        {form.formState.errors.consentGiven?.message}
      </p>
      {!consentAvailable && (
        <p role="status">
          Messages are awaiting approval of the privacy consent notice.
        </p>
      )}
      <BotCheck
        allowWithoutProvider={allowWithoutProvider}
        siteKey={siteKey}
        onToken={(token) => form.setValue("botToken", token)}
      />
      <button
        className="button button-primary"
        disabled={
          !consentAvailable ||
          form.formState.isSubmitting ||
          (process.env.NODE_ENV === "production" &&
            !allowWithoutProvider &&
            !botToken)
        }
      >
        {" "}
        {form.formState.isSubmitting ? "Sending…" : "Send message"}
      </button>
    </form>
  );
}
