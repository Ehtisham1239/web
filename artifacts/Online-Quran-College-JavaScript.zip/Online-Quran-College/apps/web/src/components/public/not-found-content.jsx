import Link from "next/link";
import Image from "next/image";
import messages from "@/messages/en.json";
export function NotFoundContent() {
  return (
    <section className="container page-title">
      <Image
        src="/brand/logo.jpg"
        alt={messages.brand}
        width={96}
        height={96}
      />
      <p className="eyebrow">404</p>
      <h1>This page isn’t here.</h1>
      <p>Search our approved courses or choose your next step.</p>
      <form
        action="/courses"
        role="search"
        aria-label="Find a course"
        className="form"
      >
        <div className="field">
          <label htmlFor="missing-search">Search courses</label>
          <input id="missing-search" type="search" name="q" maxLength={100} />
        </div>
        <button className="button button-secondary" type="submit">
          Search courses
        </button>
      </form>
      <div className="toolbar">
        <Link href="/" className="button button-secondary">
          Go home
        </Link>
        <Link href="/free-trial" className="button button-primary">
          Book a Free Trial
        </Link>
      </div>
    </section>
  );
}
