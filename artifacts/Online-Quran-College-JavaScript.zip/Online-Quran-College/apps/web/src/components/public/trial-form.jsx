"use client";
import { BotCheck } from "./bot-check";
import { useEffect, useState } from "react";
import { useFieldArray, useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { trialSchema } from "@/lib/validation/admissions";
import {
  preferenceDraftKey,
  encodePreferenceDraft,
  decodePreferenceDraft,
} from "@/lib/admissions/preference-draft";
export function TrialForm({
  courses,
  siteKey,
  allowWithoutProvider = false,
  consentVersion = "v1-draft",
  consentText = "I agree to the draft privacy notice and consent to staff reviewing this application.",
  consentAvailable = true,
}) {
  const [key] = useState(() => crypto.randomUUID());
  const [step, setStep] = useState(0);
  const [confirmation, setConfirmation] = useState(null),
    [failure, setFailure] = useState("");
  const form = useForm({
    resolver: zodResolver(trialSchema),
    defaultValues: {
      learnerName: "",
      email: "",
      phoneE164: "",
      country: "",
      ageBand: "18_PLUS",
      level: "NOT_SURE",
      teacherGenderPref: "ANY",
      teachingLanguage: "ENGLISH",
      website: "",
      notes: "",
      consentTextVersion: consentVersion,
      botToken:
        process.env.NODE_ENV !== "production" ? "development-bypass" : "",
      availableSlots: [{ weekday: 1, startMinute: 600, endMinute: 660 }],
    },
  });
  const botToken = useWatch({ control: form.control, name: "botToken" });
  const slots = useFieldArray({
    control: form.control,
    name: "availableSlots",
  });
  const preferredTimes = useWatch({
    control: form.control,
    name: "availableSlots",
  });
  const timeValue = (minute) =>
    Number.isFinite(minute)
      ? `${String(Math.floor((minute % 1440) / 60)).padStart(2, "0")}:${String(minute % 60).padStart(2, "0")}`
      : "";
  useEffect(() => {
    let restored = {};
    try {
      restored = decodePreferenceDraft(
        sessionStorage.getItem(preferenceDraftKey),
      );
    } catch {}
    form.reset({ ...form.getValues(), ...restored, consentGiven: undefined });
    form.setValue(
      "timezone",
      restored.timezone ?? Intl.DateTimeFormat().resolvedOptions().timeZone,
    );
    form.setValue("startedAt", Date.now());
    const unsubscribe = form.subscribe({
      formState: { values: true },
      callback: ({ values }) => {
        try {
          sessionStorage.setItem(
            preferenceDraftKey,
            encodePreferenceDraft(values),
          );
        } catch {}
      },
    });
    return unsubscribe;
  }, [form]);
  async function advance() {
    const fields =
      step === 0
        ? ["learnerName", "email", "phoneE164", "country", "timezone"]
        : [
            "courseId",
            "ageBand",
            "guardianName",
            "level",
            "teacherGenderPref",
            "teachingLanguage",
            "availableSlots",
          ];
    const valid = await form.trigger(fields);
    if (valid) setStep((current) => Math.min(2, current + 1));
    else {
      if (form.getFieldState("guardianName").error) setStep(0);
      setTimeout(() => document.getElementById("form-errors")?.focus(), 0);
    }
  }
  async function submit(data) {
    setFailure("");
    try {
      const response = await fetch("/api/v1/public/trial-applications", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Idempotency-Key": key },
        body: JSON.stringify(data),
      });
      const payload = await response.json();
      if (!response.ok)
        throw new Error(
          payload.error?.message ?? "Could not submit your application.",
        );
      setConfirmation(payload.data);
      try {
        sessionStorage.removeItem(preferenceDraftKey);
      } catch {}
    } catch (error) {
      setFailure(error instanceof Error ? error.message : "Please try again.");
      setTimeout(() => document.getElementById("form-errors")?.focus(), 0);
    }
  }
  if (confirmation)
    return (
      <div className="card" role="status">
        <h2>Application received</h2>
        <p>
          Reference: <strong>{confirmation.reference}</strong>
        </p>
        <p>{confirmation.message}</p>
        <p>
          Keep this reference. No automatic email or class time has been
          confirmed.
        </p>
      </div>
    );
  const fields = [
    ["learnerName", "Learner full name", "text"],
    ["guardianName", "Guardian name (required under 18)", "text"],
    ["email", "Email address", "email"],
    ["phoneE164", "Phone (international format)", "tel"],
    ["country", "Country (two-letter code)", "text"],
    ["timezone", "Time zone", "text"],
  ];
  return (
    <form
      className="form"
      onSubmit={form.handleSubmit(submit, () => {
        const errors = form.formState.errors;
        if (
          errors.learnerName ||
          errors.email ||
          errors.phoneE164 ||
          errors.country ||
          errors.timezone ||
          errors.guardianName
        )
          setStep(0);
        else if (errors.courseId || errors.ageBand || errors.availableSlots)
          setStep(1);
        setTimeout(() => document.getElementById("form-errors")?.focus(), 0);
      })}
      noValidate
    >
      {consentVersion === "v1-draft" && (
        <div className="notice">
          Consent and trial duration await owner review. This is a development
          environment.
        </div>
      )}
      <div className="trial-progress">
        <p role="status">
          Step {step + 1} of 3:{" "}
          {
            ["Your details", "Learning preferences", "Consent and submission"][
              step
            ]
          }
        </p>
        <progress value={step + 1} max={3} aria-label="Application progress" />
      </div>
      <p>
        Course preferences are remembered in this tab for 30 minutes. Re-enter
        contact details after reloading.
      </p>
      {(failure || Object.keys(form.formState.errors).length > 0) && (
        <div
          className="error-summary"
          role="alert"
          tabIndex={-1}
          id="form-errors"
        >
          {failure || "Check the highlighted fields."}
        </div>
      )}
      <section
        className={"trial-step" + (step === 0 ? " trial-step-active" : "")}
        aria-label="Your details"
      >
        <div className="form-grid">
          {fields.map(([field, label, type]) => (
            <div className="field" key={field}>
              <label htmlFor={field}>{label}</label>
              <input
                id={field}
                type={type}
                {...form.register(field, {
                  setValueAs: (value) =>
                    field === "guardianName" && !value
                      ? undefined
                      : field === "country"
                        ? value.toUpperCase()
                        : value,
                })}
                aria-invalid={!!form.formState.errors[field]}
                aria-describedby={field + "-error"}
              />
              <p className="field-error" id={field + "-error"}>
                {form.formState.errors[field]?.message}
              </p>
            </div>
          ))}
        </div>
      </section>
      <section
        className={"trial-step" + (step === 1 ? " trial-step-active" : "")}
        aria-label="Learning preferences"
      >
        <div className="field">
          <label htmlFor="course">Course</label>
          <select id="course" {...form.register("courseId")}>
            <option value="">Select a course</option>
            {courses.map((course) => (
              <option key={course.id} value={course.id}>
                {course.title}
              </option>
            ))}
          </select>
          <p className="field-error">
            {form.formState.errors.courseId?.message}
          </p>
        </div>
        <div className="form-grid">
          {[
            {
              field: "ageBand",
              label: "Age band",
              options: [
                ["UNDER_6", "Under 6"],
                ["6_8", "6–8"],
                ["9_12", "9–12"],
                ["13_17", "13–17"],
                ["18_PLUS", "18+"],
              ],
            },
            {
              field: "level",
              label: "Current level",
              options: [
                ["BEGINNER", "Beginner"],
                ["SLOW_READER", "Can read slowly"],
                ["FLUENT", "Fluent"],
                ["NOT_SURE", "Not sure"],
              ],
            },
            {
              field: "teacherGenderPref",
              label: "Teacher preference",
              options: [
                ["ANY", "No preference"],
                ["MALE", "Male"],
                ["FEMALE", "Female"],
              ],
            },
            {
              field: "teachingLanguage",
              label: "Teaching language",
              options: [
                ["ENGLISH", "English"],
                ["URDU", "Urdu"],
                ["ARABIC", "Arabic"],
                ["OTHER", "Other"],
              ],
            },
          ].map(({ field, label, options }) => (
            <div className="field" key={field}>
              <label htmlFor={field}>{label}</label>
              <select id={field} {...form.register(field)}>
                {options.map(([value, text]) => (
                  <option key={value} value={value}>
                    {text}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
        {slots.fields.map((slot, index) => (
          <fieldset className="card" key={slot.id}>
            <legend>
              Preferred time range {index + 1} (in your time zone)
            </legend>
            <div className="form-grid">
              <div className="field">
                <label htmlFor={`weekday-${index}`}>
                  Day{index ? ` ${index + 1}` : ""}
                </label>
                <select
                  id={`weekday-${index}`}
                  {...form.register(`availableSlots.${index}.weekday`, {
                    valueAsNumber: true,
                  })}
                >
                  {[
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                    "Sunday",
                  ].map((day, dayIndex) => (
                    <option key={day} value={dayIndex + 1}>
                      {day}
                    </option>
                  ))}
                </select>
              </div>
              {["startMinute", "endMinute"].map((field) => (
                <div className="field" key={field}>
                  <label htmlFor={`${field}-${index}`}>
                    {field === "startMinute"
                      ? "Preferred start time"
                      : "Preferred end time"}
                    {index ? ` ${index + 1}` : ""}
                  </label>
                  <input
                    id={`${field}-${index}`}
                    type="time"
                    step={60}
                    value={timeValue(preferredTimes?.[index]?.[field])}
                    onChange={(event) => {
                      const [hour, minute] = event.target.value
                        .split(":")
                        .map(Number);
                      form.setValue(
                        `availableSlots.${index}.${field}`,
                        event.target.value
                          ? field === "endMinute" && hour === 0 && minute === 0
                            ? 1440
                            : hour * 60 + minute
                          : Number.NaN,
                        { shouldDirty: true, shouldValidate: true },
                      );
                    }}
                  />
                </div>
              ))}
            </div>
            <p className="field-error" role="status">
              {form.formState.errors.availableSlots?.[index]?.message}
            </p>
            {slots.fields.length > 1 && (
              <button
                type="button"
                className="button button-secondary"
                onClick={() => slots.remove(index)}
              >
                Remove time range {index + 1}
              </button>
            )}
          </fieldset>
        ))}
        {slots.fields.length < 3 && (
          <button
            type="button"
            className="button button-secondary"
            onClick={() =>
              slots.append({ weekday: 1, startMinute: 600, endMinute: 660 })
            }
          >
            Add preferred time range
          </button>
        )}
        <p className="field-error">
          {form.formState.errors.availableSlots?.message}
        </p>
      </section>
      <section
        className={"trial-step" + (step === 2 ? " trial-step-active" : "")}
        aria-label="Consent and submission"
      >
        <div className="field">
          <label htmlFor="notes">Notes (optional)</label>
          <textarea id="notes" maxLength={500} {...form.register("notes")} />
        </div>
        <div hidden>
          <label htmlFor="trial-website">Website</label>
          <input
            id="trial-website"
            tabIndex={-1}
            autoComplete="off"
            {...form.register("website")}
          />
        </div>
        <label className="check-row">
          <input type="checkbox" {...form.register("consentGiven")} />
          {consentText} For a learner under 18, I confirm I am their guardian.
        </label>
        <p className="field-error">
          {form.formState.errors.consentGiven?.message}
        </p>
        {!consentAvailable && (
          <p role="status">
            Applications are awaiting approval of the privacy consent notice.
          </p>
        )}
        <BotCheck
          allowWithoutProvider={allowWithoutProvider}
          siteKey={siteKey}
          onToken={(token) => form.setValue("botToken", token)}
        />
        <button
          className="button button-primary"
          disabled={
            !consentAvailable ||
            form.formState.isSubmitting ||
            (process.env.NODE_ENV === "production" &&
              !allowWithoutProvider &&
              !botToken)
          }
        >
          {form.formState.isSubmitting ? "Submitting…" : "Submit application"}
        </button>
      </section>
      <div className="trial-step-controls toolbar">
        {step > 0 && (
          <button
            className="button button-secondary"
            type="button"
            onClick={() => setStep((current) => current - 1)}
          >
            Previous step
          </button>
        )}
        {step < 2 && (
          <button
            className="button button-primary"
            type="button"
            onClick={() => void advance()}
          >
            Continue application
          </button>
        )}
      </div>
    </form>
  );
}
