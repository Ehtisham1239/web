"use client";
import Link from "next/link";
import { ChevronDown } from "lucide-react";
export function NavDropdown({ href, label, groups }) {
  return (
    <details className="nav-dropdown">
      <summary>
        {label}
        <ChevronDown size={14} aria-hidden="true" />
      </summary>
      <div className="nav-panel">
        <Link href={href}>All {label.toLowerCase()}</Link>
        {groups.map((group) => (
          <div key={group.label}>
            <strong>{group.label}</strong>
            {group.links.map((link) => (
              <Link key={link.href} href={link.href}>
                {link.label}
              </Link>
            ))}
          </div>
        ))}
      </div>
    </details>
  );
}
