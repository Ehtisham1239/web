"use client";
import Link from "next/link";
import Image from "next/image";
import * as Dialog from "@radix-ui/react-dialog";
import { Menu, X, ArrowUpRight } from "lucide-react";
import messages from "@/messages/en.json";
import { NavDropdown } from "@/components/public/nav-dropdown";
const defaults = Object.entries(messages.nav).map(([key, label]) => ({
  href: key === "home" ? "/" : "/" + key,
  label,
}));
export function Header({ items = [], courseGroups = [], teacherGroups = [] }) {
  const links = items.length ? items : defaults;
  return (
    <header className="site-header">
      <div className="header-inner">
        <Link href="/" aria-label={messages.brand + " home"} className="brand">
          <Image
            src="/brand/logo.jpg"
            alt={messages.brand}
            width={96}
            height={96}
            className="brand-logo"
            priority
          />
        </Link>
        <nav aria-label="Main navigation" className="desktop-nav">
          {links.map(({ href, label }, index) => (
            <div key={index}>
              {href === "/courses" && courseGroups.length ? (
                <NavDropdown href={href} label={label} groups={courseGroups} />
              ) : href === "/teachers" && teacherGroups.length ? (
                <NavDropdown href={href} label={label} groups={teacherGroups} />
              ) : (
                <Link href={href}>{label}</Link>
              )}
            </div>
          ))}
        </nav>
        <Link className="button button-primary header-trial" href="/free-trial">
          {messages.trial}
          <ArrowUpRight size={16} />
        </Link>
        <Dialog.Root>
          <Dialog.Trigger
            className="icon-button mobile-menu"
            aria-label="Open navigation"
          >
            <Menu />
          </Dialog.Trigger>
          <Dialog.Portal>
            <Dialog.Overlay className="menu-overlay" />
            <Dialog.Content className="menu-sheet">
              <Dialog.Title>Navigation</Dialog.Title>
              <Dialog.Description className="sr-only">
                Choose a page or book a free trial.
              </Dialog.Description>
              <Dialog.Close
                className="icon-button menu-close"
                aria-label="Close navigation"
              >
                <X />
              </Dialog.Close>
              <nav aria-label="Mobile navigation">
                {links.map(({ href, label }) => (
                  <Dialog.Close asChild key={href + label}>
                    <Link href={href}>{label}</Link>
                  </Dialog.Close>
                ))}
              </nav>
              <Dialog.Close asChild>
                <Link href="/free-trial" className="button button-primary">
                  {messages.trial}
                </Link>
              </Dialog.Close>
            </Dialog.Content>
          </Dialog.Portal>
        </Dialog.Root>
      </div>
    </header>
  );
}
