import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
export function EmptyState({ title, description }) {
  return (
    <div className="empty-state">
      <div className="empty-symbol" aria-hidden="true">
        ✧
      </div>
      <h2>{title}</h2>
      <p>{description}</p>
      <Link href="/contact" className="button button-secondary">
        Contact our team
        <ArrowUpRight size={16} />
      </Link>
    </div>
  );
}
