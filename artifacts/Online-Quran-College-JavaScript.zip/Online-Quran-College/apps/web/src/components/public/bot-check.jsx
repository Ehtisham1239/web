"use client";
import Script from "next/script";
import { useEffect, useRef, useState } from "react";
export function BotCheck({ siteKey, onToken, allowWithoutProvider = false }) {
  const root = useRef(null),
    callback = useRef(onToken);
  const [ready, setReady] = useState(false),
    [error, setError] = useState(false);
  useEffect(() => {
    callback.current = onToken;
  }, [onToken]);
  useEffect(() => {
    if (!ready || !siteKey || !root.current || !window.turnstile) return;
    const provider = window.turnstile;
    const id = provider.render(root.current, {
      sitekey: siteKey,
      callback: (token) => {
        setError(false);
        callback.current(token);
      },
      "expired-callback": () => callback.current(""),
      "error-callback": () => {
        callback.current("");
        setError(true);
      },
    });
    return () => provider.remove(id);
  }, [ready, siteKey]);
  if (!siteKey && allowWithoutProvider) return null;
  if (!siteKey)
    return process.env.NODE_ENV === "production" ? (
      <p role="status">
        Applications are awaiting secure form configuration. Please use the
        published contact information.
      </p>
    ) : null;
  return (
    <div>
      <Script
        id="oqc-turnstile"
        src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit"
        strategy="afterInteractive"
        onReady={() => setReady(true)}
        onError={() => setError(true)}
      />
      <div ref={root} />
      {error && (
        <p className="field-error" role="alert">
          Verification could not load. Refresh this page to try again.
        </p>
      )}
    </div>
  );
}
