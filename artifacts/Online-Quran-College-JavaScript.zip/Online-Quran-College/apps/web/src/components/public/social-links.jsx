import { publicSettings } from "@/server/services/public";
import { settingSchemas } from "@/lib/validation/content";
export async function PublicSocialLinks() {
  const value = (await publicSettings()).find(
      (item) => item.key === "social.links",
    )?.value,
    parsed = settingSchemas["social.links"].safeParse(value);
  if (!parsed.success || !parsed.data.length) return null;
  return (
    <nav aria-label="Social profiles">
      {parsed.data.map((item, index) => (
        <a
          key={index}
          href={item.url}
          target="_blank"
          rel="noopener noreferrer"
        >
          {item.label}
          <span className="sr-only"> (opens in a new tab)</span>
        </a>
      ))}
    </nav>
  );
}
