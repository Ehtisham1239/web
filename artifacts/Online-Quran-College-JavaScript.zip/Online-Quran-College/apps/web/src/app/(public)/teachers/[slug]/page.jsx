import { notFound } from "next/navigation";
import Link from "next/link";
import { publicTeacher } from "@/server/services/public";
import { pageMetadata } from "@/lib/platform/seo";
export async function generateMetadata({ params }) {
  const slug = (await params).slug,
    teacher = await publicTeacher(slug);
  if (!teacher) notFound();
  return pageMetadata(
    teacher.displayName,
    teacher.bio.slice(0, 160),
    "/teachers/" + slug,
  );
}
export const dynamic = "force-dynamic";
export default async function TeacherPage({ params }) {
  const teacher = await publicTeacher((await params).slug);
  if (!teacher) notFound();
  return (
    <div className="container">
      <div className="page-title">
        <Link href="/teachers" className="breadcrumbs">
          ← Teachers
        </Link>
        <h1>{teacher.displayName}</h1>
      </div>
      <div className="page-content">
        <p>{teacher.bio}</p>
        {teacher.qualificationsText && (
          <section className="card">
            <h2>Reviewed qualifications</h2>
            <p>{teacher.qualificationsText}</p>
          </section>
        )}
        <p>Languages: {teacher.languages.join(", ")}</p>
        <Link href="/free-trial" className="button button-primary">
          Book a Free Trial
        </Link>
      </div>
    </div>
  );
}
