import { Header } from "@/components/public/header";
import { Footer } from "@/components/public/footer";
import {
  publicMenu,
  publishedCourses,
  publicTeachers,
} from "@/server/services/public";
import { TopBar } from "@/components/public/top-bar";
export default async function PublicLayout({ children }) {
  const [menu, courses, teachers] = await Promise.all([
    publicMenu("HEADER"),
    publishedCourses(),
    publicTeachers(),
  ]);
  const courseGroups = [
    { category: "REGULAR", label: "Regular courses" },
    { category: "COMPLEMENTARY", label: "Complementary courses" },
  ]
    .map((group) => ({
      label: group.label,
      links: courses
        .filter((course) => course.category === group.category)
        .slice(0, 12)
        .map((course) => ({
          href: "/courses/" + course.slug,
          label: course.title,
        })),
    }))
    .filter((group) => group.links.length);
  const teacherGroups = [
    { gender: "MALE", label: "Male teachers" },
    { gender: "FEMALE", label: "Female teachers" },
  ]
    .filter((group) =>
      teachers.some((teacher) => teacher.gender === group.gender),
    )
    .map((group) => ({
      label: group.label,
      links: [
        {
          href: "/teachers?gender=" + group.gender,
          label: "Browse " + group.label.toLowerCase(),
        },
      ],
    }));
  return (
    <>
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>
      <TopBar />
      <Header
        items={menu}
        courseGroups={courseGroups}
        teacherGroups={teacherGroups}
      />
      <main id="main-content" tabIndex={-1}>
        {children}
      </main>
      <Footer />
    </>
  );
}
