import { publicPageLabels } from "@/lib/content/public-pages";
import { CatalogListing } from "@/components/public/catalog-listing";
import { ContactDetails } from "@/components/public/contact-details";
import { pageMetadata, breadcrumbData, jsonLd } from "@/lib/platform/seo";
import { activeConsent } from "@/server/services/consent";
import { PageSections } from "@/components/public/page-sections";
import { botProtectionDisabledByOwner } from "@/server/services/admissions";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  publishedCourses,
  publicContent,
  publicPage,
} from "@/server/services/public";
import { EmptyState } from "@/components/public/empty-state";
import { ContactForm } from "@/components/public/contact-form";
import { TrialForm } from "@/components/public/trial-form";
import messages from "@/messages/en.json";
export const dynamic = "force-dynamic";
const labels = publicPageLabels;
const policies = [
  "privacy",
  "terms",
  "refund",
  "child-safeguarding",
  "accessibility",
  "ai-disclosure",
];
export async function generateMetadata({ params }) {
  const { slug } = await params;
  const page = await publicPage(slug);
  if (!labels[slug] && !page) notFound();
  return pageMetadata(
    page?.seoTitle || page?.title || labels[slug] || slug,
    page?.seoDescription ||
      `${labels[slug] ?? page?.title ?? slug} at Online Quran College LTD.`,
    `/${slug}`,
  );
}
export default async function ContentPage({ params, searchParams }) {
  const { slug } = await params;
  const cmsPage = await publicPage(slug);
  const allowWithoutProvider = ["contact", "free-trial"].includes(slug)
    ? await botProtectionDisabledByOwner()
    : false;
  if (!labels[slug] && !cmsPage) notFound();
  const consent = ["contact", "free-trial"].includes(slug)
    ? await activeConsent()
    : null;
  const consentAvailable = !!consent || process.env.NODE_ENV !== "production";
  const label = cmsPage?.title ?? labels[slug];
  let content;
  if (["courses", "teachers", "faq", "blog", "pricing"].includes(slug)) {
    content = (
      <CatalogListing resource={slug} searchParams={await searchParams} />
    );
  } else if (slug === "free-trial") {
    const courses = await publishedCourses();
    content = courses.length ? (
      <TrialForm
        courses={courses}
        consentVersion={consent?.version}
        consentText={consent?.trialText}
        consentAvailable={consentAvailable}
        siteKey={process.env.TURNSTILE_SITE_KEY}
        allowWithoutProvider={allowWithoutProvider}
      />
    ) : (
      <EmptyState
        title="Trial applications will open with our catalog"
        description="There are no published courses to select yet. Contact our team to discuss your interest."
      />
    );
  } else if (slug === "contact")
    content = (
      <>
        <ContactDetails />
        <ContactForm
          consentVersion={consent?.version}
          consentText={consent?.contactText}
          consentAvailable={consentAvailable}
          siteKey={process.env.TURNSTILE_SITE_KEY}
          allowWithoutProvider={allowWithoutProvider}
        />
      </>
    );
  else if (slug === "testimonials") {
    const items = await publicContent("testimonials");
    content = items.length ? (
      <div className="card-grid">
        {items.map((item) =>
          "quote" in item ? (
            <figure className="card" key={item.id}>
              <blockquote>{item.quote}</blockquote>
              <figcaption>
                {item.name}
                {item.role ? " · " + item.role : ""}
              </figcaption>
            </figure>
          ) : null,
        )}
      </div>
    ) : (
      <EmptyState
        title="No published testimonials yet"
        description={messages.empty.testimonials}
      />
    );
  } else {
    content = (
      <>
        {policies.includes(slug) && !cmsPage && (
          <div className="notice">{messages.policies}</div>
        )}
        {cmsPage ? (
          <PageSections sections={cmsPage.pageSection_pageId} />
        ) : (
          <EmptyState
            title="This information is awaiting review"
            description="Approved information will appear here once our team has reviewed and published it."
          />
        )}
      </>
    );
  }
  return (
    <div className="container">
      <div className="page-title">
        <nav className="breadcrumbs" aria-label="Breadcrumb">
          <Link href="/">Home</Link> / {label}
        </nav>
        <h1>{label}</h1>
      </div>
      <div className="page-content">{content}</div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: jsonLd(
            breadcrumbData([
              { label: "Home", path: "/" },
              { label, path: "/" + slug },
            ]),
          ),
        }}
      />
    </div>
  );
}
