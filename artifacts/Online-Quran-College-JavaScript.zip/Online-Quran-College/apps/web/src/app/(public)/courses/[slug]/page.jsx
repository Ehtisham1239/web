import { RichText } from "@/components/public/rich-text";
import { notFound, permanentRedirect } from "next/navigation";
import Link from "next/link";
import {
  publishedCourse,
  redirectFor,
  courseRecommendations,
} from "@/server/services/public";
import { pageMetadata, jsonLd, siteUrl } from "@/lib/platform/seo";
import messages from "@/messages/en.json";
export async function generateMetadata({ params }) {
  const slug = (await params).slug,
    course = await publishedCourse(slug);
  if (!course) {
    const redirect = await redirectFor("/courses/" + slug);
    if (redirect) permanentRedirect(redirect.toPath);
    notFound();
  }
  return pageMetadata(
    course.seoTitle || course.title,
    course.seoDescription || course.summary,
    "/courses/" + slug,
  );
}
export const dynamic = "force-dynamic";
export default async function CoursePage({ params }) {
  const course = await publishedCourse((await params).slug);
  if (!course) {
    const redirect = await redirectFor("/courses/" + (await params).slug);
    if (redirect) permanentRedirect(redirect.toPath);
    notFound();
  }
  const recommendations = await courseRecommendations(course);
  return (
    <div className="container">
      <div className="page-title">
        <Link className="breadcrumbs" href="/courses">
          ← Courses
        </Link>
        <h1>{course.title}</h1>
        <p>{course.summary}</p>
      </div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: jsonLd({
            "@context": "https://schema.org",
            "@type": "Course",
            name: course.title,
            description: course.summary,
            url: siteUrl("/courses/" + course.slug),
            provider: {
              "@type": "Organization",
              name: messages.brand,
              url: siteUrl("/"),
            },
          }),
        }}
      />
      <div className="page-content">
        <RichText document={course.description} />
        <span className="badge">
          {course.ageGroup} · {course.level}
        </span>
        {course.courseModule_courseId.map((module) => (
          <section className="card" key={module.id}>
            <h2>{module.title}</h2>
            <p>{module.objectives}</p>
          </section>
        ))}
        {course.durationText && (
          <section>
            <h2>Class format and duration</h2>
            <p>{course.durationText}</p>
          </section>
        )}
        {recommendations.teachers.length > 0 && (
          <section>
            <h2>Course teachers</h2>
            <div className="card-grid">
              {recommendations.teachers.map((teacher) => (
                <article className="card" key={teacher.id}>
                  <h3>
                    <Link href={"/teachers/" + teacher.slug}>
                      {teacher.displayName}
                    </Link>
                  </h3>
                  <p>{teacher.bio}</p>
                  <p>Languages: {teacher.languages.join(", ")}</p>
                </article>
              ))}
            </div>
          </section>
        )}
        {recommendations.courses.length > 0 && (
          <section>
            <h2>Related courses</h2>
            <div className="card-grid">
              {recommendations.courses.map((related) => (
                <article className="card" key={related.id}>
                  <h3>
                    <Link href={"/courses/" + related.slug}>
                      {related.title}
                    </Link>
                  </h3>
                  <p>{related.summary}</p>
                </article>
              ))}
            </div>
          </section>
        )}
        <p>
          <Link className="button button-primary" href="/free-trial">
            Book a Free Trial
          </Link>
        </p>
      </div>
    </div>
  );
}
