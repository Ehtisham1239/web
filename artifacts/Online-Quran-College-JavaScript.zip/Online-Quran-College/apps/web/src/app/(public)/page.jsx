import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import messages from "@/messages/en.json";
import { EmptyState } from "@/components/public/empty-state";
import {
  publishedCourses,
  publicTeachers,
  publicContent,
  publicPage,
  publicSettings,
} from "@/server/services/public";
import { settingSchemas } from "@/lib/validation/content";
import { PageSections } from "@/components/public/page-sections";
import { pageMetadata, jsonLd, siteUrl } from "@/lib/platform/seo";
import { readableRichText } from "@/lib/content/revision-fields";
export async function generateMetadata() {
  const cms = await publicPage("home");
  return pageMetadata(
    cms?.seoTitle || messages.brand,
    cms?.seoDescription || messages.hero.description,
    "/",
  );
}
export const dynamic = "force-dynamic";
export default async function Home() {
  const [courses, teachers, faqs, testimonials, plans, cms] = await Promise.all(
    [
      publishedCourses(),
      publicTeachers(),
      publicContent("faq"),
      publicContent("testimonials"),
      publicContent("pricing"),
      publicPage("home"),
    ],
  );
  const about = await publicPage("about");
  const aboutSection = about?.pageSection_pageId.find(
      (section) => section.type === "RICH_TEXT",
    ),
    aboutData = aboutSection?.data;
  const aboutText =
    typeof aboutData?.text === "string"
      ? aboutData.text
      : readableRichText(aboutData?.document);
  const ages = [...new Set(courses.map((course) => course.ageGroup))];
  const benefits =
    settingSchemas["site.benefits"].safeParse(
      (await publicSettings()).find((item) => item.key === "site.benefits")
        ?.value,
    ).data?.items ?? [];
  if (cms)
    return (
      <div className="container">
        <div className="page-title">
          <h1>{cms.title}</h1>
        </div>
        <div className="page-content">
          <PageSections sections={cms.pageSection_pageId} />
        </div>
      </div>
    );
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: jsonLd({
            "@context": "https://schema.org",
            "@type": "Organization",
            name: messages.brand,
            url: siteUrl("/"),
            logo: siteUrl("/brand/logo.jpg"),
          }),
        }}
      />
      <section className="container hero">
        <div>
          <span className="eyebrow">✧ {messages.hero.eyebrow}</span>
          <h1>{messages.hero.title}</h1>
          <p>{messages.hero.description}</p>
          <div className="hero-actions">
            <Link href="/free-trial" className="button button-primary">
              {messages.trial}
              <ArrowUpRight size={18} />
            </Link>
            <Link href="/courses" className="button button-secondary">
              {messages.hero.secondary}
            </Link>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="arch-outline" />
          <div className="arch-inner">
            <span className="ornament">✧</span>
          </div>
          <span className="art-caption">Space to learn · Space to grow</span>
        </div>
      </section>
      <section className="section section-white">
        <div className="container">
          <div className="section-heading">
            <div>
              <span className="eyebrow">Find your starting point</span>
              <h2>Explore our courses</h2>
            </div>
            <Link href="/courses">
              View courses{" "}
              <ArrowUpRight
                size={16}
                aria-hidden="true"
                style={{ display: "inline", verticalAlign: "middle" }}
              />
            </Link>
          </div>
          {courses.length ? (
            <div className="card-grid">
              {courses.slice(0, 6).map((course) => (
                <article className="card" key={course.id}>
                  <span className="badge">{course.level}</span>
                  <h3>{course.title}</h3>
                  <p>{course.summary}</p>
                  <Link
                    href={"/courses/" + course.slug}
                    className="button button-secondary"
                  >
                    Explore course
                  </Link>
                </article>
              ))}
            </div>
          ) : (
            <EmptyState
              title="A considered learning path"
              description={messages.empty.courses}
            />
          )}
        </div>
      </section>
      <section className="section">
        {benefits.length > 0 && (
          <div className="container">
            <h2>Why learn with us</h2>
            <div className="card-grid">
              {benefits.map((benefit, index) => (
                <article className="card" key={index}>
                  <h3>{benefit.title}</h3>
                  <p>{benefit.body}</p>
                </article>
              ))}
            </div>
          </div>
        )}
        <div className="container">
          <div className="section-heading">
            <div>
              <span className="eyebrow">One step at a time</span>
              <h2>Begin with a conversation</h2>
            </div>
          </div>
          <div className="process-grid">
            {[
              [
                "01",
                "Explore",
                "Browse the approved catalog as courses become available.",
              ],
              [
                "02",
                "Get in touch",
                "Tell our team what you would like to learn.",
              ],
              [
                "03",
                "Plan together",
                "Discuss course options, fees and timing before you decide.",
              ],
              [
                "04",
                "Confirm your next step",
                "Choose how to proceed once the details are clear.",
              ],
            ].map(([n, title, description]) => (
              <div className="process-card" key={n}>
                <span className="step-number">{n} / YOUR NEXT STEP</span>
                <h3>{title}</h3>
                <p>{description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      {ages.length > 0 && (
        <section className="container section">
          <h2>Learning options by age</h2>
          <div className="card-grid">
            {ages.map((age) => (
              <article className="card" key={age}>
                <h3>{age.replaceAll("_", " ")}</h3>
                <Link href={`/courses?ageGroup=${encodeURIComponent(age)}`}>
                  View approved courses
                </Link>
              </article>
            ))}
          </div>
        </section>
      )}
      {teachers.length > 0 && (
        <section className="container section">
          <div className="section-heading">
            <h2>Meet our teachers</h2>
            <Link href="/teachers">All teachers</Link>
          </div>
          <div className="card-grid">
            {teachers.slice(0, 4).map((teacher) => (
              <article className="card" key={teacher.id}>
                <h3>{teacher.displayName}</h3>
                <p>{teacher.bio}</p>
                <Link href={`/teachers/${teacher.slug}`}>View profile</Link>
              </article>
            ))}
          </div>
        </section>
      )}
      <section className="container section">
        <div className="pricing-band">
          <div>
            <span className="eyebrow">
              Clear information, considered choices
            </span>
            <h2>
              {plans.length ? "Explore approved plans" : messages.empty.pricing}
            </h2>
            <p>
              {plans.length
                ? "View the published fees and discuss the right plan with our team."
                : "Our team can discuss fees once a plan is approved."}
            </p>
          </div>
          <Link href="/pricing" className="button button-secondary">
            Schedule & fees
            <ArrowUpRight size={18} />
          </Link>
        </div>
      </section>
      {about && aboutText && (
        <section className="container section">
          <h2>About our approach</h2>
          <p>
            {aboutText.slice(0, 350)}
            {aboutText.length > 350 ? "…" : ""}
          </p>
          <Link href="/about">Read about our approach</Link>
        </section>
      )}
      {testimonials.length > 0 && (
        <section className="container section">
          <h2>Learning experiences</h2>
          <div className="card-grid">
            {testimonials.slice(0, 3).map((item) =>
              "quote" in item ? (
                <figure className="card" key={item.id}>
                  <blockquote>{item.quote}</blockquote>
                  <figcaption>{item.name}</figcaption>
                </figure>
              ) : null,
            )}
          </div>
        </section>
      )}
      {faqs.length > 0 && (
        <section className="container section">
          <h2>Your questions</h2>
          {faqs.slice(0, 6).map((item) =>
            "question" in item ? (
              <details className="card" key={item.id}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ) : null,
          )}
          <p>
            <Link href="/faq">All questions</Link>
          </p>
        </section>
      )}
      <section className="container">
        <div className="cta-band">
          <div>
            <span className="eyebrow" style={{ color: "#e1ebdf" }}>
              Your next chapter
            </span>
            <h2>Let’s find your next step.</h2>
            <p>Ask a question or explore the free-trial application.</p>
          </div>
          <Link href="/free-trial" className="button button-secondary">
            {messages.trial}
            <ArrowUpRight size={18} />
          </Link>
        </div>
      </section>
    </>
  );
}
