import { AcceptInvite } from "@/components/admin/accept-invite";
export default function Invitation() {
  return (
    <main className="container page-title" style={{ maxWidth: 600 }}>
      <h1>Join the staff workspace.</h1>
      <AcceptInvite />
    </main>
  );
}
