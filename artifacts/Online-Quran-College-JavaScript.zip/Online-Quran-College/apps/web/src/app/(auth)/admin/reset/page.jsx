import { ResetPassword } from "@/components/admin/reset-password";
export default function Reset() {
  return (
    <main className="container page-title" style={{ maxWidth: 600 }}>
      <h1>Reset your staff password.</h1>
      <ResetPassword />
    </main>
  );
}
