import { WorkspaceNavigation } from "@/components/admin/workspace-navigation";
import { SessionControls } from "@/components/admin/session-controls";
import Link from "next/link";
import { redirect } from "next/navigation";
import { currentSession } from "@/lib/auth/session";
import { can } from "@/lib/rbac/policy";
export const dynamic = "force-dynamic";
export const metadata = { robots: { index: false, follow: false } };
const modules = [
  "settings",
  "users",
  "media",
  "blog",
  "courses",
  "teachers",
  "trials",
  "contact-messages",
  "pages",
  "faqs",
  "testimonials",
  "pricing-plans",
  "students",
  "guardians",
  "enrollments",
  "schedules",
  "sessions",
  "attendance",
  "progress",
  "invoices",
  "payments",
  "audit-logs",
  "notifications",
];
export default async function AdminLayout({ children }) {
  const session = await currentSession();
  if (!session) redirect("/admin/login");
  return (
    <div className="admin-shell">
      <aside className="admin-sidebar">
        <Link href="/admin" className="brand">
          <span className="brand-name">ONLINE QURAN</span>
          <span className="brand-sub">STAFF WORKSPACE</span>
        </Link>
        <WorkspaceNavigation
          items={[
            { href: "/admin", label: "Overview" },
            { href: "/admin/account", label: "Your account" },
            ...(can(session.user.role.key, "invoices:read")
              ? [{ href: "/admin/overdue", label: "Overdue invoices" }]
              : []),
            ...(can(session.user.role.key, "sessions:read")
              ? [{ href: "/admin/calendar", label: "Class calendar" }]
              : []),
            ...([
              "reports:read",
              "reports:admissions",
              "reports:academic",
              "reports:content",
            ].some((key) => can(session.user.role.key, key))
              ? [{ href: "/admin/reports", label: "Reports" }]
              : []),
            ...modules
              .filter((module) => can(session.user.role.key, module + ":read"))
              .map((module) => ({
                href: "/admin/" + module,
                label: module.replaceAll("-", " "),
              })),
          ]}
        />
        <SessionControls name={session.user.name} />
      </aside>
      <main className="admin-main" id="main-content">
        {children}
      </main>
    </div>
  );
}
