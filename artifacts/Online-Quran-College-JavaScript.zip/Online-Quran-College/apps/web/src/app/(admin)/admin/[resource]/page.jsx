import { enrollmentChoices } from "@/server/services/enrollments";
import { EnrollmentForm } from "@/components/admin/enrollment-form";
import { requirePagePermission } from "@/lib/auth/page";
import { can } from "@/lib/rbac/policy";
import { listRecords, guardianOptions } from "@/server/services/admin";
import { RecordEditor, RecordActions } from "@/components/admin/record-editor";
import { MediaUpload } from "@/components/admin/media-upload";
import { OperationalForm } from "@/components/admin/operational-form";
import { enrollmentOptions } from "@/server/services/academics";
import { unpaidInvoices } from "@/server/services/finance";
import { formatMinor } from "@/lib/platform/money";
import Link from "next/link";
import { recordFields as fields } from "@/components/admin/record-fields";
export default async function Records({ params, searchParams }) {
  const { resource } = await params;
  const session = await requirePagePermission(resource + ":read");
  const page = Math.max(1, Number((await searchParams).page) || 1);
  const result = await listRecords(resource, page, 20, session.userId);
  const admissionChoices =
    resource === "enrollments" &&
    can(session.user.role.key, "enrollments:create")
      ? await enrollmentChoices()
      : null;
  const operational =
    ["schedules", "invoices", "payments", "progress"].includes(resource) &&
    can(session.user.role.key, resource + ":create");
  const enrollments =
    operational && resource !== "payments" ? await enrollmentOptions() : [];
  const invoices =
    operational && resource === "payments" ? await unpaidInvoices() : [];
  const choices =
    resource === "payments"
      ? invoices.map((invoice) => ({
          id: invoice.id,
          currency: invoice.currency,
          label:
            invoice.number +
            " · " +
            invoice.enrollment.student.fullName +
            " · " +
            formatMinor(
              invoice.totalMinor -
                invoice.paymentRecord_invoiceId.reduce(
                  (sum, payment) => sum + payment.amountMinor,
                  0,
                ),
              invoice.currency,
            ) +
            " remaining",
        }))
      : enrollments.map((item) => ({
          id: item.id,
          label:
            item.student.fullName +
            " · " +
            item.course.title +
            " · " +
            item.teacher.displayName +
            " · " +
            item.student.timezone,
        }));
  const configuredColumns = {
    menus: ["menu", "label", "href", "sortOrder"],
    invoices: ["number", "currency", "totalMinor", "status", "dueAt"],
    payments: ["amountMinor", "method", "reference", "receivedAt"],
    schedules: ["weekday", "startMinute", "durationMin", "timezone"],
    sessions: ["kind", "startsAtUtc", "endsAtUtc", "status"],
    attendance: ["status", "note", "createdAt"],
    progress: ["summary", "lessonRef", "createdAt"],
    enrollments: ["studentId", "courseId", "startDate", "status"],
    notifications: ["kind", "createdAt", "readAt"],
  };
  const columns =
    configuredColumns[resource] ??
    (resource === "media"
      ? ["altText", "mimeType", "sizeBytes", "status"]
      : resource === "trials"
        ? ["reference", "learnerName", "status"]
        : resource === "contact-messages"
          ? ["name", "subject", "status"]
          : resource === "audit-logs"
            ? ["action", "entityType", "createdAt"]
            : ["title", "name", "displayName", "fullName", "status"].filter(
                (column) => result.data.some((item) => column in item),
              ));
  const guardians =
    resource === "students" && can(session.user.role.key, "guardians:read")
      ? await guardianOptions()
      : [];
  const createFields =
    resource === "students"
      ? [
          ...fields.students,
          {
            key: "guardianId",
            label: "Guardian",
            type: "select",
            options: [
              { value: "", label: "Choose a guardian (required under 18)" },
              ...guardians.map((item) => ({
                value: item.id,
                label: item.fullName,
              })),
            ],
          },
        ]
      : fields[resource];
  return (
    <>
      <nav className="breadcrumbs">
        <Link href="/admin">Overview</Link> / {resource.replaceAll("-", " ")}
      </nav>
      <h1 style={{ textTransform: "capitalize" }}>
        {resource.replaceAll("-", " ")}
      </h1>
      {resource === "media" && can(session.user.role.key, "media:create") && (
        <MediaUpload />
      )}
      {createFields && can(session.user.role.key, resource + ":create") && (
        <RecordEditor resource={resource} fields={createFields} />
      )}
      {admissionChoices && (
        <EnrollmentForm
          key={String(result.meta.total)}
          choices={admissionChoices}
        />
      )}
      {operational && (
        <OperationalForm
          resource={resource}
          choices={choices}
          timezone={enrollments[0]?.student.timezone}
        />
      )}
      <div className="card table-scroll">
        {result.data.length ? (
          <table className="data-table">
            <caption>{result.meta.total} records</caption>
            <thead>
              <tr>
                {columns.map((column) => (
                  <th scope="col" key={column}>
                    {column}
                  </th>
                ))}
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {result.data.map((item) => (
                <tr key={item.id}>
                  {columns.map((column) => (
                    <td key={column}>{String(item[column] ?? "—")}</td>
                  ))}
                  <td>
                    <Link href={`/admin/${resource}/${item.id}`}>
                      Open record
                    </Link>
                    {item.status &&
                    item.version &&
                    [
                      "blog",
                      "courses",
                      "pages",
                      "faqs",
                      "testimonials",
                      "pricing-plans",
                    ].includes(resource) &&
                    (can(session.user.role.key, resource + ":publish") ||
                      (item.status === "DRAFT" &&
                        can(session.user.role.key, resource + ":submit"))) ? (
                      <RecordActions
                        resource={resource}
                        id={item.id}
                        status={item.status}
                        version={item.version}
                      />
                    ) : (
                      <span>—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="empty-state">
            <h2>No records yet</h2>
            <p>Records will appear here when authorized staff add them.</p>
          </div>
        )}
      </div>
      <nav aria-label="Pagination" className="toolbar">
        {page > 1 && <Link href={"?page=" + (page - 1)}>Previous</Link>}
        <span>Page {page}</span>
        {page * 20 < result.meta.total && (
          <Link href={"?page=" + (page + 1)}>Next</Link>
        )}
      </nav>
    </>
  );
}
