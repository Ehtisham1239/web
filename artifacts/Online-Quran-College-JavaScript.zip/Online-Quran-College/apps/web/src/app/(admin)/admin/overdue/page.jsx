import Link from "next/link";
import { requirePagePermission } from "@/lib/auth/page";
import { overdueInvoices } from "@/server/services/finance";
import { formatMinor } from "@/lib/platform/money";
export default async function Overdue() {
  await requirePagePermission("invoices:read");
  const result = await overdueInvoices();
  return (
    <>
      <nav className="breadcrumbs">
        <Link href="/admin/invoices">Invoices</Link> / Overdue
      </nav>
      <h1>Overdue invoices</h1>
      <p>
        Issued invoices past their due time, with recorded payments deducted.
        Checked at {result.asOf} (UTC).
      </p>
      {result.truncated && (
        <p role="status">Showing the oldest 200 overdue invoices.</p>
      )}
      <div className="card table-scroll">
        {result.data.length ? (
          <table className="data-table">
            <caption>Outstanding balances in each invoice currency</caption>
            <thead>
              <tr>
                <th scope="col">Invoice</th>
                <th scope="col">Learner</th>
                <th scope="col">Due at (UTC)</th>
                <th scope="col">Outstanding</th>
              </tr>
            </thead>
            <tbody>
              {result.data.map((invoice) => (
                <tr key={invoice.id}>
                  <td>
                    <Link href={`/admin/invoices/${invoice.id}`}>
                      {invoice.number}
                    </Link>
                  </td>
                  <td>{invoice.learner}</td>
                  <td>{invoice.dueAt}</td>
                  <td>
                    {formatMinor(invoice.balanceMinor, invoice.currency)} (
                    {invoice.currency})
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No overdue invoices.</p>
        )}
      </div>
    </>
  );
}
