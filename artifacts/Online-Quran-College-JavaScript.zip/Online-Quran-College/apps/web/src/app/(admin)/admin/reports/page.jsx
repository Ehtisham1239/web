import { requirePagePermission } from "@/lib/auth/page";
import { currentSession } from "@/lib/auth/session";
import { redirect } from "next/navigation";
import { can } from "@/lib/rbac/policy";
import { reportingSummary, exportPermissions } from "@/server/services/reports";
import { ExportForm } from "@/components/admin/export-form";
import { Reauthenticate } from "@/components/admin/users";
import { formatMinor } from "@/lib/platform/money";
function Counts({ items }) {
  return items.length ? (
    <dl>
      {items.map((item) => (
        <div className="field" key={item.status}>
          <dt>{item.status.toLowerCase().replaceAll("_", " ")}</dt>
          <dd>{item.count}</dd>
        </div>
      ))}
    </dl>
  ) : (
    <p>No records in this report yet.</p>
  );
}
export default async function Reports() {
  const session = await currentSession();
  if (!session) redirect("/admin/login");
  const permission = [
    "reports:read",
    "reports:admissions",
    "reports:academic",
    "reports:content",
  ].find((key) => can(session.user.role.key, key));
  await requirePagePermission(permission ?? "reports:read");
  const report = await reportingSummary(session.user.role.key),
    resources = Object.entries(exportPermissions)
      .filter(
        ([, key]) =>
          can(session.user.role.key, "exports:all") ||
          can(session.user.role.key, key),
      )
      .map(([key]) => key);
  return (
    <>
      <h1>Reports</h1>
      <p>These figures are calculated from stored college records.</p>
      <div className="card-grid">
        {report.admissions && (
          <section className="card">
            <h2>Admissions</h2>
            <Counts items={report.admissions.states} />
            <p>
              {report.admissions.duplicateCount} applications flagged for
              duplicate review.
            </p>
          </section>
        )}
        {report.academic && (
          <section className="card">
            <h2>Academic operations</h2>
            <p>{report.academic.activeEnrollments} active enrollments.</p>
            <p>
              {report.academic.upcomingClasses} planned classes in the next
              seven days.
            </p>
            <h3>Attendance</h3>
            <Counts items={report.academic.attendance} />
          </section>
        )}
        {report.content && (
          <section className="card">
            <h2>Content</h2>
            <h3>Courses</h3>
            <Counts items={report.content.courses} />
            <h3>Pages</h3>
            <Counts items={report.content.pages} />
          </section>
        )}
        {report.finance && (
          <section className="card">
            <h2>Invoices by currency</h2>
            {report.finance.invoices.length ? (
              report.finance.invoices.map((item) => (
                <p key={item.currency + item.status}>
                  {item.currency} · {item.status.toLowerCase()} · {item.count}{" "}
                  invoices · {formatMinor(item.amountMinor, item.currency)}
                </p>
              ))
            ) : (
              <p>No invoices yet.</p>
            )}
          </section>
        )}
      </div>
      {resources.length > 0 && (
        <>
          <ExportForm resources={resources} />
          <Reauthenticate />
        </>
      )}
    </>
  );
}
