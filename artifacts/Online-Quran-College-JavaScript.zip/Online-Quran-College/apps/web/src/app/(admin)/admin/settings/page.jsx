import { activeConsent } from "@/server/services/consent";
import { ConsentEditor } from "@/components/admin/consent-editor";
import { requirePagePermission } from "@/lib/auth/page";
import { can } from "@/lib/rbac/policy";
import { settings, launchReadiness } from "@/server/services/content";
import { SettingsEditor } from "@/components/admin/settings-editor";
import { Reauthenticate } from "@/components/admin/users";
import { SocialLinks } from "@/components/admin/social-links";
import { SiteBenefits } from "@/components/admin/site-benefits";
import { settingSchemas } from "@/lib/validation/content";
export default async function Settings() {
  const session = await requirePagePermission("settings:read");
  const [items, checklist, consent] = await Promise.all([
    settings(),
    launchReadiness(),
    activeConsent(),
  ]);
  return (
    <>
      <h1>College settings</h1>
      <p>Leave unknown information empty until the owner provides it.</p>
      <section className="card">
        <h2>Launch review</h2>
        <ul>
          {checklist.map((item) => (
            <li key={item.key}>
              {item.passed ? "Complete" : "Pending"} · {item.label}
            </li>
          ))}
        </ul>
      </section>
      {can(session.user.role.key, "settings:update") && (
        <>
          <SettingsEditor
            security={can(session.user.role.key, "settings:security")}
            values={Object.fromEntries(
              items.map((item) => [item.key, item.value]),
            )}
          />
          <SocialLinks
            initial={
              settingSchemas["social.links"].safeParse(
                items.find((item) => item.key === "social.links")?.value,
              ).data ?? []
            }
          />
          <SiteBenefits
            key={JSON.stringify(
              items.find((item) => item.key === "site.benefits")?.value ?? {},
            )}
            initial={
              settingSchemas["site.benefits"].safeParse(
                items.find((item) => item.key === "site.benefits")?.value,
              ).data?.items ?? []
            }
          />
          {can(session.user.role.key, "settings:security") && (
            <ConsentEditor key={consent?.version ?? "none"} current={consent} />
          )}
          <Reauthenticate />
        </>
      )}
    </>
  );
}
