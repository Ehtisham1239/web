import { NextIntlClientProvider } from "next-intl";
import messages from "@/messages/en.json";
import "./globals.css";
import { HydrationMarker } from "@/components/hydration-marker";
import { siteUrl } from "@/lib/platform/seo";
import { publicIndexingAllowed } from "@/lib/platform/indexing";
import localFont from "next/font/local";
const outfit = localFont({
  src: [
    {
      path: "../../node_modules/@fontsource/outfit/files/outfit-latin-500-normal.woff2",
      weight: "500",
    },
    {
      path: "../../node_modules/@fontsource/outfit/files/outfit-latin-600-normal.woff2",
      weight: "600",
    },
  ],
  variable: "--font-outfit",
  display: "swap",
  preload: true,
});
const inter = localFont({
  src: [
    {
      path: "../../node_modules/@fontsource/inter/files/inter-latin-400-normal.woff2",
      weight: "400",
    },
    {
      path: "../../node_modules/@fontsource/inter/files/inter-latin-500-normal.woff2",
      weight: "500",
    },
    {
      path: "../../node_modules/@fontsource/inter/files/inter-latin-600-normal.woff2",
      weight: "600",
    },
  ],
  variable: "--font-inter",
  display: "swap",
  preload: false,
});
const siteMetadata = {
  metadataBase: new URL(siteUrl("/")),
  title: { default: messages.brand, template: "%s | " + messages.brand },
  description:
    "Explore approved learning options and contact Online Quran College LTD.",
  icons: { icon: { url: "/brand/logo.jpg", type: "image/jpeg" } },
  robots: { index: false, follow: false },
};
export async function generateMetadata() {
  const approved = await publicIndexingAllowed();
  return { ...siteMetadata, robots: { index: approved, follow: approved } };
}
export default function RootLayout({ children }) {
  return (
    <html lang="en" dir="ltr">
      <body className={`${outfit.variable} ${inter.variable}`}>
        <NextIntlClientProvider locale="en" messages={messages}>
          <HydrationMarker />
          {children}
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
export const dynamic = "force-dynamic";
