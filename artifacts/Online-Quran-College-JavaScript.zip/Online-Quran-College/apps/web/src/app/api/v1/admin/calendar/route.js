import { api } from "@/lib/platform/http";
import { requirePermission } from "@/lib/auth/session";
import { classCalendar } from "@/server/services/calendar";
export function GET(request) {
  return api(async () => {
    await requirePermission("sessions:read");
    return Response.json({
      data: await classCalendar(
        Object.fromEntries(new URL(request.url).searchParams),
      ),
    });
  });
}
