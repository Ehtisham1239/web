import { clientAddress } from "@/lib/platform/client-ip";
import { api, parseBody } from "@/lib/platform/http";
import { contactSchema } from "@/lib/validation/admissions";
import { requireOrigin } from "@/lib/auth/session";
import { privateHash } from "@/lib/auth/crypto";
import { submitContact } from "@/server/services/admissions";
export function POST(request) {
  return api(async () => {
    requireOrigin(request);
    const input = await parseBody(request, contactSchema);
    return Response.json(
      { data: await submitContact(input, privateHash(clientAddress(request))) },
      { status: 201 },
    );
  });
}
