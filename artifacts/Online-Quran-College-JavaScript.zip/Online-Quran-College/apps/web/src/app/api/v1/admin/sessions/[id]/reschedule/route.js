import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { rescheduleSchema } from "@/lib/validation/class-session";
import { rescheduleSession } from "@/server/services/class-sessions";
export function POST(request, { params }) {
  return api(async () => {
    const actor = await requireMutation(request, "sessions:update");
    return Response.json({
      data: await rescheduleSession(
        z.uuid().parse((await params).id),
        await parseBody(request, rescheduleSchema),
        actor.userId,
      ),
    });
  });
}
