import { api } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { markNotificationRead } from "@/server/services/notifications";
import { z } from "zod";
export function POST(request, { params }) {
  return api(async () => {
    const session = await requireMutation(request, "notifications:read");
    return Response.json({
      data: await markNotificationRead(
        z.uuid().parse((await params).id),
        session.userId,
      ),
    });
  });
}
