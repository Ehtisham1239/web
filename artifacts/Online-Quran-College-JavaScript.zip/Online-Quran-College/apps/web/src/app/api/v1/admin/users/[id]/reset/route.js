import { api } from "@/lib/platform/http";
import { requireMutation, requireRecentAuth } from "@/lib/auth/session";
import { issuePasswordReset } from "@/server/services/users";
import { z } from "zod";
import { rateLimit } from "@/lib/ratelimit";
export function POST(request, { params }) {
  return api(async () => {
    const session = await requireMutation(request, "users:update");
    requireRecentAuth(session);
    await rateLimit("reset-issue:" + session.userId, 5, 900);
    return Response.json({
      data: await issuePasswordReset(
        z.uuid().parse((await params).id),
        session.userId,
        session.user.role.key,
      ),
    });
  });
}
