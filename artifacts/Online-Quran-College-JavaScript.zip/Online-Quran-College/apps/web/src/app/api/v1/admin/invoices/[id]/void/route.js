import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation, requireRecentAuth } from "@/lib/auth/session";
import { invoiceVoidSchema } from "@/lib/validation/invoice-void";
import { voidInvoice } from "@/server/services/finance";
export function POST(request, { params }) {
  return api(async () => {
    const actor = await requireMutation(request, "invoices:update");
    requireRecentAuth(actor);
    return Response.json({
      data: await voidInvoice(
        z.uuid().parse((await params).id),
        await parseBody(request, invoiceVoidSchema),
        actor.userId,
      ),
    });
  });
}
