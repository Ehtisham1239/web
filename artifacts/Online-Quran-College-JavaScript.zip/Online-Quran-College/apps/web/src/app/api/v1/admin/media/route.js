import { api } from "@/lib/platform/http";
import { requireMutation, requirePermission } from "@/lib/auth/session";
import { AppError } from "@/lib/platform/errors";
import { maxImageBytes } from "@/lib/media/images";
import { uploadImage } from "@/server/services/media";
import { listRecords } from "@/server/services/admin";
export function GET() {
  return api(async () => {
    const session = await requirePermission("media:read");
    return Response.json(await listRecords("media", 1, 20, session.userId));
  });
}
export function POST(request) {
  return api(async () => {
    const session = await requireMutation(request, "media:create");
    if (!request.headers.get("content-type")?.startsWith("multipart/form-data"))
      throw new AppError("VALIDATION_ERROR", 400, "Choose an image file.");
    const limit = maxImageBytes + 10000;
    if (Number(request.headers.get("content-length") ?? 0) > limit)
      throw new AppError("PAYLOAD_TOO_LARGE", 413, "This file is too large.");
    const reader = request.body?.getReader();
    if (!reader) throw new AppError("VALIDATION_ERROR", 400, "Choose a file.");
    const chunks = [];
    let size = 0;
    while (true) {
      const part = await reader.read();
      if (part.done) break;
      size += part.value.length;
      if (size > limit) {
        await reader.cancel();
        throw new AppError("PAYLOAD_TOO_LARGE", 413, "This file is too large.");
      }
      chunks.push(part.value);
    }
    const form = await new Response(Buffer.concat(chunks), {
      headers: { "Content-Type": request.headers.get("content-type") },
    })
      .formData()
      .catch(() => null);
    const file = form?.get("file"),
      alt = form?.get("altText");
    if (
      !(file instanceof File) ||
      typeof alt !== "string" ||
      alt.trim().length < 2 ||
      alt.length > 300 ||
      [...form.keys()].some((key) => !["file", "altText"].includes(key))
    )
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Choose an image and add descriptive alternative text.",
      );
    return Response.json(
      {
        data: await uploadImage(
          new Uint8Array(await file.arrayBuffer()),
          alt.trim(),
          session.userId,
        ),
      },
      { status: 201 },
    );
  });
}
