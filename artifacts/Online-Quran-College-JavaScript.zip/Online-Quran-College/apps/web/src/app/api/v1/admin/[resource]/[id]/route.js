import { api, parseBody } from "@/lib/platform/http";
import { requirePermission, requireMutation } from "@/lib/auth/session";
import { adminSchemas, isEditableResource } from "@/lib/validation/admin";
import { can } from "@/lib/rbac/policy";
import { AppError } from "@/lib/platform/errors";
import { getRecord, updateRecord, deleteRecord } from "@/server/services/admin";
import { z } from "zod";
function checkId(id) {
  if (!z.uuid().safeParse(id).success)
    throw new AppError("VALIDATION_ERROR", 400, "Invalid record identifier.");
}
export async function GET(request, { params }) {
  return api(async () => {
    const { resource, id } = await params;
    const session = await requirePermission(resource + ":read");
    checkId(id);
    return Response.json({
      data: await getRecord(resource, id, session.userId),
    });
  });
}
export async function PATCH(request, { params }) {
  return api(async () => {
    const { resource, id } = await params;
    checkId(id);
    const permission =
      resource === "courses" || resource === "teachers"
        ? resource + ":update-content"
        : resource + ":update";
    let session;
    try {
      session = await requireMutation(request, resource + ":update");
    } catch (error) {
      if (error instanceof AppError && error.status === 403)
        session = await requireMutation(request, permission);
      else throw error;
    }
    if (!isEditableResource(resource))
      throw new AppError("FORBIDDEN", 403, "Use the dedicated workflow.");
    const schema = adminSchemas[resource]
      .partial()
      .extend({ version: z.number().int().positive().optional() })
      .strict();
    const { version, ...input } = await parseBody(request, schema);
    if (!can(session.user.role.key, resource + ":update")) {
      const allowed =
        resource === "courses"
          ? ["title", "summary", "description", "seoTitle", "seoDescription"]
          : ["bio", "qualificationsText"];
      if (Object.keys(input).some((key) => !allowed.includes(key)))
        throw new AppError(
          "FORBIDDEN",
          403,
          "You can only update content fields.",
        );
    }
    return Response.json({
      data: await updateRecord(resource, id, input, session.userId, version),
    });
  });
}
export async function DELETE(request, { params }) {
  return api(async () => {
    const { resource, id } = await params;
    const session = await requireMutation(request, resource + ":delete");
    checkId(id);
    if (!isEditableResource(resource))
      throw new AppError("FORBIDDEN", 403, "Use the dedicated workflow.");
    const body = await parseBody(
      request,
      z.object({ version: z.number().int().positive().optional() }).strict(),
    );
    await deleteRecord(resource, id, session.userId, body.version);
    return new Response(null, { status: 204 });
  });
}
