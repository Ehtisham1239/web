import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requirePermission, requireMutation } from "@/lib/auth/session";
import { AppError } from "@/lib/platform/errors";
import {
  schedulePublicationSchema,
  cancelPublicationSchema,
} from "@/lib/validation/publication-schedule";
import {
  scheduledResource,
  scheduledPublication,
  schedulePublication,
  cancelPublication,
} from "@/server/services/publication-schedules";
export function GET(request, { params }) {
  return api(async () => {
    const { resource, id } = await params;
    if (!scheduledResource(resource))
      throw new AppError("NOT_FOUND", 404, "Publication workflow not found.");
    await requirePermission(resource + ":read");
    return Response.json({
      data: await scheduledPublication(resource, z.uuid().parse(id)),
    });
  });
}
export function POST(request, { params }) {
  return api(async () => {
    const { resource, id } = await params;
    if (!scheduledResource(resource))
      throw new AppError("NOT_FOUND", 404, "Publication workflow not found.");
    const actor = await requireMutation(request, resource + ":publish");
    return Response.json({
      data: await schedulePublication(
        resource,
        z.uuid().parse(id),
        await parseBody(request, schedulePublicationSchema),
        actor.userId,
      ),
    });
  });
}
export function DELETE(request, { params }) {
  return api(async () => {
    const { resource, id } = await params;
    if (!scheduledResource(resource))
      throw new AppError("NOT_FOUND", 404, "Publication workflow not found.");
    const actor = await requireMutation(request, resource + ":publish");
    const body = await parseBody(request, cancelPublicationSchema);
    return Response.json({
      data: await cancelPublication(
        resource,
        z.uuid().parse(id),
        body.version,
        actor.userId,
      ),
    });
  });
}
