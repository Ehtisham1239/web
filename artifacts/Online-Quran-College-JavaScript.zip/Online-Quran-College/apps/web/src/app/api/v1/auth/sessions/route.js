import { z } from "zod";
import { clearSessionCookie } from "@/lib/auth/cookies";
import { NextResponse } from "next/server";
import { api, parseBody } from "@/lib/platform/http";
import { currentSession, requireSessionMutation } from "@/lib/auth/session";
import { AppError } from "@/lib/platform/errors";
import {
  ownSessions,
  revokeOwnSessions,
} from "@/server/services/session-management";
export function GET() {
  return api(async () => {
    const session = await currentSession();
    if (!session) throw new AppError("UNAUTHENTICATED", 401, "Please sign in.");
    return Response.json({
      data: await ownSessions(session.userId, session.id),
    });
  });
}
export function POST(request) {
  return api(async () => {
    const session = await requireSessionMutation(request);
    const { target } = await parseBody(
      request,
      z.object({ target: z.union([z.uuid(), z.literal("all")]) }).strict(),
    );
    const response = NextResponse.json({
      data: await revokeOwnSessions(session.userId, target),
    });
    if (target === "all" || target === session.id) clearSessionCookie(response);
    return response;
  });
}
