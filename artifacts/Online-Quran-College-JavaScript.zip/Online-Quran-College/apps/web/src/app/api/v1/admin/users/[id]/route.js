import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation, requireRecentAuth } from "@/lib/auth/session";
import { updateUser } from "@/server/services/users";
import { roles } from "@/lib/rbac/policy";
import { AppError } from "@/lib/platform/errors";
export function PATCH(request, { params }) {
  return api(async () => {
    const session = await requireMutation(request, "users:update");
    requireRecentAuth(session);
    const id = (await params).id;
    if (!z.uuid().safeParse(id).success)
      throw new AppError("NOT_FOUND", 404, "Account not found.");
    const body = await parseBody(
      request,
      z.object({ role: z.enum(roles), isActive: z.boolean() }).strict(),
    );
    return Response.json({
      data: await updateUser(id, body, session.userId, session.user.role.key),
    });
  });
}
