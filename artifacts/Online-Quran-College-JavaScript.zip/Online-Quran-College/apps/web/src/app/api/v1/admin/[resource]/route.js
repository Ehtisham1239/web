import { api, parseBody } from "@/lib/platform/http";
import { requirePermission, requireMutation } from "@/lib/auth/session";
import { paginationSchema } from "@/lib/validation/common";
import { adminSchemas, isEditableResource } from "@/lib/validation/admin";
import { AppError } from "@/lib/platform/errors";
import { listRecords, createRecord } from "@/server/services/admin";
export async function GET(request, { params }) {
  return api(async () => {
    const { resource } = await params,
      session = await requirePermission(resource + ":read");
    const parsed = paginationSchema.safeParse(
      Object.fromEntries(new URL(request.url).searchParams),
    );
    if (!parsed.success)
      throw new AppError("VALIDATION_ERROR", 400, "Invalid pagination.");
    return Response.json(
      await listRecords(
        resource,
        parsed.data.page,
        parsed.data.pageSize,
        session.userId,
      ),
    );
  });
}
export async function POST(request, { params }) {
  return api(async () => {
    const { resource } = await params,
      session = await requireMutation(request, resource + ":create");
    if (!isEditableResource(resource))
      throw new AppError(
        "FORBIDDEN",
        403,
        "Use the dedicated workflow for this module.",
      );
    const input = await parseBody(request, adminSchemas[resource]);
    return Response.json(
      { data: await createRecord(resource, input, session.userId) },
      { status: 201 },
    );
  });
}
