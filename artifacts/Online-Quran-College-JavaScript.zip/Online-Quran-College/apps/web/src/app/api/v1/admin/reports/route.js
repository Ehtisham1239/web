import { api } from "@/lib/platform/http";
import { currentSession } from "@/lib/auth/session";
import { reportingSummary } from "@/server/services/reports";
import { AppError } from "@/lib/platform/errors";
export function GET() {
  return api(async () => {
    const session = await currentSession();
    if (!session) throw new AppError("UNAUTHENTICATED", 401, "Please sign in.");
    return Response.json({
      data: await reportingSummary(session.user.role.key),
    });
  });
}
