import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireOrigin } from "@/lib/auth/session";
import { password } from "@/lib/validation/common";
import { rateLimit } from "@/lib/ratelimit";
import { hashToken } from "@/lib/auth/crypto";
import { acceptInvitation } from "@/server/services/users";
export function POST(request) {
  return api(async () => {
    requireOrigin(request);
    const body = await parseBody(
      request,
      z.object({ token: z.string().min(40).max(100), password }).strict(),
    );
    await rateLimit("invite:" + hashToken(body.token), 5, 900);
    return Response.json({
      data: await acceptInvitation(body.token, body.password),
    });
  });
}
