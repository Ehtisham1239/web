import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { sessionStatusSchema } from "@/lib/validation/class-session";
import { changeSessionStatus } from "@/server/services/class-sessions";
export function PUT(request, { params }) {
  return api(async () => {
    const actor = await requireMutation(request, "sessions:update");
    return Response.json({
      data: await changeSessionStatus(
        z.uuid().parse((await params).id),
        await parseBody(request, sessionStatusSchema),
        actor.userId,
      ),
    });
  });
}
