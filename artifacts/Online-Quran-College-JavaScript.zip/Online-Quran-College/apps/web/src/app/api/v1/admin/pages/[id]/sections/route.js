import { api, parseBody } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { sectionsSchema } from "@/lib/validation/content";
import { replaceSections } from "@/server/services/content";
export function PUT(request, { params }) {
  return api(async () => {
    const session = await requireMutation(request, "pages:update");
    const body = await parseBody(request, sectionsSchema);
    return Response.json({
      data: await replaceSections((await params).id, body, session.userId),
    });
  });
}
