import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireSessionMutation } from "@/lib/auth/session";
import { reauthenticate } from "@/server/services/users";
import { rateLimit } from "@/lib/ratelimit";
export function POST(request) {
  return api(async () => {
    const session = await requireSessionMutation(request);
    await rateLimit("reauth:" + session.userId, 5, 900);
    const body = await parseBody(
      request,
      z
        .object({
          password: z.string().min(1).max(128),
          code: z.string().max(64).optional(),
        })
        .strict(),
    );
    return Response.json({
      data: await reauthenticate(
        session.id,
        session.user.email,
        body.password,
        body.code,
      ),
    });
  });
}
