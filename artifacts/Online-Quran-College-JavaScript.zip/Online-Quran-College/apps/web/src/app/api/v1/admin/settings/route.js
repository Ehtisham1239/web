import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import {
  requirePermission,
  requireMutation,
  requireRecentAuth,
} from "@/lib/auth/session";
import { AppError } from "@/lib/platform/errors";
import { settingKey, settingSchemas } from "@/lib/validation/content";
import { settings, updateSetting } from "@/server/services/content";
export function GET() {
  return api(async () => {
    await requirePermission("settings:read");
    return Response.json({ data: await settings() });
  });
}
export function PUT(request) {
  return api(async () => {
    const session = await requireMutation(request, "settings:update");
    const body = await parseBody(
      request,
      z.object({ key: z.string().max(80), value: z.unknown() }).strict(),
    );
    if (!settingKey(body.key))
      throw new AppError("VALIDATION_ERROR", 400, "Unknown setting.");
    if (
      body.key.startsWith("readiness.") ||
      body.key.startsWith("retention.") ||
      body.key.startsWith("scheduling.")
    ) {
      await requireMutation(request, "settings:security");
      requireRecentAuth(session);
    }
    const parsed = settingSchemas[body.key].safeParse(body.value);
    if (!parsed.success)
      throw new AppError("VALIDATION_ERROR", 400, "Invalid setting value.");
    return Response.json({
      data: await updateSetting(body.key, parsed.data, session.userId),
    });
  });
}
