import { NextResponse } from "next/server";
import { api, parseBody } from "@/lib/platform/http";
import { loginSchema } from "@/lib/validation/auth";
import { login } from "@/server/services/identity";
import { requireOrigin, sessionCookieName } from "@/lib/auth/session";
import { privateHash } from "@/lib/auth/crypto";
import { rateLimit } from "@/lib/ratelimit";
import { authCookiePolicy } from "@/lib/platform/env";
export function POST(request) {
  return api(async () => {
    requireOrigin(request);
    const body = await parseBody(request, loginSchema);
    await rateLimit("login:" + privateHash(body.email), 10, 900);
    const session = await login(body.email, body.password, body.code);
    const response = NextResponse.json({ data: { csrf: session.csrf } });
    response.cookies.set(sessionCookieName(), session.token, {
      httpOnly: true,
      secure: authCookiePolicy(process.env).secure,
      sameSite: "lax",
      path: "/",
      maxAge: 43200,
    });
    return response;
  });
}
