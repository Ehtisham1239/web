import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { api } from "@/lib/platform/http";
import {
  requireOrigin,
  sessionCookieName,
  currentSession,
} from "@/lib/auth/session";
import { revokeSession, validateCsrf } from "@/server/repositories/identity";
import { AppError } from "@/lib/platform/errors";
import { clearSessionCookie } from "@/lib/auth/cookies";
export function POST(request) {
  return api(async () => {
    requireOrigin(request);
    const token = (await cookies()).get(sessionCookieName())?.value;
    if (!token || !(await currentSession()))
      throw new AppError("UNAUTHENTICATED", 401, "Please sign in.");
    await validateCsrf(token, request.headers.get("x-csrf-token") ?? "");
    await revokeSession(token);
    const response = NextResponse.json({ data: { signedOut: true } });
    clearSessionCookie(response);
    return response;
  });
}
