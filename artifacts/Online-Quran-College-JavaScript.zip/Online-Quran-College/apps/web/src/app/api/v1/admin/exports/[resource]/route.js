import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireSessionMutation, requireRecentAuth } from "@/lib/auth/session";
import { can } from "@/lib/rbac/policy";
import { exportPermissions, exportRecords } from "@/server/services/reports";
import { AppError } from "@/lib/platform/errors";
import { rateLimit } from "@/lib/ratelimit";
export function POST(request, { params }) {
  return api(async () => {
    const session = await requireSessionMutation(request);
    requireRecentAuth(session);
    const { resource } = await params;
    const permission = exportPermissions[resource];
    if (
      !permission ||
      (!can(session.user.role.key, "exports:all") &&
        !can(session.user.role.key, permission))
    )
      throw new AppError(
        "FORBIDDEN",
        403,
        "This export is not available for your role.",
      );
    await rateLimit("export:" + session.userId, 10, 3600);
    const filters = await parseBody(
      request,
      z
        .object({ from: z.iso.date().optional(), to: z.iso.date().optional() })
        .strict()
        .refine(
          (value) => !value.from || !value.to || value.from <= value.to,
          "Choose an ordered date range",
        ),
    );
    const output = await exportRecords(resource, filters, session.userId);
    return new Response(output.csv, {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="oqc-${resource}.csv"`,
        "X-Export-Count": String(output.count),
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "private, no-store",
      },
    });
  });
}
