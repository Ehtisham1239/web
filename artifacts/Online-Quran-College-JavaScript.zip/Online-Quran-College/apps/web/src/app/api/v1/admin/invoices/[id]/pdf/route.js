import { z } from "zod";
import { api } from "@/lib/platform/http";
import { requireMutation, requireRecentAuth } from "@/lib/auth/session";
import { exportInvoicePdf } from "@/server/services/invoice-documents";
import { rateLimit } from "@/lib/ratelimit";
export function POST(request, { params }) {
  return api(async () => {
    const session = await requireMutation(request, "invoices:read");
    requireRecentAuth(session);
    await rateLimit("invoice-pdf:" + session.userId, 20, 3600);
    const result = await exportInvoicePdf(
      z.uuid().parse((await params).id),
      session.userId,
    );
    return new Response(new Uint8Array(result.bytes), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${result.filename}"`,
        "Cache-Control": "private, no-store",
      },
    });
  });
}
