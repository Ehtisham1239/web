import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation, requirePermission } from "@/lib/auth/session";
import { recordProgress } from "@/server/services/academics";
import { listRecords } from "@/server/services/admin";
export function GET() {
  return api(async () => {
    const session = await requirePermission("progress:read");
    return Response.json(await listRecords("progress", 1, 20, session.userId));
  });
}
export function POST(request) {
  return api(async () => {
    const session = await requireMutation(request, "progress:create");
    const body = await parseBody(
      request,
      z
        .object({
          enrollmentId: z.uuid(),
          summary: z.string().trim().min(2).max(2000),
          lessonRef: z.string().trim().max(200).optional(),
          level: z.string().trim().max(100).optional(),
        })
        .strict(),
    );
    return Response.json(
      { data: await recordProgress(body, session.userId) },
      { status: 201 },
    );
  });
}
