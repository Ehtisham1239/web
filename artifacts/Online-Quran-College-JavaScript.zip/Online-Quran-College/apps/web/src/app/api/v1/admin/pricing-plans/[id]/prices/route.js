import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { pricesSchema } from "@/lib/validation/prices";
import { replacePlanPrices } from "@/server/services/prices";
export function PUT(request, { params }) {
  return api(async () => {
    const session = await requireMutation(request, "pricing-plans:update");
    const body = await parseBody(request, pricesSchema);
    return Response.json({
      data: await replacePlanPrices(
        z.uuid().parse((await params).id),
        body,
        session.userId,
      ),
    });
  });
}
