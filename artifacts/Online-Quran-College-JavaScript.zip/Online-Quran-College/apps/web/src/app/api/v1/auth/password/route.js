import { z } from "zod";
import { clearSessionCookie } from "@/lib/auth/cookies";
import { NextResponse } from "next/server";
import { api, parseBody } from "@/lib/platform/http";
import { requireSessionMutation } from "@/lib/auth/session";
import { password } from "@/lib/validation/common";
import { changeOwnPassword } from "@/server/services/users";
import { rateLimit } from "@/lib/ratelimit";
export function POST(request) {
  return api(async () => {
    const session = await requireSessionMutation(request);
    await rateLimit("password:" + session.userId, 5, 900);
    const body = await parseBody(
      request,
      z
        .object({
          currentPassword: z.string().min(1).max(128),
          password,
          code: z.string().max(64).optional(),
        })
        .strict(),
    );
    await changeOwnPassword(
      session.userId,
      body.currentPassword,
      body.password,
      body.code,
    );
    const response = NextResponse.json({ data: { changed: true } });
    clearSessionCookie(response);
    return response;
  });
}
