import { validCronAuthorization } from "@/lib/platform/cron-auth";
import { runMaintenance } from "@/server/services/maintenance";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(request) {
  const headers = { "Cache-Control": "no-store" };
  if (
    !validCronAuthorization(
      request.headers.get("authorization"),
      process.env.CRON_SECRET,
    )
  )
    return Response.json({ error: "Unauthorized" }, { status: 401, headers });
  try {
    return Response.json(await runMaintenance(), { headers });
  } catch {
    return Response.json(
      { error: "Job failed; retry later." },
      { status: 503, headers },
    );
  }
}

// Vercel Cron sends an authenticated GET; generic schedulers can use POST.
export const GET = POST;
