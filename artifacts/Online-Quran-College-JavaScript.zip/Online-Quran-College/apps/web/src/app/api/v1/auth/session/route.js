import { cookies } from "next/headers";
import { api } from "@/lib/platform/http";
import { currentSession, sessionCookieName } from "@/lib/auth/session";
import { sessionCsrf } from "@/lib/auth/crypto";
import { validateCsrf } from "@/server/repositories/identity";
import { AppError } from "@/lib/platform/errors";
export function GET() {
  return api(async () => {
    const session = await currentSession();
    const token = (await cookies()).get(sessionCookieName())?.value;
    if (!session || !token)
      throw new AppError("UNAUTHENTICATED", 401, "Please sign in.");
    const csrf = sessionCsrf(token);
    await validateCsrf(token, csrf);
    return Response.json({
      data: {
        csrf,
        user: { name: session.user.name, role: session.user.role.key },
      },
    });
  });
}
