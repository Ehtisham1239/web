"use client";
import Link from "next/link";
import "./globals.css";
export default function GlobalError({ reset }) {
  return (
    <html lang="en" dir="ltr">
      <body>
        <main className="container page-title" id="main-content">
          <p className="eyebrow">Online Quran College LTD</p>
          <h1>We could not load this page.</h1>
          <p>Please try again or contact our team for help.</p>
          <button className="button button-primary" onClick={reset}>
            Try again
          </button>
          <p>
            <Link href="/">Go home</Link> ·{" "}
            <Link href="/contact">Contact our team</Link>
          </p>
        </main>
      </body>
    </html>
  );
}
