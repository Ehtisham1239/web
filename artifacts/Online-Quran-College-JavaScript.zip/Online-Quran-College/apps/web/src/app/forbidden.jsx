import Link from "next/link";
export default function Forbidden() {
  return (
    <main className="container section">
      <h1>Access restricted</h1>
      <p>Your staff role does not have access to this module.</p>
      <Link className="button button-secondary" href="/admin">
        Return to your workspace
      </Link>
    </main>
  );
}
