import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";

export default defineConfig([
  ...nextVitals,

  globalIgnores([
    ".next/**",
    ".next-*/**",
    "src/generated/**",
    "coverage/**",
    "next-env.d.ts",
  ]),
]);
