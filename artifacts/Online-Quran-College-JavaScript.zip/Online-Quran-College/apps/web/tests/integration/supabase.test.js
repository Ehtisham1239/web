import { beforeAll, afterAll, expect, it, vi } from "vitest";
import { readFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { randomBytes } from "node:crypto";
import pg from "pg";
import { database } from "@/lib/db";
import { postgresRateLimit } from "@/lib/ratelimit/postgres";

const name = "oqc_supabase_test_" + randomBytes(8).toString("hex");
const control = new pg.Pool({
  connectionString: "postgresql://oqc:oqc@localhost:5432/postgres",
});
let pool;
let sql;
beforeAll(async () => {
  await control.query(`CREATE DATABASE "${name}"`);
  const url = `postgresql://oqc:oqc@localhost:5432/${name}`;
  vi.stubEnv("DATABASE_URL", url);
  vi.stubEnv("DIRECT_URL", "");
  vi.stubEnv("AUTH_SECRET", randomBytes(48).toString("base64url"));
  pool = new pg.Pool({ connectionString: url });
  // Supabase often keeps extensions outside public; exercise that layout.
  await pool.query(
    "CREATE SCHEMA extensions; CREATE EXTENSION vector WITH SCHEMA extensions; CREATE EXTENSION citext WITH SCHEMA extensions; CREATE EXTENSION pg_trgm WITH SCHEMA extensions; CREATE EXTENSION btree_gist WITH SCHEMA extensions;",
  );
  sql = await readFile("../../supabase/schema.sql", "utf8");
  await pool.query(sql);
}, 30000);

afterAll(async () => {
  await database().$disconnect();
  await pool?.end();
  await control.query(`DROP DATABASE IF EXISTS "${name}" WITH (FORCE)`);
  await control.end();
  vi.unstubAllEnvs();
});

it("applies the exported SQL twice without duplicating or losing data", async () => {
  await pool.query(sql);
  expect(
    Number(
      (await pool.query("SELECT count(*) FROM _prisma_migrations")).rows[0]
        .count,
    ),
  ).toBe(5);
  expect(
    Number((await pool.query('SELECT count(*) FROM "Role"')).rows[0].count),
  ).toBe(5);
  expect(
    Number((await pool.query('SELECT count(*) FROM "User"')).rows[0].count),
  ).toBe(0);
  expect(() =>
    execFileSync(process.execPath, ["scripts/migrate.mjs"], {
      env: process.env,
      timeout: 20000,
      stdio: "pipe",
    }),
  ).not.toThrow();
}, 30000);

it("protects all application tables with RLS and no public privileges", async () => {
  const tables = await pool.query(
    `SELECT c.relname, c.relrowsecurity FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind='r'`,
  );
  expect(tables.rows.length).toBeGreaterThan(40);
  expect(tables.rows.every((table) => table.relrowsecurity)).toBe(true);
  const publicGrants = await pool.query(
    `SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace CROSS JOIN LATERAL aclexplode(c.relacl) a WHERE n.nspname='public' AND c.relkind='r' AND a.grantee=0`,
  );
  expect(publicGrants.rows).toEqual([]);
});

it("enforces a shared atomic limit across concurrent requests and resets expired windows", async () => {
  const outcomes = await Promise.allSettled(
    Array.from({ length: 12 }, () =>
      postgresRateLimit("concurrent-check", 5, 60),
    ),
  );
  expect(
    outcomes.filter((result) => result.status === "fulfilled"),
  ).toHaveLength(5);
  expect(
    outcomes
      .filter((result) => result.status === "rejected")
      .every((result) => result.reason.code === "RATE_LIMITED"),
  ).toBe(true);
  await pool.query(
    'UPDATE "RateLimitBucket" SET "expiresAt" = now() - interval \'1 second\'',
  );
  await expect(
    postgresRateLimit("concurrent-check", 5, 60),
  ).resolves.toBeUndefined();
});

it("fails closed when rate-limit storage is unavailable", async () => {
  await pool.query(
    'ALTER TABLE "RateLimitBucket" RENAME TO "RateLimitOffline"',
  );
  try {
    await expect(
      postgresRateLimit("unavailable-check", 5, 60),
    ).rejects.toMatchObject({ code: "RATE_LIMIT_UNAVAILABLE", status: 503 });
  } finally {
    await pool.query(
      'ALTER TABLE "RateLimitOffline" RENAME TO "RateLimitBucket"',
    );
  }
});
