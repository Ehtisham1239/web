import { it, expect } from "vitest";
import { calendarRange } from "@/server/repositories/calendar";
it("calendar windows follow local DST boundaries rather than fixed UTC hours", () => {
  const spring = calendarRange({
    from: "2030-03-10",
    timezone: "America/New_York",
    days: "1",
  });
  const fall = calendarRange({
    from: "2030-11-03",
    timezone: "America/New_York",
    days: "1",
  });
  expect(
    (spring.endsAtUtc.getTime() - spring.startsAtUtc.getTime()) / 3600000,
  ).toBe(23);
  expect(
    (fall.endsAtUtc.getTime() - fall.startsAtUtc.getTime()) / 3600000,
  ).toBe(25);
  const week = calendarRange({
    from: "2030-03-04",
    timezone: "America/New_York",
    days: "7",
  });
  expect(week.dates).toHaveLength(7);
  expect(
    (week.endsAtUtc.getTime() - week.startsAtUtc.getTime()) / 3600000,
  ).toBe(167);
});
it("calendar rejects dates that do not exist in the selected zone", () => {
  expect(() =>
    calendarRange({ from: "2011-12-30", timezone: "Pacific/Apia", days: "1" }),
  ).toThrow();
});
