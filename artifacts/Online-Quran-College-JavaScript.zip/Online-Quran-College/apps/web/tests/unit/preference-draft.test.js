import { it, expect } from "vitest";
import {
  encodePreferenceDraft,
  decodePreferenceDraft,
} from "@/lib/admissions/preference-draft";
it("trial draft storage excludes contact details, guardian data, notes, consent and tokens", () => {
  const now = 1800000000000,
    value = {
      courseId: "019a8f9a-f0b1-7000-8000-000000000001",
      country: "GB",
      timezone: "Europe/London",
      learnerName: "Synthetic child",
      guardianName: "Synthetic guardian",
      email: "synthetic@test.invalid",
      phoneE164: "+447700900123",
      notes: "Private note",
      consentGiven: true,
      botToken: "Private token",
    };
  const raw = encodePreferenceDraft(value, now),
    restored = decodePreferenceDraft(raw, now + 1000);
  expect(restored).toMatchObject({
    courseId: value.courseId,
    country: "GB",
    timezone: "Europe/London",
  });
  for (const field of [
    "learnerName",
    "guardianName",
    "email",
    "phoneE164",
    "notes",
    "consentGiven",
    "botToken",
  ])
    expect(restored).not.toHaveProperty(field);
  expect(raw).not.toContain("Synthetic child");
});
it("trial preference drafts expire and reject malformed or invalid values", () => {
  const now = 1800000000000;
  expect(
    decodePreferenceDraft(
      encodePreferenceDraft({ country: "GB" }, now),
      now + 1800001,
    ),
  ).toEqual({});
  expect(decodePreferenceDraft("not JSON", now)).toEqual({});
  expect(
    decodePreferenceDraft(
      encodePreferenceDraft({ courseId: "invalid", timezone: "invalid" }, now),
      now + 1,
    ),
  ).toEqual({});
});
