import { it, expect, vi } from "vitest";
import {
  createPreviewLink,
  validPreviewLink,
} from "@/lib/content/preview-links";
it("preview signatures expire and cannot cross staff sessions, records or versions", () => {
  vi.stubEnv("AUTH_SECRET", "synthetic-preview-key-with-sufficient-length");
  try {
    const now = 1800000000000,
      link = createPreviewLink("session-one", "pages", "record-one", 2, now),
      query = Object.fromEntries(
        new URL(link, "https://synthetic.invalid").searchParams,
      );
    expect(
      validPreviewLink("session-one", "pages", "record-one", query, now + 1000),
    ).toBe(true);
    expect(
      validPreviewLink("session-two", "pages", "record-one", query, now + 1000),
    ).toBe(false);
    expect(
      validPreviewLink("session-one", "pages", "record-two", query, now + 1000),
    ).toBe(false);
    expect(
      validPreviewLink(
        "session-one",
        "pages",
        "record-one",
        { ...query, version: "3" },
        now + 1000,
      ),
    ).toBe(false);
    expect(
      validPreviewLink(
        "session-one",
        "pages",
        "record-one",
        query,
        now + 600001,
      ),
    ).toBe(false);
  } finally {
    vi.unstubAllEnvs();
  }
});
