import { EventEmitter } from "node:events";
import { it, expect, vi, afterEach } from "vitest";
const probe = vi.hoisted(() => ({ clients: [] }));
vi.mock("ioredis", () => ({
  default: class extends EventEmitter {
    status = "wait";
    count = 0;
    constructor() {
      super();
      probe.clients.push(this);
    }
    async connect() {
      this.status = "ready";
    }
    async eval() {
      return ++this.count;
    }
  },
}));
it("reuses one Redis error handler across requests and still enforces the limit", async () => {
  vi.stubEnv("RATE_LIMIT_DRIVER", "redis");
  const { rateLimit } = await import("@/lib/ratelimit");
  for (let request = 0; request < 20; request++)
    await rateLimit("synthetic-listener-probe", 20, 60);
  expect(probe.clients).toHaveLength(1);
  expect(probe.clients[0].listenerCount("error")).toBe(1);
  expect(() =>
    probe.clients[0].emit("error", new Error("synthetic connection error")),
  ).not.toThrow();
  await expect(
    rateLimit("synthetic-listener-probe", 20, 60),
  ).rejects.toMatchObject({ code: "RATE_LIMITED", status: 429 });
});

afterEach(() => vi.unstubAllEnvs());
