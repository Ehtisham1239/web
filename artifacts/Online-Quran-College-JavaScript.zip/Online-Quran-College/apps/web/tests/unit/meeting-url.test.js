import { it, expect } from "vitest";
import { approvedMeetingUrl } from "@/server/repositories/class-sessions";
it("requires HTTPS and an exact approved hostname without credentials or custom ports", () => {
  const hosts = ["meet.synthetic.invalid"];
  expect(approvedMeetingUrl(null, undefined)).toBeNull();
  expect(approvedMeetingUrl("https://meet.synthetic.invalid/room", hosts)).toBe(
    "https://meet.synthetic.invalid/room",
  );
  for (const url of [
    "http://meet.synthetic.invalid/room",
    "https://meet.synthetic.invalid.attacker.invalid/room",
    "https://attacker.invalid/room",
    "https://user:pass@meet.synthetic.invalid/room",
    "https://meet.synthetic.invalid:8443/room",
    "javascript:alert(1)",
  ])
    expect(() => approvedMeetingUrl(url, hosts)).toThrow();
  expect(() =>
    approvedMeetingUrl("https://meet.synthetic.invalid/room", undefined),
  ).toThrow();
});
