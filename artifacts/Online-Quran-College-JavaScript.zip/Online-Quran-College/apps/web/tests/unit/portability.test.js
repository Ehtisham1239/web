import { afterEach, expect, it, vi } from "vitest";
import { validCronAuthorization } from "@/lib/platform/cron-auth";
import { rateLimitProvider } from "@/lib/ratelimit/provider";

afterEach(() => vi.unstubAllEnvs());

it("uses PostgreSQL by default and preserves explicitly configured Redis", () => {
  expect(rateLimitProvider({})).toBe("postgres");
  expect(rateLimitProvider({ REDIS_URL: "redis://localhost:6379" })).toBe(
    "redis",
  );
  expect(
    rateLimitProvider({
      REDIS_URL: "redis://localhost:6379",
      RATE_LIMIT_DRIVER: "postgres",
    }),
  ).toBe("postgres");
  expect(() => rateLimitProvider({ RATE_LIMIT_DRIVER: "memory" })).toThrow();
});

it("refuses missing, weak, or incorrect scheduler credentials", () => {
  const secret = "test-only-scheduler-secret-long-enough";
  expect(validCronAuthorization(null, secret)).toBe(false);
  expect(validCronAuthorization("Bearer short", "short")).toBe(false);
  expect(validCronAuthorization("Bearer " + secret, undefined)).toBe(false);
  expect(validCronAuthorization("Bearer " + secret + "x", secret)).toBe(false);
  expect(
    validCronAuthorization("Bearer " + secret.slice(0, -1) + "X", secret),
  ).toBe(false);
  expect(validCronAuthorization("Bearer " + secret, secret)).toBe(true);
});

it("does not execute scheduled jobs without authorization", async () => {
  vi.stubEnv("CRON_SECRET", "test-only-scheduler-secret-long-enough");
  const { POST } = await import("@/app/api/internal/jobs/route");
  const response = await POST(
    new Request("http://localhost/api/internal/jobs", { method: "POST" }),
  );
  expect(response.status).toBe(401);
  expect(response.headers.get("cache-control")).toBe("no-store");
});
