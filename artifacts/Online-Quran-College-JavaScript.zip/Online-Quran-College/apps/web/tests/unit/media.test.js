import { it, expect } from "vitest";
import sharp from "sharp";
import { normalizeUpload, maxImageBytes } from "@/lib/media/images";
it("rejects disguised executable uploads and oversized input", async () => {
  await expect(
    normalizeUpload(Buffer.from('<svg onload="alert(1)"></svg>')),
  ).rejects.toMatchObject({ status: 400 });
  await expect(
    normalizeUpload(Buffer.alloc(maxImageBytes + 1)),
  ).rejects.toMatchObject({ status: 413 });
});
it("normalizes an image, strips metadata and enforces safe dimensions", async () => {
  const source = await sharp({
    create: {
      width: 3000,
      height: 10,
      channels: 3,
      background: { r: 30, g: 120, b: 40 },
    },
  })
    .jpeg()
    .withMetadata({ orientation: 1 })
    .toBuffer();
  const result = await normalizeUpload(source);
  expect(result.mimeType).toBe("image/webp");
  expect(result.width).toBe(2400);
  const metadata = await sharp(result.bytes).metadata();
  expect(metadata.exif).toBeUndefined();
  expect(metadata.icc).toBeUndefined();
});
it("rejects corrupt image bytes even with an authentic signature", async () => {
  await expect(
    normalizeUpload(Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0])),
  ).rejects.toMatchObject({ status: 400 });
});
