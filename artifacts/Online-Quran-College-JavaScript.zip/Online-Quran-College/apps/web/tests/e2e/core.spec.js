import { readFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import { database } from "../../src/lib/db";
import { newId } from "../../src/lib/platform/ids";
import {
  randomToken,
  hashToken,
  hashPassword,
  encryptSecret,
} from "../../src/lib/auth/crypto";
import { generateSecret } from "otplib";
const email = "synthetic-browser@test.invalid";
const password = "Synthetic browser passphrase";
let backup = "";
test.beforeAll(async () => {
  const notice = {
    version: "synthetic-browser-v1",
    trialText:
      "Synthetic consent wording for this disposable test application.",
    contactText: "Synthetic consent wording for this disposable test message.",
  };
  await database().setting.upsert({
    where: { key: "consent.version." + notice.version },
    create: {
      id: newId(),
      key: "consent.version." + notice.version,
      value: notice,
      isPublic: false,
    },
    update: { value: notice },
  });
  await database().setting.upsert({
    where: { key: "legal.activeConsentVersion" },
    create: {
      id: newId(),
      key: "legal.activeConsentVersion",
      value: notice.version,
      isPublic: false,
    },
    update: { value: notice.version },
  });
  // Disposable test owner explicitly chooses the supported provider opt-out.
  await database().setting.upsert({
    where: { key: "readiness.botProtectionDisabledAccepted" },
    create: {
      id: newId(),
      key: "readiness.botProtectionDisabledAccepted",
      value: true,
      isPublic: false,
    },
    update: { value: true },
  });
  const existing = await database().user.findUnique({ where: { email } });
  const role = await database().role.findUniqueOrThrow({
    where: { key: "SUPER_ADMIN" },
  });
  const user =
    existing ??
    (await database().user.create({
      data: {
        id: newId(),
        email,
        name: "Synthetic Browser Operator",
        passwordHash: await hashPassword(password),
        roleId: role.id,
        isActive: true,
        mustEnrollMfa: false,
        mfaEnabled: true,
        mfaSecretEnc: encryptSecret(generateSecret()),
      },
    }));
  backup = randomToken();
  await database().mfaBackupCode.create({
    data: { id: newId(), userId: user.id, codeHash: hashToken(backup) },
  });
});
test.afterAll(async () => {
  await database().$disconnect();
});
test("public pages have honest empty states, navigation and accessibility", async ({
  page,
  context,
}) => {
  test.setTimeout(90000);
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText(
    "Make room for learning.",
  );
  await expect(page.getByText("A considered learning path")).toBeVisible();
  await page.waitForFunction(
    () => document.documentElement.dataset.hydrated === "true",
  );
  for (const route of [
    "/",
    "/courses",
    "/teachers",
    "/pricing",
    "/free-trial",
    "/contact",
    "/privacy",
    "/admin/login",
  ]) {
    const scanPage = await context.newPage();
    await scanPage.goto(route);
    await scanPage.waitForFunction(
      () => document.documentElement.dataset.hydrated === "true",
    );
    await expect(scanPage.getByRole("heading", { level: 1 })).toBeVisible();
    const scan = await new AxeBuilder({ page: scanPage })
      .setLegacyMode(true)
      .analyze();
    expect(
      scan.violations.filter((v) =>
        ["critical", "serious"].includes(v.impact ?? ""),
      ),
      route,
    ).toEqual([]);
    await scanPage.close();
  }
  await page.setViewportSize({ width: 375, height: 812 });
  await page.goto("/");
  await page.keyboard.press("Tab");
  await expect(page.locator(".skip-link")).toBeFocused();
  await page.keyboard.press("Enter");
  await expect(page.locator("#main-content")).toBeFocused();
  await expect(
    page.getByRole("link", { name: "Book a Free Trial" }).first(),
  ).toBeInViewport();
  await page.getByRole("button", { name: "Open navigation" }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page
    .getByRole("dialog")
    .getByRole("link", { name: "Courses", exact: true })
    .click();
  await expect(page).toHaveURL(/\/courses$/);
});
test("anonymous direct admin access is denied and AI remains unavailable", async ({
  page,
  request,
}) => {
  await page.goto("/admin");
  await expect(page).toHaveURL(/\/admin\/login$/);
  const denied = await request.get("/api/v1/admin/courses");
  expect(denied.status()).toBe(401);
  expect((await request.get("/api/v1/admin/calendar")).status()).toBe(401);
  const ai = await request.post("/api/v1/ai/assistant", {
    data: { message: "synthetic question" },
  });
  expect(ai.status()).toBe(503);
  expect((await ai.json()).error.code).toBe("AI_UNAVAILABLE");
});
test("staff login, draft approval, publication and trial submission work end to end", async ({
  page,
}) => {
  await page.goto("/admin/login");
  await page.getByLabel("Staff email").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("Authenticator or backup code").fill(backup);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(page).toHaveURL(/\/admin$/);
  await page.getByLabel("Find a workspace section").fill("courses");
  const staffNav = page.getByRole("navigation", { name: "Staff navigation" });
  await expect(staffNav.getByRole("link")).toHaveCount(1);
  await staffNav.getByRole("link", { name: "courses", exact: true }).click();
  await expect(
    staffNav.getByRole("link", { name: "courses", exact: true }),
  ).toHaveAttribute("aria-current", "page");
  await page.setViewportSize({ width: 390, height: 844 });
  await expect(staffNav).toBeHidden();
  await page.getByRole("button", { name: "Workspace menu" }).click();
  await expect(staffNav).toBeVisible();
  await page.getByRole("button", { name: "Close menu" }).click();
  await expect(staffNav).toBeHidden();
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto("/admin/courses");
  await page.getByText("Create a record", { exact: true }).click();
  await page.getByLabel("Course title").fill("Synthetic Browser Course");
  await page.getByLabel("Page address").fill("synthetic-browser-course");
  await page
    .getByLabel("Summary")
    .fill("Synthetic browser test only, ephemeral database.");
  await page.getByLabel("Age group").fill("ADULT");
  await page.getByLabel("Level", { exact: true }).fill("BEGINNER");
  await page.getByRole("button", { name: "Save draft" }).click();
  await expect(
    page.getByRole("cell", { name: "Synthetic Browser Course" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Submit for approval" }).click();
  await expect(
    page.getByRole("button", { name: "Approve", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Approve", exact: true }).click();
  await page.getByRole("button", { name: "Publish", exact: true }).click();
  await expect(
    page.getByRole("cell", { name: "PUBLISHED", exact: true }),
  ).toBeVisible();
  await page.goto("/courses");
  await expect(
    page.getByRole("heading", { name: "Synthetic Browser Course" }),
  ).toBeVisible();
  await page.goto("/free-trial");
  await page.getByLabel("Learner full name").fill("Synthetic Browser Learner");
  await page.getByLabel("Email address").fill("synthetic-learner@test.invalid");
  await page.getByLabel("Phone (international format)").fill("+441234567890");
  await page.getByLabel("Country (two-letter code)").fill("GB");
  await page
    .getByLabel("Course", { exact: true })
    .selectOption({ label: "Synthetic Browser Course" });
  await page.getByRole("checkbox").check();
  await expect(page.getByLabel("Time zone")).not.toHaveValue("");
  await page.waitForTimeout(3100);
  await page.getByRole("button", { name: "Submit application" }).click();
  await expect(
    page.getByRole("heading", { name: "Application received" }),
  ).toBeVisible();
  expect(await database().trialApplication.count()).toBe(1);
  expect(
    await database().auditLog.count({ where: { action: "trial.submitted" } }),
  ).toBe(1);
});
test("mobile trial steps restore preferences without retaining contact details", async ({
  page,
}) => {
  await page.setViewportSize({ width: 375, height: 812 });
  await page.goto("/free-trial");
  await page.getByLabel("Learner full name").fill("Synthetic Mobile Learner");
  await page.getByLabel("Email address").fill("mobile@test.invalid");
  await page.getByLabel("Phone (international format)").fill("+441234567890");
  await page.getByLabel("Country (two-letter code)").fill("GB");
  await page
    .getByRole("button", { name: "Continue application", exact: true })
    .click();
  await expect(page.getByLabel("Course", { exact: true })).toBeVisible();
  await page
    .getByLabel("Course", { exact: true })
    .selectOption({ label: "Synthetic Browser Course" });
  await page.getByLabel("Preferred start time", { exact: true }).fill("12:30");
  await page.getByLabel("Preferred end time", { exact: true }).fill("13:30");
  await page
    .getByRole("button", { name: "Add preferred time range", exact: true })
    .click();
  await page.getByLabel("Day 2", { exact: true }).selectOption("3");
  await page
    .getByLabel("Preferred start time 2", { exact: true })
    .fill("14:00");
  await page.getByLabel("Preferred end time 2", { exact: true }).fill("15:00");
  await page
    .getByRole("button", { name: "Add preferred time range", exact: true })
    .click();
  await expect(
    page.getByRole("button", { name: "Add preferred time range", exact: true }),
  ).toHaveCount(0);
  await page
    .getByRole("button", { name: "Remove time range 3", exact: true })
    .click();
  const stored = await page.evaluate(() =>
    Object.values(sessionStorage).join(" "),
  );
  expect(stored).not.toContain("mobile@test.invalid");
  expect(stored).not.toContain("Synthetic Mobile Learner");
  await page.reload();
  await expect(page.getByLabel("Learner full name")).toHaveValue("");
  await expect(page.getByLabel("Email address")).toHaveValue("");
  await page.getByLabel("Learner full name").fill("Synthetic Mobile Learner");
  await page.getByLabel("Email address").fill("mobile@test.invalid");
  await page.getByLabel("Phone (international format)").fill("+441234567890");
  await page
    .getByRole("button", { name: "Continue application", exact: true })
    .click();
  await expect(page.getByLabel("Course", { exact: true })).not.toHaveValue("");
  await expect(
    page.getByLabel("Preferred start time", { exact: true }),
  ).toHaveValue("12:30");
  await expect(
    page.getByLabel("Preferred start time 2", { exact: true }),
  ).toHaveValue("14:00");
  await page
    .getByRole("button", { name: "Continue application", exact: true })
    .click();
  await expect(page.getByRole("checkbox")).not.toBeChecked();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
});
test("CSRF and unexpected input are rejected, contact form persists", async ({
  page,
  request,
}) => {
  const bad = await request.post("/api/v1/public/contact-messages", {
    data: {},
    headers: { Origin: "https://other.invalid" },
  });
  expect(bad.status()).toBe(403);
  await page.goto("/contact");
  await page.getByLabel("Your name").fill("Synthetic Browser Contact");
  await page.getByLabel("Email address").fill("synthetic-contact@test.invalid");
  await page
    .getByLabel("Subject", { exact: true })
    .fill("Synthetic test question");
  await page
    .getByLabel("Your message")
    .fill("Synthetic browser contact test only.");
  await page.getByRole("checkbox").check();
  await page.waitForTimeout(3100);
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(
    page.getByRole("heading", { name: "Message received" }),
  ).toBeVisible();
  expect(await database().contactMessage.count()).toBe(1);
});
test("staff records can be edited from a fresh tab and a trial can be scheduled and enrolled", async ({
  page,
  context,
}) => {
  test.setTimeout(90000);
  const user = await database().user.findUniqueOrThrow({ where: { email } }),
    code = randomToken();
  await database().mfaBackupCode.create({
    data: { id: newId(), userId: user.id, codeHash: hashToken(code) },
  });
  await page.goto("/admin/login");
  await page.getByLabel("Staff email").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("Authenticator or backup code").fill(code);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(page).toHaveURL(/\/admin$/);
  const course = await database().course.findFirstOrThrow();
  const fresh = await context.newPage();
  await fresh.goto("/admin/courses/" + course.id);
  await fresh.getByText("Edit record", { exact: true }).click();
  await fresh
    .getByLabel("Summary", { exact: true })
    .fill("Synthetic edit verified from a new browser tab.");
  await fresh.getByRole("button", { name: "Save changes" }).click();
  await expect
    .poll(
      async () =>
        (
          await database().course.findUniqueOrThrow({
            where: { id: course.id },
          })
        ).status,
    )
    .toBe("DRAFT");
  await fresh.goto("/admin/courses/" + course.id);
  await fresh.getByRole("button", { name: "Add module", exact: true }).click();
  await fresh
    .getByLabel("Module 1 title", { exact: true })
    .fill("Synthetic first module");
  await fresh
    .getByLabel("Module 1 objectives", { exact: true })
    .fill("Practice a skill in this disposable test.");
  await fresh
    .getByRole("button", { name: "Save syllabus", exact: true })
    .click();
  await expect
    .poll(() =>
      database().courseModule.count({ where: { courseId: course.id } }),
    )
    .toBe(1);
  await fresh.goto("/admin/courses");
  await fresh.getByRole("button", { name: "Submit for approval" }).click();
  await fresh.getByRole("button", { name: "Approve", exact: true }).click();
  await fresh.getByRole("button", { name: "Publish", exact: true }).click();
  await expect(
    fresh.getByRole("cell", { name: "PUBLISHED", exact: true }),
  ).toBeVisible();
  const csrf = await fresh.request.get("/api/v1/auth/session");
  expect(csrf.status()).toBe(200);
  const rejected = await fresh.request.patch(
    "/api/v1/admin/courses/" + course.id,
    {
      headers: { Origin: "http://localhost:3100", "X-CSRF-Token": "invalid" },
      data: { version: 8, title: "Synthetic rejected edit" },
    },
  );
  expect(rejected.status()).toBe(403);
  await fresh.goto("/admin/teachers");
  await fresh.getByText("Create a record", { exact: true }).click();
  await fresh.getByLabel("Public name").fill("Synthetic Academic Teacher");
  await fresh.getByLabel("Page address").fill("synthetic-academic-teacher");
  await fresh
    .getByLabel("Biography")
    .fill("Synthetic teacher for ephemeral browser workflow only.");
  await fresh.getByLabel("Languages (comma separated)").fill("English");
  await fresh.getByRole("button", { name: "Save draft" }).click();
  await expect(
    fresh.getByRole("cell", {
      name: "Synthetic Academic Teacher",
      exact: true,
    }),
  ).toBeVisible();
  const teacher = await database().teacher.findFirstOrThrow();
  await fresh.goto("/admin/teachers/" + teacher.id);
  await fresh.getByLabel("Synthetic Browser Course", { exact: true }).check();
  await fresh.getByRole("button", { name: "Save course assignments" }).click();
  await expect
    .poll(() =>
      database().teacherCourse.count({
        where: { teacherId: teacher.id, courseId: course.id },
      }),
    )
    .toBe(1);
  await expect(fresh.locator("[data-record-version]")).toHaveAttribute(
    "data-record-version",
    "2",
  );
  await fresh.getByLabel("Teacher time zone", { exact: true }).fill("UTC");
  await fresh
    .getByRole("button", { name: "Add availability slot", exact: true })
    .click();
  await fresh.getByLabel("From", { exact: true }).fill("09:00");
  await fresh.getByLabel("Through", { exact: true }).fill("11:00");
  await fresh
    .getByRole("button", { name: "Save availability", exact: true })
    .click();
  await expect
    .poll(() =>
      database().teacherAvailability.count({
        where: { teacherId: teacher.id },
      }),
    )
    .toBe(1);
  await expect(fresh.locator("[data-record-version]")).toHaveAttribute(
    "data-record-version",
    "3",
  );
  const trial = await database().trialApplication.findFirstOrThrow();
  await fresh.goto("/admin/trials/" + trial.id);
  await fresh.getByLabel("Course teacher").selectOption(teacher.id);
  await fresh.getByLabel("Trial start (UTC)").fill("2030-06-03T10:00");
  await fresh.getByLabel("Duration in minutes").fill("30");
  await fresh.getByRole("button", { name: "Assign trial class" }).click();
  await expect
    .poll(
      async () =>
        (
          await database().trialApplication.findUniqueOrThrow({
            where: { id: trial.id },
          })
        ).assignedTeacherId,
    )
    .toBe(teacher.id);
  await expect(
    fresh.getByText("Assigned teacher: Synthetic Academic Teacher", {
      exact: true,
    }),
  ).toBeVisible();
  for (const status of ["REVIEWED", "SCHEDULED", "COMPLETED"]) {
    await fresh.getByLabel("Next status").selectOption(status);
    await fresh.getByRole("button", { name: "Update status" }).click();
    await expect
      .poll(
        async () =>
          (
            await database().trialApplication.findUniqueOrThrow({
              where: { id: trial.id },
            })
          ).status,
      )
      .toBe(status);
    await expect(
      fresh.getByText("Current status: " + status.toLowerCase(), {
        exact: true,
      }),
    ).toBeVisible();
  }
  await fresh.getByRole("checkbox", { name: /I confirm enrollment/ }).check();
  await fresh.getByRole("button", { name: "Enroll learner" }).click();
  await expect
    .poll(
      async () =>
        (
          await database().trialApplication.findUniqueOrThrow({
            where: { id: trial.id },
          })
        ).status,
    )
    .toBe("ENROLLED");
  expect(await database().student.count()).toBe(1);
  expect(await database().enrollment.count()).toBe(1);
  await fresh.goto("/admin/account");
  await expect(
    fresh.getByRole("heading", { name: "Active sessions" }),
  ).toBeVisible();
  await fresh
    .getByRole("button", { name: "Sign out everywhere", exact: true })
    .click();
  await expect(fresh).toHaveURL(/\/admin\/login$/);
  await fresh.close();
});
test("staff can enter a fee and publish a pricing plan", async ({ page }) => {
  const user = await database().user.findUniqueOrThrow({ where: { email } }),
    code = randomToken();
  await database().mfaBackupCode.create({
    data: { id: newId(), userId: user.id, codeHash: hashToken(code) },
  });
  await page.goto("/admin/login");
  await page.getByLabel("Staff email").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("Authenticator or backup code").fill(code);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(page).toHaveURL(/\/admin$/);
  await page.goto("/admin/pricing-plans");
  await page.getByText("Create a record", { exact: true }).click();
  await page
    .getByLabel("Plan name", { exact: true })
    .fill("Synthetic browser plan");
  await page.getByLabel("Show plan publicly when published").check();
  await page.getByLabel("Classes per week", { exact: true }).fill("2");
  await page.getByLabel("Class duration (minutes)", { exact: true }).fill("30");
  await page.getByRole("button", { name: "Save draft", exact: true }).click();
  await expect(
    page.getByRole("cell", { name: "Synthetic browser plan", exact: true }),
  ).toBeVisible();
  const plan = await database().pricingPlan.findFirstOrThrow();
  await page.goto("/admin/pricing-plans/" + plan.id);
  await page.getByRole("button", { name: "Add price", exact: true }).click();
  await page
    .getByLabel("Price 1 currency", { exact: true })
    .selectOption("GBP");
  await page.getByLabel("Price 1 amount", { exact: true }).fill("12.34");
  await page.getByLabel("Visible when published", { exact: true }).check();
  await page.getByRole("button", { name: "Save prices", exact: true }).click();
  await expect
    .poll(() =>
      database().pricingPlanPrice.count({
        where: { planId: plan.id, amountMinor: 1234 },
      }),
    )
    .toBe(1);
  await page.goto("/pricing");
  await expect(
    page.getByRole("heading", { name: "Synthetic browser plan" }),
  ).toHaveCount(0);
  await page.goto("/admin/pricing-plans");
  await page.getByRole("button", { name: "Submit for approval" }).click();
  await page.getByRole("button", { name: "Approve", exact: true }).click();
  await page.getByRole("button", { name: "Publish", exact: true }).click();
  await expect(
    page.getByRole("cell", { name: "PUBLISHED", exact: true }),
  ).toBeVisible();
  await page.goto("/pricing");
  await expect(
    page.getByRole("heading", { name: "Synthetic browser plan" }),
  ).toBeVisible();
  await expect(page.getByText("£12.34", { exact: true })).toBeVisible();
});
test("staff can create an adult learner and enroll them with a course teacher", async ({
  page,
}) => {
  const user = await database().user.findUniqueOrThrow({ where: { email } }),
    code = randomToken();
  await database().mfaBackupCode.create({
    data: { id: newId(), userId: user.id, codeHash: hashToken(code) },
  });
  await page.goto("/admin/login");
  await page.getByLabel("Staff email").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("Authenticator or backup code").fill(code);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(page).toHaveURL(/\/admin$/);
  await page.goto("/admin/students");
  await page.getByText("Create a record", { exact: true }).click();
  await page
    .getByLabel("Learner name", { exact: true })
    .fill("Synthetic manually enrolled adult");
  await page.getByLabel("Age band", { exact: true }).selectOption("18_PLUS");
  await page.getByLabel("Country code", { exact: true }).fill("GB");
  await page.getByLabel("Time zone", { exact: true }).fill("UTC");
  await page.getByRole("button", { name: "Save draft", exact: true }).click();
  await expect(
    page.getByRole("cell", {
      name: "Synthetic manually enrolled adult",
      exact: true,
    }),
  ).toBeVisible();
  const student = await database().student.findFirstOrThrow({
    where: { fullName: "Synthetic manually enrolled adult" },
  });
  const course = await database().course.findFirstOrThrow(),
    teacher = await database().teacher.findFirstOrThrow();
  await page.goto("/admin/enrollments");
  await page.getByText("Enroll an existing learner", { exact: true }).click();
  await page.getByLabel("Learner", { exact: true }).selectOption(student.id);
  await page
    .getByLabel("Published course", { exact: true })
    .selectOption(course.id);
  await page
    .getByLabel("Course teacher", { exact: true })
    .selectOption(teacher.id);
  await page.getByLabel("Enrollment start", { exact: true }).fill("2030-06-01");
  await page
    .getByRole("button", { name: "Confirm enrollment", exact: true })
    .click();
  await expect
    .poll(() =>
      database().enrollment.count({
        where: {
          studentId: student.id,
          courseId: course.id,
          teacherId: teacher.id,
          status: "ACTIVE",
        },
      }),
    )
    .toBe(1);
});
test("Super Admin can publish approved consent wording and stale versions are rejected", async ({
  page,
}) => {
  const user = await database().user.findUniqueOrThrow({ where: { email } }),
    code = randomToken();
  await database().mfaBackupCode.create({
    data: { id: newId(), userId: user.id, codeHash: hashToken(code) },
  });
  await page.goto("/admin/login");
  await page.getByLabel("Staff email").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("Authenticator or backup code").fill(code);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(page).toHaveURL(/\/admin$/);
  await page.goto("/admin/settings");
  await page
    .getByLabel("Consent version identifier", { exact: true })
    .fill("synthetic-browser-v2");
  await page
    .getByLabel("Trial consent wording", { exact: true })
    .fill("Updated synthetic consent wording for this disposable trial test.");
  const wording =
    "Updated synthetic consent wording for this disposable contact test.";
  await page
    .getByLabel("Contact consent wording", { exact: true })
    .fill(wording);
  await page
    .getByLabel("The owner has approved this exact wording for publication.", {
      exact: true,
    })
    .check();
  await page
    .getByRole("button", { name: "Approve new consent version", exact: true })
    .click();
  await expect(
    page.getByText("Current approved version: synthetic-browser-v2", {
      exact: true,
    }),
  ).toBeVisible();
  await page.goto("/contact");
  await expect(
    page.getByRole("checkbox", { name: wording, exact: true }),
  ).toBeVisible();
  const stale = await page.request.post("/api/v1/public/contact-messages", {
    headers: { Origin: "http://localhost:3100" },
    data: {
      name: "Synthetic stale notice",
      email: "stale@test.invalid",
      subject: "Synthetic stale submission",
      message: "Synthetic stale form submission is rejected.",
      consentGiven: true,
      consentTextVersion: "synthetic-browser-v1",
      website: "",
      startedAt: Date.now() - 4000,
      botToken: "",
    },
  });
  expect(stale.status()).toBe(409);
});
test("staff can assign, review, confirm a reply and archive a contact message", async ({
  page,
}) => {
  const user = await database().user.findUniqueOrThrow({ where: { email } }),
    code = randomToken();
  await database().mfaBackupCode.create({
    data: { id: newId(), userId: user.id, codeHash: hashToken(code) },
  });
  await page.goto("/admin/login");
  await page.getByLabel("Staff email").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("Authenticator or backup code").fill(code);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(page).toHaveURL(/\/admin$/);
  const message = await database().contactMessage.findFirstOrThrow();
  await page.goto("/admin/contact-messages/" + message.id);
  await page
    .getByLabel("Assigned operator", { exact: true })
    .selectOption(user.id);
  await page.getByLabel("Message status", { exact: true }).selectOption("READ");
  await page
    .getByRole("button", { name: "Save message workflow", exact: true })
    .click();
  await expect(
    page.getByText("Current status: read", { exact: true }),
  ).toBeVisible();
  await page
    .getByLabel("Message status", { exact: true })
    .selectOption("REPLIED");
  await page
    .getByLabel(
      "I have already replied to this person through an approved channel.",
      { exact: true },
    )
    .check();
  await page
    .getByRole("button", { name: "Save message workflow", exact: true })
    .click();
  await expect(
    page.getByText("Current status: replied", { exact: true }),
  ).toBeVisible();
  await page
    .getByLabel("Message status", { exact: true })
    .selectOption("ARCHIVED");
  await page
    .getByRole("button", { name: "Save message workflow", exact: true })
    .click();
  await expect(
    page.getByText("Current status: archived", { exact: true }),
  ).toBeVisible();
  const saved = await database().contactMessage.findUniqueOrThrow({
    where: { id: message.id },
  });
  expect(saved.assignedToUserId).toBe(user.id);
  expect(saved.repliedById).toBe(user.id);
});
test("staff can reschedule, mark attendance and cancel classes with stale-edit protection", async ({
  page,
}) => {
  const db = database();
  const user = await db.user.findUniqueOrThrow({ where: { email } }),
    code = randomToken();
  await db.mfaBackupCode.create({
    data: { id: newId(), userId: user.id, codeHash: hashToken(code) },
  });
  await page.goto("/admin/login");
  await page.getByLabel("Staff email").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("Authenticator or backup code").fill(code);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(page).toHaveURL(/\/admin$/);
  const enrollment = await db.enrollment.findFirstOrThrow();
  const schedule = await db.classSchedule.create({
    data: {
      id: newId(),
      enrollmentId: enrollment.id,
      teacherId: enrollment.teacherId,
      weekday: 1,
      startMinute: 600,
      durationMin: 30,
      timezone: "UTC",
      effectiveFrom: new Date("2040-01-02"),
    },
  });
  const session = await db.classSession.create({
    data: {
      id: newId(),
      scheduleId: schedule.id,
      teacherId: enrollment.teacherId,
      studentId: enrollment.studentId,
      startsAtUtc: new Date("2040-01-02T10:00:00Z"),
      endsAtUtc: new Date("2040-01-02T10:30:00Z"),
    },
  });
  await page.goto("/admin/sessions/" + session.id);
  await page
    .getByLabel("New class date and time", { exact: true })
    .fill("2040-01-09T10:00");
  await page.getByLabel("Class time zone", { exact: true }).fill("UTC");
  await page
    .getByLabel("Approved HTTPS meeting URL", { exact: true })
    .fill("https://unapproved.synthetic.invalid/class");
  await page
    .getByRole("button", { name: "Reschedule class", exact: true })
    .click();
  await expect(
    page
      .getByRole("alert")
      .filter({ hasText: "exact meeting hostname approved" }),
  ).toContainText("exact meeting hostname approved");
  await page.getByLabel("Approved HTTPS meeting URL", { exact: true }).fill("");
  await page
    .getByRole("button", { name: "Reschedule class", exact: true })
    .click();
  await expect(page.locator("[data-record-version]")).toHaveAttribute(
    "data-record-version",
    "2",
  );
  expect(
    (
      await db.classSession.findUniqueOrThrow({ where: { id: session.id } })
    ).startsAtUtc.toISOString(),
  ).toBe("2040-01-09T10:00:00.000Z");
  await expect(
    page.getByRole("heading", { name: "Class attendance", exact: true }),
  ).toBeVisible();
  await page
    .getByLabel("Attendance status", { exact: true })
    .selectOption("PRESENT");
  await page
    .getByLabel("Private attendance note")
    .fill("Synthetic private browser note");
  await page
    .getByRole("button", { name: "Save attendance", exact: true })
    .click();
  await expect
    .poll(() =>
      db.attendance.count({
        where: { sessionId: session.id, status: "PRESENT" },
      }),
    )
    .toBe(1);
  await expect(
    page.getByLabel("Attendance status", { exact: true }),
  ).toHaveValue("PRESENT");
  const csrf = await page.evaluate(
    async () => (await (await fetch("/api/v1/auth/session")).json()).data.csrf,
  );
  const stale = await page.request.post("/api/v1/admin/attendance", {
    headers: { Origin: "http://localhost:3100", "X-CSRF-Token": csrf },
    data: {
      sessionId: session.id,
      enrollmentId: enrollment.id,
      sessionVersion: session.version,
      expectedUpdatedAt: null,
      status: "ABSENT",
      note: "Stale synthetic edit",
    },
  });
  expect(stale.status()).toBe(409);
  const previous = await db.attendance.findFirstOrThrow({
    where: { sessionId: session.id },
  });
  await page
    .getByLabel("Attendance status", { exact: true })
    .selectOption("LATE");
  await page
    .getByRole("button", { name: "Save attendance", exact: true })
    .click();
  await expect
    .poll(() =>
      db.attendance.count({ where: { sessionId: session.id, status: "LATE" } }),
    )
    .toBe(1);
  expect(
    (
      await db.attendance.findFirstOrThrow({ where: { sessionId: session.id } })
    ).updatedAt.getTime(),
  ).toBeGreaterThan(previous.updatedAt.getTime());
  const next = await db.classSession.create({
    data: {
      id: newId(),
      scheduleId: schedule.id,
      teacherId: enrollment.teacherId,
      studentId: enrollment.studentId,
      startsAtUtc: new Date("2040-01-16T10:00:00Z"),
      endsAtUtc: new Date("2040-01-16T10:30:00Z"),
    },
  });
  await page.goto("/admin/sessions/" + next.id);
  await page
    .getByLabel("Class outcome", { exact: true })
    .selectOption("CANCELLED");
  await page
    .getByLabel("I confirm this class outcome.", { exact: true })
    .check();
  await page
    .getByRole("button", { name: "Save class outcome", exact: true })
    .click();
  await expect(
    page.getByText("Attendance cannot be recorded for a cancelled class.", {
      exact: true,
    }),
  ).toBeVisible();
  expect(
    (await db.classSession.findUniqueOrThrow({ where: { id: next.id } }))
      .status,
  ).toBe("CANCELLED");
  await page.goto("/admin/calendar?from=2040-01-09&timezone=UTC&days=7");
  await expect(
    page.getByRole("heading", { name: "Class calendar", exact: true }),
  ).toBeVisible();
  await expect(
    page.locator(`a[href="/admin/sessions/${session.id}"]`),
  ).toBeVisible();
  await page.getByLabel("Calendar view", { exact: true }).selectOption("1");
  await page
    .getByLabel("Calendar teacher", { exact: true })
    .selectOption(enrollment.teacherId);
  await page
    .getByRole("button", { name: "Show calendar", exact: true })
    .click();
  await expect(page.getByLabel("Calendar view", { exact: true })).toHaveValue(
    "1",
  );
  await expect(
    page.locator(`a[href="/admin/sessions/${session.id}"]`),
  ).toBeVisible();
  const calendarAxe = await new AxeBuilder({ page })
    .setLegacyMode(true)
    .analyze();
  expect(
    calendarAxe.violations.filter((violation) =>
      ["serious", "critical"].includes(violation.impact ?? ""),
    ),
  ).toEqual([]);
});
test("public filters, approved FAQ and journal feed work without exposing drafts", async ({
  page,
}) => {
  const db = database(),
    course = await db.course.findFirstOrThrow({
      where: { status: "PUBLISHED" },
    });
  const user = await db.user.findUniqueOrThrow({ where: { email } });
  const teacher = await db.teacher.create({
    data: {
      id: newId(),
      slug: "synthetic-public-directory",
      displayName: "Synthetic Public Directory Teacher",
      bio: "Synthetic approved public directory profile.",
      gender: "FEMALE",
      languages: ["Arabic"],
      isPublic: true,
      verificationNote: "Synthetic private verification note",
    },
  });
  await db.teacherCourse.create({
    data: { id: newId(), teacherId: teacher.id, courseId: course.id },
  });
  await db.fAQ.create({
    data: {
      id: newId(),
      question: "How do synthetic enquiries work?",
      answer: "Use the approved synthetic trial form.",
      category: "Getting started",
      status: "PUBLISHED",
    },
  });
  await db.blogPost.create({
    data: {
      id: newId(),
      slug: "synthetic-related-journal",
      title: "Synthetic related article",
      excerpt: "Related approved synthetic copy",
      body: { type: "doc", content: [] },
      renderedHtml: "<p>Related synthetic body.</p>",
      authorId: user.id,
      tags: ["Learning"],
      status: "PUBLISHED",
      publishedAt: new Date(),
    },
  });
  await db.blogPost.create({
    data: {
      id: newId(),
      slug: "synthetic-published-journal",
      title: "Published & Synthetic Journal",
      excerpt: "Approved > synthetic excerpt",
      body: { type: "doc", content: [] },
      renderedHtml: "<p>Approved synthetic journal body.</p>",
      authorId: user.id,
      tags: ["Learning"],
      status: "PUBLISHED",
      publishedAt: new Date(),
    },
  });
  await db.blogPost.create({
    data: {
      id: newId(),
      slug: "synthetic-private-journal",
      title: "Private synthetic journal",
      excerpt: "Unapproved private excerpt",
      body: { type: "doc", content: [] },
      renderedHtml: "<p>Private synthetic body.</p>",
      authorId: user.id,
      tags: ["Private topic"],
      status: "DRAFT",
    },
  });
  await page.goto("/courses");
  await page
    .getByLabel("Search courses", { exact: true })
    .fill("Synthetic Browser");
  await page.getByLabel("Level", { exact: true }).selectOption(course.level);
  await page
    .getByRole("button", { name: "Apply filters", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: course.title, exact: true }),
  ).toBeVisible();
  await page
    .getByLabel("Search courses", { exact: true })
    .fill("NothingMatchesSyntheticProbe");
  await page
    .getByRole("button", { name: "Apply filters", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "No matching results", exact: true }),
  ).toBeVisible();
  await page.goto("/teachers");
  await page
    .getByLabel("Teaching language", { exact: true })
    .selectOption("Arabic");
  await page
    .getByLabel("Teaching course", { exact: true })
    .selectOption(course.id);
  await page
    .getByRole("button", { name: "Apply filters", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: teacher.displayName, exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText("Synthetic private verification note"),
  ).toHaveCount(0);
  await page.goto("/faq");
  await page
    .getByLabel("Search questions", { exact: true })
    .fill("synthetic enquiries");
  await page
    .getByRole("button", { name: "Apply filters", exact: true })
    .click();
  await page
    .locator("summary")
    .filter({ hasText: "How do synthetic enquiries work?" })
    .click();
  await expect(
    page.getByText("Use the approved synthetic trial form.", { exact: true }),
  ).toBeVisible();
  await page.goto("/blog?tag=Learning");
  await expect(
    page.getByRole("heading", {
      name: "Published & Synthetic Journal",
      exact: true,
    }),
  ).toBeVisible();
  await expect(
    page.getByText("Private synthetic journal", { exact: true }),
  ).toHaveCount(0);
  const rss = await page.request.get("/rss.xml");
  expect(rss.status()).toBe(200);
  expect(rss.headers()["content-type"]).toContain("application/rss+xml");
  const xml = await rss.text();
  expect(xml).toContain("Published &amp; Synthetic Journal");
  expect(xml).not.toContain("Private synthetic journal");
  await page.goto("/courses/" + course.slug);
  await expect(
    page.getByRole("heading", { name: "Course teachers", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: teacher.displayName, exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText("Synthetic private verification note", { exact: true }),
  ).toHaveCount(0);
  await page.goto("/blog/synthetic-published-journal");
  await expect(page.locator('meta[property="og:title"]')).toHaveAttribute(
    "content",
    "Published & Synthetic Journal",
  );
  await expect(page.locator('script[type="application/ld+json"]')).toHaveCount(
    1,
  );
  await expect(
    page.getByRole("heading", { name: "Related articles", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("link", { name: "Synthetic related article", exact: true })
    .click();
  await expect(page).toHaveURL(/\/blog\/synthetic-related-journal$/);
  const missingPage = await page.goto("/missing-synthetic-public-page");
  expect(missingPage?.status()).toBe(404);
  await expect(
    page.getByRole("heading", { name: "This page isn’t here.", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("link", { name: "Book a Free Trial", exact: true }).last(),
  ).toBeVisible();
});
test("staff can preview drafts, restore revisions and edit website navigation", async ({
  page,
}) => {
  const db = database(),
    user = await db.user.findUniqueOrThrow({ where: { email } }),
    code = randomToken();
  await db.mfaBackupCode.create({
    data: { id: newId(), userId: user.id, codeHash: hashToken(code) },
  });
  await page.goto("/admin/login");
  await page.getByLabel("Staff email").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("Authenticator or backup code").fill(code);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(page).toHaveURL(/\/admin$/);
  const course = await db.course.create({
    data: {
      id: newId(),
      slug: "synthetic-browser-revisions",
      title: "Synthetic Revision Browser",
      summary: "Synthetic draft used only in a disposable browser database",
      ageGroup: "ADULT",
      level: "BEGINNER",
      description: { type: "doc", content: [] },
    },
  });
  await page.goto(`/admin/courses/${course.id}`);
  await page.getByText("Edit record", { exact: true }).click();
  await page
    .getByLabel("Course title", { exact: true })
    .fill("Synthetic Revision Browser Edited");
  await page.getByRole("button", { name: "Save changes", exact: true }).click();
  await expect(page.locator("[data-record-version]")).toHaveAttribute(
    "data-record-version",
    "2",
  );
  await page
    .getByRole("button", { name: "Preview content", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Private content preview", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", {
      name: "Synthetic Revision Browser Edited",
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByRole("link", { name: "Back to editing", exact: true })
    .click();
  await page
    .getByLabel("I confirm this revision should replace the current draft.", {
      exact: true,
    })
    .check();
  await page
    .getByRole("button", { name: "Restore selected revision", exact: true })
    .click();
  await expect(page.locator("[data-record-version]")).toHaveAttribute(
    "data-record-version",
    "3",
  );
  await expect(page.getByLabel("Course title", { exact: true })).toHaveValue(
    "Synthetic Revision Browser",
  );
  const publicDraft = await page.request.get(`/courses/${course.slug}`);
  expect(publicDraft.status()).toBe(404);
  await page.goto("/admin/menus");
  await page.getByText("Create a record", { exact: true }).click();
  await page
    .getByLabel("Navigation location", { exact: true })
    .selectOption("FOOTER");
  await page
    .getByLabel("Navigation label", { exact: true })
    .fill("Synthetic approved journal link");
  await page
    .getByLabel("Navigation destination", { exact: true })
    .fill("/blog");
  await page.getByLabel("Navigation order", { exact: true }).fill("0");
  await page
    .getByRole("button", { name: "Add navigation link", exact: true })
    .click();
  await expect.poll(() => db.menuItem.count()).toBe(1);
  await expect(
    page.getByRole("cell", {
      name: "Synthetic approved journal link",
      exact: true,
    }),
  ).toBeVisible();
  await page.goto("/");
  await expect(
    page.getByRole("link", {
      name: "Synthetic approved journal link",
      exact: true,
    }),
  ).toBeVisible();
});
test("staff can build website sections, schedule approved publication and save public social profiles", async ({
  page,
}) => {
  const db = database(),
    user = await db.user.findUniqueOrThrow({ where: { email } }),
    code = randomToken();
  await db.mfaBackupCode.create({
    data: { id: newId(), userId: user.id, codeHash: hashToken(code) },
  });
  await page.goto("/admin/login");
  await page.getByLabel("Staff email").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("Authenticator or backup code").fill(code);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(page).toHaveURL(/\/admin$/);
  await page.goto("/admin/pages");
  await page.getByText("Create a record", { exact: true }).click();
  await page
    .getByLabel("Page title", { exact: true })
    .fill("Synthetic Website Page");
  await page
    .getByLabel("Page address", { exact: true })
    .fill("synthetic-website-page");
  await page
    .getByLabel("Search title", { exact: true })
    .fill("Synthetic page SEO");
  await page
    .getByLabel("Search description", { exact: true })
    .fill("Synthetic approved website page description.");
  await page.getByRole("button", { name: "Save draft", exact: true }).click();
  await expect
    .poll(() => db.cMSPage.count({ where: { slug: "synthetic-website-page" } }))
    .toBe(1);
  const record = await db.cMSPage.findUniqueOrThrow({
    where: { slug_locale: { slug: "synthetic-website-page", locale: "en" } },
  });
  await page.goto(`/admin/pages/${record.id}`);
  await page
    .getByRole("button", { name: "Add selected section", exact: true })
    .click();
  await page
    .getByLabel("Section 1 heading", { exact: true })
    .fill("Synthetic hero heading");
  await page
    .getByLabel("Section 1 description", { exact: true })
    .fill("Synthetic owner-approved hero body.");
  await page
    .getByLabel("Section 1 button label", { exact: true })
    .fill("Contact our team");
  await page
    .getByLabel("Section 1 button destination", { exact: true })
    .fill("/contact");
  await page
    .getByLabel("New page section", { exact: true })
    .selectOption("FEATURES");
  await page
    .getByRole("button", { name: "Add selected section", exact: true })
    .click();
  await page.getByRole("button", { name: "Add feature", exact: true }).click();
  await page
    .getByLabel("Feature 1 title", { exact: true })
    .fill("Synthetic page feature");
  await page
    .getByLabel("Feature 1 description", { exact: true })
    .fill("Only disposable test content.");
  await page
    .getByRole("button", { name: "Save sections", exact: true })
    .click();
  await expect(page.locator("[data-record-version]")).toHaveAttribute(
    "data-record-version",
    "2",
  );
  await page
    .getByRole("button", { name: "Preview content", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Synthetic hero heading", exact: true }),
  ).toBeVisible();
  await page.goto("/admin/pages");
  const row = page
    .getByRole("row")
    .filter({ hasText: "Synthetic Website Page" });
  await row
    .getByRole("button", { name: "Submit for approval", exact: true })
    .click();
  await row.getByRole("button", { name: "Approve", exact: true }).click();
  await expect
    .poll(
      async () =>
        (await db.cMSPage.findUniqueOrThrow({ where: { id: record.id } }))
          .status,
    )
    .toBe("APPROVED");
  await page.goto(`/admin/pages/${record.id}`);
  const when = new Date(Date.now() + 7200000);
  await page
    .getByLabel("Publication date and time", { exact: true })
    .fill(when.toISOString().slice(0, 16));
  await page.getByLabel("Publication time zone", { exact: true }).fill("UTC");
  await page
    .getByRole("button", { name: "Schedule publication", exact: true })
    .click();
  await expect
    .poll(() =>
      db.setting.count({
        where: { key: "publication.schedule.pages." + record.id },
      }),
    )
    .toBe(1);
  expect((await page.request.get("/synthetic-website-page")).status()).toBe(
    404,
  );
  const { publishDueContent } =
    await import("../../src/server/services/publication-schedules");
  expect(
    (await publishDueContent(20, new Date(when.getTime() + 60000))).published,
  ).toBe(1);
  const live = await page.goto("/synthetic-website-page");
  expect(live?.status()).toBe(200);
  await expect(
    page.getByRole("heading", { name: "Synthetic hero heading", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Synthetic page feature", exact: true }),
  ).toBeVisible();
  await expect(page.locator('meta[property="og:title"]')).toHaveAttribute(
    "content",
    "Synthetic page SEO",
  );
  await page.goto("/admin/settings");
  await page
    .getByRole("button", { name: "Add social profile", exact: true })
    .click();
  await page
    .getByLabel("Profile 1 label", { exact: true })
    .fill("Synthetic official channel");
  await page
    .getByLabel("Profile 1 HTTPS URL", { exact: true })
    .fill("https://profile.synthetic.invalid/channel");
  await page
    .getByRole("button", { name: "Save social links", exact: true })
    .click();
  await expect
    .poll(() => db.setting.count({ where: { key: "social.links" } }))
    .toBe(1);
  await expect(
    page.getByRole("status").filter({ hasText: "Social links saved." }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Save social links", exact: true }),
  ).toBeEnabled();
  await page.goto("/");
  await expect(
    page.getByRole("link", { name: "Synthetic official channel" }),
  ).toHaveAttribute("href", "https://profile.synthetic.invalid/channel");
});
test("staff can issue an invoice, record a partial payment and download its PDF", async ({
  page,
}) => {
  const user = await database().user.findUniqueOrThrow({ where: { email } }),
    code = randomToken();
  await database().mfaBackupCode.create({
    data: { id: newId(), userId: user.id, codeHash: hashToken(code) },
  });
  await page.goto("/admin/login");
  await page.getByLabel("Staff email").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("Authenticator or backup code").fill(code);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(page).toHaveURL(/\/admin$/);
  const enrollment = await database().enrollment.findFirstOrThrow();
  await page.goto("/admin/invoices");
  await page
    .locator("summary")
    .filter({ hasText: /^Issue an invoice$/ })
    .click();
  await page
    .getByLabel("Active enrollment", { exact: true })
    .selectOption(enrollment.id);
  await page.getByLabel("Currency", { exact: true }).selectOption("GBP");
  await page.getByLabel("Invoice amount", { exact: true }).fill("123.45");
  await page.getByLabel("Due date", { exact: true }).fill("2030-06-30");
  await page
    .locator("form")
    .getByRole("button", { name: "Issue an invoice", exact: true })
    .click();
  await expect.poll(() => database().invoice.count()).toBe(1);
  const invoice = await database().invoice.findFirstOrThrow();
  await expect(
    page.getByRole("cell", { name: invoice.number, exact: true }),
  ).toBeVisible();
  await page.goto("/admin/payments");
  await page
    .locator("summary")
    .filter({ hasText: /^Record a received payment$/ })
    .click();
  await page
    .getByLabel("Unpaid invoice", { exact: true })
    .selectOption(invoice.id);
  await page
    .getByLabel("Received amount (invoice currency)", { exact: true })
    .fill("50.00");
  await page.getByLabel("Payment method", { exact: true }).selectOption("BANK");
  await page.getByLabel("Received date", { exact: true }).fill("2030-06-15");
  await page
    .locator("form")
    .getByRole("button", { name: "Record a received payment", exact: true })
    .click();
  await expect
    .poll(() =>
      database().paymentRecord.count({
        where: { invoiceId: invoice.id, amountMinor: 5000 },
      }),
    )
    .toBe(1);
  await expect(
    page.getByRole("cell", { name: "5000", exact: true }),
  ).toBeVisible();
  await page.goto("/admin/invoices/" + invoice.id);
  const downloading = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Download invoice PDF", exact: true })
    .click();
  const download = await downloading;
  expect(download.suggestedFilename()).toBe(invoice.number + ".pdf");
  const filename = await download.path();
  expect(filename).not.toBeNull();
  const bytes = await readFile(filename);
  const text = execFileSync("pdftotext", ["-", "-"], {
    input: bytes,
    encoding: "utf8",
  });
  expect(text).toContain("£123.45");
  expect(text).toContain("£50.00");
  expect(text).toContain("£73.45");
  expect(
    await database().auditLog.count({
      where: { action: "invoice.pdf_exported", entityId: invoice.id },
    }),
  ).toBe(1);
});
