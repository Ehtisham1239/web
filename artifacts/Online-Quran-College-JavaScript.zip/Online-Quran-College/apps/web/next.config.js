import { resolve } from "node:path";
const config = {
  distDir: process.env.NEXT_DIST_DIR ?? ".next",
  output: process.env.NEXT_DIST_DIR === ".next-e2e" ? undefined : "standalone",
  poweredByHeader: false,
  outputFileTracingRoot: resolve("../.."),
  outputFileTracingIncludes: { "/*": ["./assets/pdf/**/*"] },
  serverExternalPackages: ["pdfkit"],
  devIndicators: false,
  experimental: { cpus: 2, authInterrupts: true },
  turbopack: { resolveAlias: { "next-intl/config": "./src/i18n/request.js" } },
  webpack(config) {
    config.resolve.alias["next-intl/config"] = resolve("src/i18n/request.js");
    return config;
  },
};
export default config;
