import { chromium } from "@playwright/test";
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH ?? "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
try {
  for (const [path, width, height, output] of [
    ["/", 1280, 900, "/tmp/oqc-home-desktop.png"],
    ["/courses", 375, 812, "/tmp/oqc-courses-mobile.png"],
  ]) {
    const page = await browser.newPage({ viewport: { width, height } });
    await page.goto((process.env.APP_URL ?? "http://localhost:3000") + path);
    await page.waitForFunction(
      () => document.documentElement.dataset.hydrated === "true",
    );
    await page.getByRole("heading", { level: 1 }).waitFor();
    if (
      await page
        .getByText("We could not load this page.", { exact: true })
        .count()
    )
      throw new Error(
        "Cannot capture a successful page screenshot from an error boundary",
      );
    await page.evaluate(async () => {
      for (const image of document.images) {
        image.loading = "eager";
        await image.decode();
      }
      await document.fonts.ready;
    });
    await page.screenshot({ path: output, fullPage: true, timeout: 15000 });
    await page.close();
    console.log("Captured " + output);
  }
} finally {
  await browser.close();
}
