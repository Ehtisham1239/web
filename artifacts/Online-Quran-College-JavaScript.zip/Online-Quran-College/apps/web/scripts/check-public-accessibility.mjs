import { chromium } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import { readFile, writeFile } from "node:fs/promises";
const evidence = new URL("../../../docs/evidence/", import.meta.url);
const review = JSON.parse(
  await readFile(new URL("responsive-review.json", evidence), "utf8"),
);
const paths = [...new Set(review.results.map((item) => item.path))];
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH ?? "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
const results = [];
let failed = false;
try {
  for (const width of [375, 1440]) {
    const page = await browser.newPage({ viewport: { width, height: 900 } });
    for (const path of paths) {
      await page.goto(
        (process.env.REVIEW_APP_URL ?? "http://localhost:3200") + path,
      );
      await page.waitForFunction(
        () => document.documentElement.dataset.hydrated === "true",
      );
      const scan = await new AxeBuilder({ page })
        .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"])
        .setLegacyMode(true)
        .analyze();
      const violations = scan.violations.map((item) => ({
        id: item.id,
        impact: item.impact,
        description: item.description,
        help: item.help,
        nodes: item.nodes.map((node) => ({
          target: node.target,
          failureSummary: node.failureSummary,
        })),
      }));
      failed ||= violations.some((item) =>
        ["critical", "serious"].includes(item.impact),
      );
      results.push({ width, path, violations });
    }
    console.log(`Accessibility: scanned ${paths.length} pages at ${width}px`);
    await page.close();
  }
  await writeFile(
    new URL("accessibility-review.json", evidence),
    JSON.stringify(
      {
        checkedAt: new Date().toISOString(),
        scope:
          "Automated axe checks on empty public pages; does not replace manual screen-reader review",
        results,
      },
      null,
      2,
    ),
  );
  console.log(
    `Serious/critical violations: ${results.flatMap((item) => item.violations).filter((item) => ["critical", "serious"].includes(item.impact)).length}`,
  );
  if (failed) process.exitCode = 1;
} finally {
  await browser.close();
}
