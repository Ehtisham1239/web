import "dotenv/config";
import { CreateBucketCommand } from "@aws-sdk/client-s3";
import { storage, bucket } from "../src/lib/media/storage";
if (
  !["localhost", "127.0.0.1"].includes(
    new URL(process.env.S3_ENDPOINT ?? "").hostname,
  )
)
  throw new Error("Local storage initialization only.");
try {
  await storage().send(new CreateBucketCommand({ Bucket: bucket() }));
} catch (error) {
  if (
    !(error instanceof Error) ||
    !["BucketAlreadyOwnedByYou", "BucketAlreadyExists"].includes(error.name)
  )
    throw error;
}
console.log("Local private storage bucket available.");
