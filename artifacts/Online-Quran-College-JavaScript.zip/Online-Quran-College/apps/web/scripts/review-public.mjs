import { chromium } from "@playwright/test";
import { mkdir, writeFile } from "node:fs/promises";
import assert from "node:assert/strict";
const base = process.env.REVIEW_APP_URL ?? "http://localhost:3200";
const output = new URL("../../../docs/evidence/", import.meta.url);
await mkdir(output, { recursive: true });
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH ?? "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
const results = [];
try {
  for (const width of [320, 768, 1440]) {
    const page = await browser.newPage({ viewport: { width, height: 900 } });
    const errors = [];
    page.on("pageerror", (error) => errors.push(error.message));
    for (const path of [
      "/",
      "/about",
      "/courses",
      "/teachers",
      "/pricing",
      "/schedule",
      "/free-trial",
      "/how-it-works",
      "/testimonials",
      "/faq",
      "/blog",
      "/contact",
      "/careers",
      "/privacy",
      "/terms",
      "/refund",
      "/child-safeguarding",
      "/accessibility",
      "/ai-disclosure",
      "/quality-assurance",
      "/certificates",
      "/customer-service",
    ]) {
      const response = await page.goto(base + path);
      assert.equal(response.status(), 200, `${width}px ${path}: response`);
      await page.getByRole("heading", { level: 1 }).waitFor();
      await page.waitForFunction(
        () => document.documentElement.dataset.hydrated === "true",
      );
      assert.equal(
        await page
          .getByText("We could not load this page.", { exact: true })
          .count(),
        0,
        `${path}: error boundary`,
      );
      assert.equal(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= window.innerWidth,
        ),
        true,
        `${width}px ${path}: horizontal overflow`,
      );
      assert.deepEqual(errors, [], `${width}px ${path}: browser errors`);
      results.push({
        width,
        path,
        status: response.status(),
        horizontalOverflow: false,
        browserErrors: 0,
      });
      if (
        (path === "/" && [320, 1440].includes(width)) ||
        (path === "/free-trial" && width === 320)
      ) {
        await page.evaluate(async () => {
          for (const image of document.images) {
            image.loading = "eager";
            await image.decode();
          }
          await document.fonts.ready;
        });
        await page.screenshot({
          path: new URL(
            `website-${path === "/" ? "home" : "trial"}-${width}.png`,
            output,
          ).pathname,
          fullPage: true,
        });
      }
    }
    const missing = await page.goto(base + "/synthetic-missing-website-review");
    assert.equal(missing.status(), 404);
    await page.close();
    console.log(
      `Reviewed ${results.filter((item) => item.width === width).length} public routes at ${width}px; missing route returned 404`,
    );
  }
  await writeFile(
    new URL("responsive-review.json", output),
    JSON.stringify(
      {
        checkedAt: new Date().toISOString(),
        runtime:
          "compiled production output with local test configuration and empty developer database",
        results,
      },
      null,
      2,
    ),
  );
} finally {
  await browser.close();
}
