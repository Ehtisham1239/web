import { createRequire } from "node:module";
import { mkdtemp, mkdir, writeFile, symlink, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve, join, relative } from "node:path";
import assert from "node:assert/strict";
const require = createRequire(import.meta.url);
const registry = createRequire(
  require.resolve("@prisma/client-generator-registry"),
);
const generator = createRequire(
  registry.resolve("@prisma/client-generator-ts"),
);
const config = createRequire(require.resolve("eslint-config-next"));
const nextLint = createRequire(config.resolve("@next/eslint-plugin-next"));
const { glob } = generator("fast-glob"),
  { globSync } = nextLint("fast-glob");
const base = await mkdtemp(join(tmpdir(), "oqc-glob-compatibility-"));
try {
  const output = join(base, "generated");
  await mkdir(join(output, "models"), { recursive: true });
  await mkdir(join(base, "outside"));
  const files = [
    "client.ts",
    "models/Course.ts",
    "models/Student.d.ts",
    "loader.mts",
    "legacy.cts",
    "engine.wasm",
    "native.node",
    "query-engine-local",
    "schema-engine-local",
    "package.json",
    "schema.prisma",
  ];
  for (const file of [...files, "keep.txt"])
    await writeFile(
      join(output, file),
      "synthetic package compatibility probe",
    );
  await writeFile(join(base, "outside/private.ts"), "synthetic outside file");
  await symlink(join(base, "outside"), join(output, "linked"));
  const selected = await glob(
    [
      `${output}/**/*.{js,ts,mts,cts,d.ts}`,
      `${output}/**/*.wasm`,
      `${output}/*.node`,
      `${output}/{query,schema}-engine-*`,
      `${output}/package.json`,
      `${output}/**/*.prisma`,
    ],
    { followSymbolicLinks: false },
  );
  assert.deepEqual(
    selected.map((file) => relative(output, resolve(file))).sort(),
    [...files].sort(),
  );
  await mkdir(join(base, "roots/one"), { recursive: true });
  await mkdir(join(base, "roots/two"));
  for (const pattern of [`${base}/roots/*`, `${base}/roots/{one,two}`])
    assert.deepEqual(
      globSync(pattern, { onlyDirectories: true })
        .map((file) => resolve(file))
        .sort(),
      [resolve(base, "roots/one"), resolve(base, "roots/two")].sort(),
    );
  console.log(
    "Prisma cleanup scope and Next lint directory discovery passed; symlink traversal and unrelated files excluded.",
  );
} finally {
  await rm(base, { recursive: true, force: true });
}
