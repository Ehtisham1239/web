import { loadEngine, filters, shutdownEngine } from "./schema-engine.mjs";
import { readFile, mkdir, writeFile } from "node:fs/promises";
const schema = await readFile("prisma/schema.prisma", "utf8");
const engine = await loadEngine();
try {
  const result = await engine.diff({
    from: { tag: "empty" },
    to: {
      tag: "schemaDatamodel",
      files: [{ path: "schema.prisma", content: schema }],
    },
    script: true,
    exitCode: false,
    filters,
  });
  await mkdir("prisma/migrations/202610110001_initial", { recursive: true });
  await writeFile(
    "prisma/migrations/202610110001_initial/migration.sql",
    "CREATE EXTENSION IF NOT EXISTS citext;\nCREATE EXTENSION IF NOT EXISTS pg_trgm;\nCREATE EXTENSION IF NOT EXISTS btree_gist;\nCREATE EXTENSION IF NOT EXISTS vector;\n" +
      result.stdout,
  );
  await writeFile(
    "prisma/migrations/migration_lock.toml",
    'provider = "postgresql"\n',
  );
  console.log("Generated initial migration using Prisma WASM");
} finally {
  await shutdownEngine(engine);
}

process.exit(0);
