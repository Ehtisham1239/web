import { mkdir, writeFile } from "node:fs/promises";
import {
  permissionKeys,
  permissionMatrix,
  roles,
} from "../src/lib/rbac/policy";
import { v7 } from "uuid";
let sql = "-- System constants only. No business content.\n";
for (const role of roles)
  sql += `INSERT INTO "Role" (id,key,name,"updatedAt") VALUES ('${v7()}','${role}','${role.replaceAll("_", " ")}',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;\n`;
for (const permission of permissionKeys)
  sql += `INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('${v7()}','${permission}','${permission}',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;\n`;
for (const role of roles)
  for (const permission of permissionMatrix[role])
    sql += `INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '${v7()}',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='${role}' AND p.key='${permission}' ON CONFLICT ("roleId","permissionId") DO NOTHING;\n`;
sql += `
ALTER TABLE "ClassSession" ADD CONSTRAINT teacher_no_overlap EXCLUDE USING gist ("teacherId" WITH =,tstzrange("startsAtUtc","endsAtUtc",'[)') WITH &&) WHERE (status <> 'CANCELLED');
ALTER TABLE "ClassSession" ADD CONSTRAINT student_no_overlap EXCLUDE USING gist ("studentId" WITH =,tstzrange("startsAtUtc","endsAtUtc",'[)') WITH &&) WHERE (status <> 'CANCELLED' AND "studentId" IS NOT NULL);
ALTER TABLE "ClassSession" ADD CONSTRAINT session_positive_duration CHECK ("endsAtUtc">"startsAtUtc");
ALTER TABLE "ClassSession" ADD CONSTRAINT session_kind_target CHECK ((kind='TRIAL' AND "trialId" IS NOT NULL AND "scheduleId" IS NULL) OR (kind='REGULAR' AND "scheduleId" IS NOT NULL AND "studentId" IS NOT NULL AND "trialId" IS NULL));
ALTER TABLE "TeacherAvailability" ADD CONSTRAINT availability_bounds CHECK (weekday BETWEEN 1 AND 7 AND "startMinute" BETWEEN 0 AND 1439 AND "endMinute" BETWEEN 1 AND 1440 AND "endMinute">"startMinute");
ALTER TABLE "ClassSchedule" ADD CONSTRAINT schedule_bounds CHECK (weekday BETWEEN 1 AND 7 AND "startMinute" BETWEEN 0 AND 1439 AND "durationMin" BETWEEN 1 AND 240);
CREATE UNIQUE INDEX enrollment_active_unique ON "Enrollment" ("studentId","courseId") WHERE status IN ('ACTIVE','PAUSED') AND "deletedAt" IS NULL;
ALTER TABLE "Testimonial" ADD CONSTRAINT consent_before_publish CHECK (status <> 'PUBLISHED' OR "consentRecordedAt" IS NOT NULL);
ALTER TABLE "TrialApplication" ADD CONSTRAINT trial_consent CHECK ("consentGiven" IS TRUE);
ALTER TABLE "PricingPlanPrice" ADD CONSTRAINT price_nonnegative CHECK ("amountMinor">=0 AND currency ~ '^[A-Z]{3}$');
ALTER TABLE "Invoice" ADD CONSTRAINT invoice_nonnegative CHECK ("totalMinor">=0 AND currency ~ '^[A-Z]{3}$');
ALTER TABLE "PaymentRecord" ADD CONSTRAINT payment_positive CHECK ("amountMinor">0);
CREATE SEQUENCE invoice_number_seq;
CREATE FUNCTION audit_immutable() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'Audit log is append-only'; END; $$;
CREATE TRIGGER audit_immutable BEFORE UPDATE OR DELETE ON "AuditLog" FOR EACH ROW EXECUTE FUNCTION audit_immutable();
CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON "AuditLog" FOR EACH STATEMENT EXECUTE FUNCTION audit_immutable();
CREATE INDEX course_search_idx ON "Course" USING gin (to_tsvector('english', title || ' ' || summary));
CREATE INDEX teacher_name_idx ON "Teacher" USING gin ("displayName" gin_trgm_ops);
CREATE INDEX student_name_idx ON "Student" USING gin ("fullName" gin_trgm_ops);
CREATE INDEX ai_embedding_idx ON "AIKnowledgeChunk" USING hnsw (embedding vector_cosine_ops);
`;
await mkdir("prisma/migrations/202610110002_system_constraints", {
  recursive: true,
});
await writeFile(
  "prisma/migrations/202610110002_system_constraints/migration.sql",
  sql,
);
console.log("System constants and database constraints migration written");
