import pg from "pg";
import { randomBytes } from "node:crypto";
import { execFileSync, spawn } from "node:child_process";
const name = "oqc_e2e_" + randomBytes(8).toString("hex");
const control = new pg.Pool({
  connectionString: "postgresql://oqc:oqc@localhost:5432/postgres",
});
await control.query(`CREATE DATABASE "${name}"`);
const env = {
  ...process.env,
  NODE_ENV: "test",
  NEXT_DIST_DIR: ".next-e2e",
  APP_URL: "http://localhost:3100",
  DATABASE_URL: `postgresql://oqc:oqc@localhost:5432/${name}`,
  AUTH_SECRET: randomBytes(48).toString("base64url"),
  AI_ENABLED: "false",
  REDIS_URL: "",
  RATE_LIMIT_DRIVER: "postgres",
  DIRECT_URL: "",
};
let code = 1;
try {
  execFileSync(process.execPath, ["scripts/migrate.mjs"], {
    env,
    stdio: "inherit",
  });
  execFileSync(process.execPath, ["scripts/next.mjs", "build"], {
    env: { ...env, NODE_ENV: "production" },
    stdio: "inherit",
  });
  const child = spawn(
    "pnpm",
    [
      "exec",
      "playwright",
      "test",
      ...process.argv.slice(2),
      ...(process.argv
        .slice(2)
        .some((argument) => argument.startsWith("--project"))
        ? []
        : ["--project=chromium"]),
    ],
    { env, stdio: "inherit" },
  );
  code = await new Promise((resolve) =>
    child.on("exit", (code) => resolve(code ?? 1)),
  );
} finally {
  await control.query(`DROP DATABASE "${name}" WITH (FORCE)`);
  await control.end();
}
process.exitCode = code;
