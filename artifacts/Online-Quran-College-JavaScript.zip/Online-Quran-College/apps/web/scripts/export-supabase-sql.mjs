import { readdir, readFile, mkdir, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { resolve } from "node:path";

const root = resolve("prisma/migrations");
const folders = (await readdir(root, { withFileTypes: true }))
  .filter((item) => item.isDirectory())
  .map((item) => item.name)
  .sort();
let sql = `-- Online Quran College: generated from the versioned PostgreSQL migrations.
-- Run in the Supabase SQL editor as postgres, on a dedicated project.
-- This is repeatable: completed migrations are checked and skipped.
-- Do not edit this generated file; run pnpm db:sql after adding a migration.
BEGIN;
SET LOCAL search_path = public, extensions;
SELECT pg_advisory_xact_lock(746372901);
CREATE TABLE IF NOT EXISTS public._prisma_migrations (
  id VARCHAR(36) PRIMARY KEY NOT NULL, checksum VARCHAR(64) NOT NULL,
  finished_at TIMESTAMPTZ, migration_name VARCHAR(255) NOT NULL,
  logs TEXT, rolled_back_at TIMESTAMPTZ,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(), applied_steps_count INTEGER NOT NULL DEFAULT 0
);
`;
for (const folder of folders) {
  const source = await readFile(resolve(root, folder, "migration.sql"), "utf8");
  const checksum = createHash("sha256").update(source).digest("hex");
  const id = [
    checksum.slice(0, 8),
    checksum.slice(8, 12),
    checksum.slice(12, 16),
    checksum.slice(16, 20),
    checksum.slice(20, 32),
  ].join("-");
  sql += `
DO $migration$
BEGIN
  IF EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '${folder}' AND rolled_back_at IS NULL AND (checksum <> '${checksum}' OR finished_at IS NULL)) THEN
    RAISE EXCEPTION 'Migration ${folder} is changed or incomplete; inspect before continuing';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '${folder}' AND finished_at IS NOT NULL AND rolled_back_at IS NULL) THEN
    EXECUTE $source$
${source}
$source$;
    INSERT INTO public._prisma_migrations (id, checksum, migration_name, finished_at, applied_steps_count)
      VALUES ('${id}', '${checksum}', '${folder}', now(), 1);
  END IF;
END
$migration$;
`;
}
sql += "\nCOMMIT;\n";
await mkdir("../../supabase", { recursive: true });
await writeFile("../../supabase/schema.sql", sql);
console.log(`Exported ${folders.length} migrations to supabase/schema.sql`);
