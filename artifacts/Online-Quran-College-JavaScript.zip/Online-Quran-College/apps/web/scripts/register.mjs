import { registerHooks } from "node:module";
import { existsSync, statSync } from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";

// Native Node 24 resolution for the same aliases used by Next.js and Vitest.
const source = new URL("../src/", import.meta.url);
registerHooks({
  resolve(specifier, context, nextResolve) {
    if (context.conditions.includes("require"))
      return nextResolve(specifier, context);
    if (specifier.startsWith("@/") || specifier.startsWith(".")) {
      const url = specifier.startsWith("@/")
        ? new URL(specifier.slice(2), source)
        : new URL(specifier, context.parentURL);
      if (url.protocol === "file:") {
        const base = fileURLToPath(url);
        const found = [base, base + ".js", base + "/index.js"].find(
          (file) => existsSync(file) && statSync(file).isFile(),
        );
        if (found) specifier = pathToFileURL(found).href;
      }
    }
    return nextResolve(
      specifier,
      specifier.endsWith(".json")
        ? {
            ...context,
            importAttributes: { ...context.importAttributes, type: "json" },
          }
        : context,
    );
  },
});
