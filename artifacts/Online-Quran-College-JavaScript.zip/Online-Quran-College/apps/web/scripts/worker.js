import "dotenv/config";
import { PgBoss } from "pg-boss";
import { runMaintenance } from "../src/server/services/maintenance";
import { database } from "../src/lib/db";
import { runtimeEnv } from "../src/lib/platform/env";
import { validateDatabaseUrl } from "../src/lib/platform/env";
const config = runtimeEnv();
const boss = new PgBoss({
  connectionString: validateDatabaseUrl(
    config.DIRECT_URL || config.DATABASE_URL,
  ),
  schema: "pgboss",
});
boss.on("error", () =>
  console.error("Worker queue error; consult restricted operator diagnostics."),
);
await boss.start();
await boss.createQueue("outbox-drain", {
  retryLimit: 5,
  retryDelay: 10,
  retryBackoff: true,
});
await boss.work("outbox-drain", async () => {
  await runMaintenance();
});
await boss.schedule("outbox-drain", "* * * * *");
await boss.send(
  "outbox-drain",
  {},
  { singletonKey: "periodic-drain", singletonSeconds: 60 },
);
console.log(
  "Internal notification worker running. Outbound delivery disabled.",
);
let stopping = false;
async function stop() {
  if (stopping) return;
  stopping = true;
  await boss.stop({ graceful: true, timeout: 15000 });
  await database().$disconnect();
  process.exit(0);
}
process.once("SIGINT", () => void stop());
process.once("SIGTERM", () => void stop());
