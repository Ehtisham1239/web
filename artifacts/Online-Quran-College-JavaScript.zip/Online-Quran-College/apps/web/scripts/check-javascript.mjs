import { readdir, readFile } from "node:fs/promises";
import { join } from "node:path";
import ts from "typescript";

let count = 0;
async function check(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (
      [
        "node_modules",
        "generated",
        ".runtime",
        "test-results",
        "playwright-report",
      ].includes(entry.name) ||
      entry.name.startsWith(".next")
    )
      continue;
    const file = join(directory, entry.name);
    if (entry.isDirectory()) {
      await check(file);
      continue;
    }
    if (/\.tsx?$/.test(file))
      throw new Error(`Unexpected TypeScript source: ${file}`);
    if (!/\.(js|jsx|mjs)$/.test(file)) continue;
    const result = ts.transpileModule(await readFile(file, "utf8"), {
      fileName: file,
      compilerOptions: {
        allowJs: true,
        target: ts.ScriptTarget.ESNext,
        module: ts.ModuleKind.ESNext,
        jsx: ts.JsxEmit.Preserve,
      },
      reportDiagnostics: true,
    });
    const errors = result.diagnostics.filter(
      (item) => item.category === ts.DiagnosticCategory.Error,
    );
    if (errors.length)
      throw new Error(
        file +
          ": " +
          errors
            .map((item) =>
              ts.flattenDiagnosticMessageText(item.messageText, "\n"),
            )
            .join("\n"),
      );
    count++;
  }
}
await check(".");
console.log(
  `JavaScript syntax checked: ${count} files. Application source contains no TypeScript.`,
);
