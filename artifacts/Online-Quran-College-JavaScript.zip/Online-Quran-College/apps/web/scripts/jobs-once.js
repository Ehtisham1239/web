import "dotenv/config";
import { database } from "@/lib/db";
import { runMaintenance } from "@/server/services/maintenance";

try {
  console.log(JSON.stringify(await runMaintenance()));
} finally {
  await database().$disconnect();
}
