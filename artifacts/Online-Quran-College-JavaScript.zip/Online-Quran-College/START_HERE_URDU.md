# Shuru kaisay karein

Aapki di hui dono ZIP files ek jaisi thin. Usi Online Quran College project ko JavaScript/JSX mein convert aur update kiya gaya hai.

1. Local computer par Node 24 aur Docker install karein. Project folder mein `bash infra/scripts/setup-cloud.sh` chalayein.
2. `pnpm dev` se website chalayein. Doosre terminal mein `pnpm worker` chalayein.
3. Supabase ke liye apne project ke SQL Editor mein `supabase/schema.sql` chalayein. Database ki private connection strings host ki environment settings mein dein; template `.env.supabase.example` hai.
4. Admin account banane ke liye private `BOOTSTRAP_TOKEN` set karke `pnpm bootstrap:admin --email apna-email` chalayein. Password terminal mein poocha jayega. MFA setup ke baad bootstrap token hata dein.
5. Node.js/Docker support walay host ya Vercel par deploy kar sakte hain. Mukammal commands `docs/DEPLOYMENT.md` mein hain.

Domain ka step aapki hidayat ke mutabiq skip hai. Live Supabase project is workspace se create nahi kiya gaya. Apne actual courses, teachers, fees aur contact details admin se add karein. Koi default password ya farzi business data shamil nahi kiya gaya.
