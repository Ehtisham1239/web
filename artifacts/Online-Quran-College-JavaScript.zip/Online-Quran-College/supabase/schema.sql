-- Online Quran College: generated from the versioned PostgreSQL migrations.
-- Run in the Supabase SQL editor as postgres, on a dedicated project.
-- This is repeatable: completed migrations are checked and skipped.
-- Do not edit this generated file; run pnpm db:sql after adding a migration.
BEGIN;
SET LOCAL search_path = public, extensions;
SELECT pg_advisory_xact_lock(746372901);
CREATE TABLE IF NOT EXISTS public._prisma_migrations (
  id VARCHAR(36) PRIMARY KEY NOT NULL, checksum VARCHAR(64) NOT NULL,
  finished_at TIMESTAMPTZ, migration_name VARCHAR(255) NOT NULL,
  logs TEXT, rolled_back_at TIMESTAMPTZ,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(), applied_steps_count INTEGER NOT NULL DEFAULT 0
);

DO $migration$
BEGIN
  IF EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '202610110001_initial' AND rolled_back_at IS NULL AND (checksum <> 'ff4ac0106e960a71fbc9586d9724962cd764cd9f1d46b2274a0c71143fb84300' OR finished_at IS NULL)) THEN
    RAISE EXCEPTION 'Migration 202610110001_initial is changed or incomplete; inspect before continuing';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '202610110001_initial' AND finished_at IS NOT NULL AND rolled_back_at IS NULL) THEN
    EXECUTE $source$
CREATE EXTENSION IF NOT EXISTS citext;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS btree_gist;
CREATE EXTENSION IF NOT EXISTS vector;
-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "public";

-- CreateEnum
CREATE TYPE "ContentStatus" AS ENUM ('DRAFT', 'SUBMITTED', 'APPROVED', 'PUBLISHED', 'ARCHIVED');

-- CreateEnum
CREATE TYPE "TrialStatus" AS ENUM ('NEW', 'REVIEWED', 'SCHEDULED', 'COMPLETED', 'ENROLLED', 'CANCELLED', 'NO_SHOW');

-- CreateEnum
CREATE TYPE "ContactStatus" AS ENUM ('NEW', 'READ', 'REPLIED', 'SPAM', 'ARCHIVED');

-- CreateEnum
CREATE TYPE "EnrollmentStatus" AS ENUM ('ACTIVE', 'PAUSED', 'COMPLETED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "SessionStatus" AS ENUM ('PLANNED', 'HELD', 'CANCELLED', 'RESCHEDULED');

-- CreateEnum
CREATE TYPE "AttendanceStatus" AS ENUM ('PRESENT', 'ABSENT', 'LATE', 'EXCUSED');

-- CreateEnum
CREATE TYPE "InvoiceStatus" AS ENUM ('DRAFT', 'ISSUED', 'PAID', 'VOID');

-- CreateEnum
CREATE TYPE "PaymentMethod" AS ENUM ('BANK', 'CARD_EXTERNAL', 'CASH', 'OTHER');

-- CreateEnum
CREATE TYPE "PageTemplate" AS ENUM ('STANDARD', 'COURSE_LISTING', 'LOCATION_LANDING', 'AUDIENCE_LANDING', 'POLICY');

-- CreateEnum
CREATE TYPE "SectionType" AS ENUM ('HERO', 'FEATURES', 'COURSES_GRID', 'TEACHERS', 'PRICING_TEASER', 'TESTIMONIALS', 'FAQ', 'CTA', 'RICH_TEXT');

-- CreateTable
CREATE TABLE "Role" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "key" TEXT NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "Role_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Permission" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "key" TEXT NOT NULL,
    "description" TEXT NOT NULL,

    CONSTRAINT "Permission_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RolePermission" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "roleId" UUID NOT NULL,
    "permissionId" UUID NOT NULL,

    CONSTRAINT "RolePermission_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "User" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "email" CITEXT NOT NULL,
    "name" TEXT NOT NULL,
    "passwordHash" TEXT NOT NULL,
    "roleId" UUID NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT false,
    "mustEnrollMfa" BOOLEAN NOT NULL DEFAULT true,
    "mfaEnabled" BOOLEAN NOT NULL DEFAULT false,
    "lastMfaStep" INTEGER,
    "mfaSecretEnc" TEXT,
    "lastLoginAt" TIMESTAMPTZ(3),
    "failedLogins" INTEGER NOT NULL DEFAULT 0,
    "lockedUntil" TIMESTAMPTZ(3),

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Session" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "userId" UUID NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "csrfHash" TEXT NOT NULL,
    "expiresAt" TIMESTAMPTZ(3) NOT NULL,
    "lastSeenAt" TIMESTAMPTZ(3) NOT NULL,
    "reauthenticatedAt" TIMESTAMPTZ(3),
    "ipHash" TEXT,
    "userAgent" TEXT,

    CONSTRAINT "Session_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PasswordResetToken" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "userId" UUID NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "expiresAt" TIMESTAMPTZ(3) NOT NULL,
    "usedAt" TIMESTAMPTZ(3),

    CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "InviteToken" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "userId" UUID NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "expiresAt" TIMESTAMPTZ(3) NOT NULL,
    "usedAt" TIMESTAMPTZ(3),

    CONSTRAINT "InviteToken_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MfaSetupToken" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "userId" UUID NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "expiresAt" TIMESTAMPTZ(3) NOT NULL,
    "usedAt" TIMESTAMPTZ(3),

    CONSTRAINT "MfaSetupToken_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MfaBackupCode" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "userId" UUID NOT NULL,
    "codeHash" TEXT NOT NULL,
    "usedAt" TIMESTAMPTZ(3),

    CONSTRAINT "MfaBackupCode_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "actorId" UUID,
    "action" TEXT NOT NULL,
    "entityType" TEXT NOT NULL,
    "entityId" TEXT,
    "before" JSONB,
    "after" JSONB,
    "ipHash" TEXT,
    "userAgent" TEXT,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Course" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "slug" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "summary" TEXT NOT NULL,
    "description" JSONB NOT NULL DEFAULT '{}',
    "ageGroup" TEXT NOT NULL,
    "level" TEXT NOT NULL,
    "durationText" TEXT,
    "status" "ContentStatus" NOT NULL DEFAULT 'DRAFT',
    "category" TEXT NOT NULL DEFAULT 'REGULAR',
    "seoTitle" TEXT,
    "seoDescription" TEXT,
    "ogImageId" UUID,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "publishedAt" TIMESTAMPTZ(3),
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "Course_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CourseModule" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "courseId" UUID NOT NULL,
    "title" TEXT NOT NULL,
    "objectives" TEXT NOT NULL,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "CourseModule_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Teacher" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "slug" TEXT NOT NULL,
    "displayName" TEXT NOT NULL,
    "gender" TEXT NOT NULL,
    "bio" TEXT NOT NULL,
    "qualificationsText" TEXT,
    "languages" TEXT[],
    "photoId" UUID,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "isPublic" BOOLEAN NOT NULL DEFAULT false,
    "verificationNote" TEXT,
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "Teacher_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TeacherCourse" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "teacherId" UUID NOT NULL,
    "courseId" UUID NOT NULL,

    CONSTRAINT "TeacherCourse_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TeacherAvailability" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "teacherId" UUID NOT NULL,
    "weekday" INTEGER NOT NULL,
    "startMinute" INTEGER NOT NULL,
    "endMinute" INTEGER NOT NULL,
    "timezone" TEXT NOT NULL,

    CONSTRAINT "TeacherAvailability_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TrialApplication" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "reference" TEXT NOT NULL,
    "learnerName" TEXT NOT NULL,
    "guardianName" TEXT,
    "email" CITEXT NOT NULL,
    "phoneE164" TEXT NOT NULL,
    "country" TEXT NOT NULL,
    "timezone" TEXT NOT NULL,
    "ageBand" TEXT NOT NULL,
    "courseId" UUID NOT NULL,
    "level" TEXT NOT NULL,
    "teacherGenderPref" TEXT NOT NULL,
    "teachingLanguage" TEXT NOT NULL,
    "availableSlots" JSONB NOT NULL,
    "notes" TEXT,
    "consentGiven" BOOLEAN NOT NULL,
    "consentTextVersion" TEXT NOT NULL,
    "consentAt" TIMESTAMPTZ(3) NOT NULL,
    "status" "TrialStatus" NOT NULL DEFAULT 'NEW',
    "assignedToUserId" UUID,
    "assignedTeacherId" UUID,
    "trialSessionAtUtc" TIMESTAMPTZ(3),
    "duplicateOfId" UUID,
    "idempotencyKey" TEXT NOT NULL,
    "ipHash" TEXT NOT NULL,
    "userAgent" TEXT,
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "TrialApplication_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TrialHistory" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "trialId" UUID NOT NULL,
    "fromStatus" "TrialStatus",
    "toStatus" "TrialStatus" NOT NULL,
    "actorId" UUID,
    "note" TEXT,

    CONSTRAINT "TrialHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TrialNote" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "trialId" UUID NOT NULL,
    "authorId" UUID NOT NULL,
    "body" TEXT NOT NULL,

    CONSTRAINT "TrialNote_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ContactMessage" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "name" TEXT NOT NULL,
    "email" CITEXT NOT NULL,
    "phone" TEXT,
    "country" TEXT,
    "city" TEXT,
    "subject" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "consentTextVersion" TEXT NOT NULL,
    "consentAt" TIMESTAMPTZ(3) NOT NULL,
    "status" "ContactStatus" NOT NULL DEFAULT 'NEW',
    "spamScore" INTEGER NOT NULL DEFAULT 0,
    "assignedToUserId" UUID,
    "repliedAt" TIMESTAMPTZ(3),
    "repliedById" UUID,
    "ipHash" TEXT NOT NULL,

    CONSTRAINT "ContactMessage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Student" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "fullName" TEXT NOT NULL,
    "dob" DATE,
    "ageBand" TEXT NOT NULL,
    "country" TEXT NOT NULL,
    "timezone" TEXT NOT NULL,
    "notes" TEXT,
    "status" TEXT NOT NULL DEFAULT 'ACTIVE',
    "createdFromTrialId" UUID,

    CONSTRAINT "Student_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Guardian" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "fullName" TEXT NOT NULL,
    "email" CITEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "relationship" TEXT NOT NULL,
    "country" TEXT NOT NULL,

    CONSTRAINT "Guardian_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "StudentGuardian" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "studentId" UUID NOT NULL,
    "guardianId" UUID NOT NULL,
    "isPrimary" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "StudentGuardian_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Enrollment" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "studentId" UUID NOT NULL,
    "courseId" UUID NOT NULL,
    "teacherId" UUID NOT NULL,
    "planId" UUID,
    "status" "EnrollmentStatus" NOT NULL DEFAULT 'ACTIVE',
    "startDate" DATE NOT NULL,
    "endDate" DATE,
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "Enrollment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ClassSchedule" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "enrollmentId" UUID NOT NULL,
    "teacherId" UUID NOT NULL,
    "weekday" INTEGER NOT NULL,
    "startMinute" INTEGER NOT NULL,
    "durationMin" INTEGER NOT NULL,
    "timezone" TEXT NOT NULL,
    "meetingUrl" TEXT,
    "effectiveFrom" DATE NOT NULL,
    "effectiveTo" DATE,
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "ClassSchedule_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ClassSession" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "scheduleId" UUID,
    "trialId" UUID,
    "teacherId" UUID NOT NULL,
    "studentId" UUID,
    "startsAtUtc" TIMESTAMPTZ(3) NOT NULL,
    "endsAtUtc" TIMESTAMPTZ(3) NOT NULL,
    "status" "SessionStatus" NOT NULL DEFAULT 'PLANNED',
    "kind" TEXT NOT NULL DEFAULT 'REGULAR',
    "meetingUrl" TEXT,
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "ClassSession_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Attendance" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "sessionId" UUID NOT NULL,
    "enrollmentId" UUID NOT NULL,
    "status" "AttendanceStatus" NOT NULL,
    "note" TEXT,

    CONSTRAINT "Attendance_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ProgressRecord" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "enrollmentId" UUID NOT NULL,
    "sessionId" UUID,
    "authorId" UUID NOT NULL,
    "summary" TEXT NOT NULL,
    "lessonRef" TEXT,
    "level" TEXT,

    CONSTRAINT "ProgressRecord_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PricingPlan" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "courseId" UUID,
    "name" TEXT NOT NULL,
    "billingPeriod" TEXT NOT NULL,
    "classesPerWeek" INTEGER NOT NULL,
    "durationMin" INTEGER NOT NULL,
    "isPublic" BOOLEAN NOT NULL DEFAULT false,
    "status" "ContentStatus" NOT NULL DEFAULT 'DRAFT',
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "PricingPlan_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PricingPlanPrice" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "planId" UUID NOT NULL,
    "currency" CHAR(3) NOT NULL,
    "amountMinor" INTEGER NOT NULL,
    "isPublic" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "PricingPlanPrice_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Invoice" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "number" TEXT NOT NULL,
    "enrollmentId" UUID NOT NULL,
    "currency" CHAR(3) NOT NULL,
    "totalMinor" INTEGER NOT NULL,
    "status" "InvoiceStatus" NOT NULL DEFAULT 'DRAFT',
    "issuedAt" TIMESTAMPTZ(3),
    "dueAt" TIMESTAMPTZ(3),
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "Invoice_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PaymentRecord" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "deletedAt" TIMESTAMPTZ(3),
    "invoiceId" UUID NOT NULL,
    "amountMinor" INTEGER NOT NULL,
    "method" "PaymentMethod" NOT NULL,
    "reference" TEXT,
    "receivedAt" TIMESTAMPTZ(3) NOT NULL,
    "recordedById" UUID NOT NULL,

    CONSTRAINT "PaymentRecord_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CMSPage" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "slug" TEXT NOT NULL,
    "locale" TEXT NOT NULL DEFAULT 'en',
    "title" TEXT NOT NULL,
    "status" "ContentStatus" NOT NULL DEFAULT 'DRAFT',
    "template" "PageTemplate" NOT NULL DEFAULT 'STANDARD',
    "seoTitle" TEXT,
    "seoDescription" TEXT,
    "canonicalUrl" TEXT,
    "publishedAt" TIMESTAMPTZ(3),
    "currentRevisionId" TEXT,
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "CMSPage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PageSection" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "pageId" UUID NOT NULL,
    "type" "SectionType" NOT NULL,
    "data" JSONB NOT NULL,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "isVisible" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "PageSection_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ContentRevision" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "entityType" TEXT NOT NULL,
    "entityId" UUID NOT NULL,
    "snapshot" JSONB NOT NULL,
    "authorId" UUID NOT NULL,

    CONSTRAINT "ContentRevision_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BlogPost" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "slug" TEXT NOT NULL,
    "locale" TEXT NOT NULL DEFAULT 'en',
    "title" TEXT NOT NULL,
    "excerpt" TEXT NOT NULL,
    "body" JSONB NOT NULL,
    "renderedHtml" TEXT NOT NULL,
    "coverId" UUID,
    "authorId" UUID NOT NULL,
    "tags" TEXT[],
    "status" "ContentStatus" NOT NULL DEFAULT 'DRAFT',
    "scheduledAt" TIMESTAMPTZ(3),
    "publishedAt" TIMESTAMPTZ(3),
    "seoTitle" TEXT,
    "seoDescription" TEXT,
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "BlogPost_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MediaAsset" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "storageKey" TEXT NOT NULL,
    "mimeType" TEXT NOT NULL,
    "sizeBytes" INTEGER NOT NULL,
    "width" INTEGER,
    "height" INTEGER,
    "altText" TEXT,
    "caption" TEXT,
    "uploadedById" UUID NOT NULL,
    "checksum" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'PENDING',

    CONSTRAINT "MediaAsset_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FAQ" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "question" TEXT NOT NULL,
    "answer" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "locale" TEXT NOT NULL DEFAULT 'en',
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "status" "ContentStatus" NOT NULL DEFAULT 'DRAFT',
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "FAQ_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Testimonial" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "name" TEXT NOT NULL,
    "role" TEXT NOT NULL,
    "country" TEXT NOT NULL,
    "quote" TEXT NOT NULL,
    "consentRecordedAt" TIMESTAMPTZ(3),
    "status" "ContentStatus" NOT NULL DEFAULT 'DRAFT',
    "version" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "Testimonial_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MenuItem" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "menu" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "href" TEXT NOT NULL,
    "parentId" UUID,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "MenuItem_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Setting" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "key" TEXT NOT NULL,
    "value" JSONB NOT NULL,
    "isPublic" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "Setting_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Redirect" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "fromPath" TEXT NOT NULL,
    "toPath" TEXT NOT NULL,
    "statusCode" INTEGER NOT NULL DEFAULT 308,

    CONSTRAINT "Redirect_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Notification" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "userId" UUID NOT NULL,
    "kind" TEXT NOT NULL,
    "entityId" TEXT,
    "readAt" TIMESTAMPTZ(3),

    CONSTRAINT "Notification_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "OutboxEvent" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "kind" TEXT NOT NULL,
    "payload" JSONB NOT NULL,
    "processedAt" TIMESTAMPTZ(3),
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "errorCode" TEXT,

    CONSTRAINT "OutboxEvent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "IdempotencyRecord" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "key" TEXT NOT NULL,
    "requestHash" TEXT NOT NULL,
    "response" JSONB NOT NULL,
    "expiresAt" TIMESTAMPTZ(3) NOT NULL,

    CONSTRAINT "IdempotencyRecord_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PrivacyRequest" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "studentId" UUID,
    "kind" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'NEW',
    "verifiedAt" TIMESTAMPTZ(3),
    "dueAt" TIMESTAMPTZ(3) NOT NULL,
    "completedAt" TIMESTAMPTZ(3),
    "notes" TEXT,

    CONSTRAINT "PrivacyRequest_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Certificate" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "enrollmentId" UUID NOT NULL,
    "number" TEXT NOT NULL,
    "issuedAt" TIMESTAMPTZ(3) NOT NULL,
    "status" TEXT NOT NULL,
    "approvedById" UUID NOT NULL,

    CONSTRAINT "Certificate_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AIKnowledgeDocument" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "sourceType" TEXT NOT NULL,
    "sourceId" TEXT NOT NULL,
    "version" INTEGER NOT NULL,
    "status" "ContentStatus" NOT NULL,
    "approvedById" UUID,
    "approvedAt" TIMESTAMPTZ(3),

    CONSTRAINT "AIKnowledgeDocument_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AIKnowledgeChunk" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "documentId" UUID NOT NULL,
    "text" TEXT NOT NULL,
    "tokenCount" INTEGER NOT NULL,
    "embedding" vector(1536),
    "metadata" JSONB NOT NULL,
    "locale" TEXT NOT NULL,
    "visibility" TEXT NOT NULL,

    CONSTRAINT "AIKnowledgeChunk_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AIConfiguration" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "key" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT false,
    "promptVersion" TEXT,
    "model" TEXT,
    "limits" JSONB NOT NULL DEFAULT '{}',

    CONSTRAINT "AIConfiguration_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AIFeedback" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "feature" TEXT NOT NULL,
    "rating" INTEGER NOT NULL,
    "redactedComment" TEXT,

    CONSTRAINT "AIFeedback_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AIEvaluationRun" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "suiteVersion" TEXT NOT NULL,
    "model" TEXT NOT NULL,
    "promptVersion" TEXT NOT NULL,
    "results" JSONB NOT NULL,
    "passed" BOOLEAN NOT NULL,

    CONSTRAINT "AIEvaluationRun_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AIUsageMetric" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "date" DATE NOT NULL,
    "feature" TEXT NOT NULL,
    "requests" INTEGER NOT NULL,
    "tokensIn" INTEGER NOT NULL,
    "tokensOut" INTEGER NOT NULL,
    "errors" INTEGER NOT NULL,
    "costEstimateMinor" INTEGER NOT NULL,

    CONSTRAINT "AIUsageMetric_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AIReviewQueue" (
    "id" UUID NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,
    "kind" TEXT NOT NULL,
    "payload" JSONB NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "reviewerId" UUID,
    "decisionNote" TEXT,

    CONSTRAINT "AIReviewQueue_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Role_key_key" ON "Role"("key");

-- CreateIndex
CREATE UNIQUE INDEX "Permission_key_key" ON "Permission"("key");

-- CreateIndex
CREATE INDEX "RolePermission_permissionId_idx" ON "RolePermission"("permissionId");

-- CreateIndex
CREATE UNIQUE INDEX "RolePermission_roleId_permissionId_key" ON "RolePermission"("roleId", "permissionId");

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- CreateIndex
CREATE INDEX "User_roleId_idx" ON "User"("roleId");

-- CreateIndex
CREATE UNIQUE INDEX "Session_tokenHash_key" ON "Session"("tokenHash");

-- CreateIndex
CREATE INDEX "Session_userId_idx" ON "Session"("userId");

-- CreateIndex
CREATE INDEX "Session_expiresAt_idx" ON "Session"("expiresAt");

-- CreateIndex
CREATE UNIQUE INDEX "PasswordResetToken_tokenHash_key" ON "PasswordResetToken"("tokenHash");

-- CreateIndex
CREATE INDEX "PasswordResetToken_userId_idx" ON "PasswordResetToken"("userId");

-- CreateIndex
CREATE INDEX "PasswordResetToken_expiresAt_idx" ON "PasswordResetToken"("expiresAt");

-- CreateIndex
CREATE UNIQUE INDEX "InviteToken_tokenHash_key" ON "InviteToken"("tokenHash");

-- CreateIndex
CREATE INDEX "InviteToken_userId_idx" ON "InviteToken"("userId");

-- CreateIndex
CREATE INDEX "InviteToken_expiresAt_idx" ON "InviteToken"("expiresAt");

-- CreateIndex
CREATE UNIQUE INDEX "MfaSetupToken_tokenHash_key" ON "MfaSetupToken"("tokenHash");

-- CreateIndex
CREATE INDEX "MfaSetupToken_userId_idx" ON "MfaSetupToken"("userId");

-- CreateIndex
CREATE INDEX "MfaSetupToken_expiresAt_idx" ON "MfaSetupToken"("expiresAt");

-- CreateIndex
CREATE UNIQUE INDEX "MfaBackupCode_codeHash_key" ON "MfaBackupCode"("codeHash");

-- CreateIndex
CREATE INDEX "MfaBackupCode_userId_idx" ON "MfaBackupCode"("userId");

-- CreateIndex
CREATE INDEX "AuditLog_entityType_entityId_createdAt_idx" ON "AuditLog"("entityType", "entityId", "createdAt");

-- CreateIndex
CREATE INDEX "AuditLog_actorId_createdAt_idx" ON "AuditLog"("actorId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "Course_slug_key" ON "Course"("slug");

-- CreateIndex
CREATE INDEX "Course_status_publishedAt_idx" ON "Course"("status", "publishedAt");

-- CreateIndex
CREATE INDEX "Course_ogImageId_idx" ON "Course"("ogImageId");

-- CreateIndex
CREATE INDEX "CourseModule_courseId_sortOrder_idx" ON "CourseModule"("courseId", "sortOrder");

-- CreateIndex
CREATE UNIQUE INDEX "Teacher_slug_key" ON "Teacher"("slug");

-- CreateIndex
CREATE INDEX "Teacher_photoId_idx" ON "Teacher"("photoId");

-- CreateIndex
CREATE INDEX "Teacher_isActive_isPublic_idx" ON "Teacher"("isActive", "isPublic");

-- CreateIndex
CREATE INDEX "TeacherCourse_courseId_idx" ON "TeacherCourse"("courseId");

-- CreateIndex
CREATE UNIQUE INDEX "TeacherCourse_teacherId_courseId_key" ON "TeacherCourse"("teacherId", "courseId");

-- CreateIndex
CREATE INDEX "TeacherAvailability_teacherId_weekday_idx" ON "TeacherAvailability"("teacherId", "weekday");

-- CreateIndex
CREATE UNIQUE INDEX "TrialApplication_reference_key" ON "TrialApplication"("reference");

-- CreateIndex
CREATE UNIQUE INDEX "TrialApplication_idempotencyKey_key" ON "TrialApplication"("idempotencyKey");

-- CreateIndex
CREATE INDEX "TrialApplication_status_createdAt_idx" ON "TrialApplication"("status", "createdAt");

-- CreateIndex
CREATE INDEX "TrialApplication_assignedToUserId_status_idx" ON "TrialApplication"("assignedToUserId", "status");

-- CreateIndex
CREATE INDEX "TrialApplication_courseId_createdAt_idx" ON "TrialApplication"("courseId", "createdAt");

-- CreateIndex
CREATE INDEX "TrialApplication_email_courseId_createdAt_idx" ON "TrialApplication"("email", "courseId", "createdAt");

-- CreateIndex
CREATE INDEX "TrialApplication_phoneE164_courseId_createdAt_idx" ON "TrialApplication"("phoneE164", "courseId", "createdAt");

-- CreateIndex
CREATE INDEX "TrialApplication_country_idx" ON "TrialApplication"("country");

-- CreateIndex
CREATE INDEX "TrialApplication_assignedTeacherId_idx" ON "TrialApplication"("assignedTeacherId");

-- CreateIndex
CREATE INDEX "TrialApplication_duplicateOfId_idx" ON "TrialApplication"("duplicateOfId");

-- CreateIndex
CREATE INDEX "TrialHistory_trialId_createdAt_idx" ON "TrialHistory"("trialId", "createdAt");

-- CreateIndex
CREATE INDEX "TrialHistory_actorId_idx" ON "TrialHistory"("actorId");

-- CreateIndex
CREATE INDEX "TrialNote_trialId_idx" ON "TrialNote"("trialId");

-- CreateIndex
CREATE INDEX "TrialNote_authorId_idx" ON "TrialNote"("authorId");

-- CreateIndex
CREATE INDEX "ContactMessage_status_createdAt_idx" ON "ContactMessage"("status", "createdAt");

-- CreateIndex
CREATE INDEX "ContactMessage_assignedToUserId_idx" ON "ContactMessage"("assignedToUserId");

-- CreateIndex
CREATE INDEX "ContactMessage_repliedById_idx" ON "ContactMessage"("repliedById");

-- CreateIndex
CREATE UNIQUE INDEX "Student_createdFromTrialId_key" ON "Student"("createdFromTrialId");

-- CreateIndex
CREATE INDEX "Student_status_idx" ON "Student"("status");

-- CreateIndex
CREATE INDEX "Guardian_email_idx" ON "Guardian"("email");

-- CreateIndex
CREATE INDEX "StudentGuardian_guardianId_idx" ON "StudentGuardian"("guardianId");

-- CreateIndex
CREATE UNIQUE INDEX "StudentGuardian_studentId_guardianId_key" ON "StudentGuardian"("studentId", "guardianId");

-- CreateIndex
CREATE INDEX "Enrollment_studentId_idx" ON "Enrollment"("studentId");

-- CreateIndex
CREATE INDEX "Enrollment_courseId_idx" ON "Enrollment"("courseId");

-- CreateIndex
CREATE INDEX "Enrollment_teacherId_idx" ON "Enrollment"("teacherId");

-- CreateIndex
CREATE INDEX "Enrollment_planId_idx" ON "Enrollment"("planId");

-- CreateIndex
CREATE INDEX "Enrollment_status_idx" ON "Enrollment"("status");

-- CreateIndex
CREATE INDEX "ClassSchedule_enrollmentId_idx" ON "ClassSchedule"("enrollmentId");

-- CreateIndex
CREATE INDEX "ClassSchedule_teacherId_idx" ON "ClassSchedule"("teacherId");

-- CreateIndex
CREATE INDEX "ClassSession_teacherId_startsAtUtc_idx" ON "ClassSession"("teacherId", "startsAtUtc");

-- CreateIndex
CREATE INDEX "ClassSession_studentId_startsAtUtc_idx" ON "ClassSession"("studentId", "startsAtUtc");

-- CreateIndex
CREATE INDEX "ClassSession_trialId_idx" ON "ClassSession"("trialId");

-- CreateIndex
CREATE UNIQUE INDEX "ClassSession_scheduleId_startsAtUtc_key" ON "ClassSession"("scheduleId", "startsAtUtc");

-- CreateIndex
CREATE INDEX "Attendance_enrollmentId_idx" ON "Attendance"("enrollmentId");

-- CreateIndex
CREATE UNIQUE INDEX "Attendance_sessionId_enrollmentId_key" ON "Attendance"("sessionId", "enrollmentId");

-- CreateIndex
CREATE INDEX "ProgressRecord_enrollmentId_createdAt_idx" ON "ProgressRecord"("enrollmentId", "createdAt");

-- CreateIndex
CREATE INDEX "ProgressRecord_sessionId_idx" ON "ProgressRecord"("sessionId");

-- CreateIndex
CREATE INDEX "ProgressRecord_authorId_idx" ON "ProgressRecord"("authorId");

-- CreateIndex
CREATE INDEX "PricingPlan_courseId_idx" ON "PricingPlan"("courseId");

-- CreateIndex
CREATE INDEX "PricingPlan_status_isPublic_idx" ON "PricingPlan"("status", "isPublic");

-- CreateIndex
CREATE UNIQUE INDEX "PricingPlanPrice_planId_currency_key" ON "PricingPlanPrice"("planId", "currency");

-- CreateIndex
CREATE UNIQUE INDEX "Invoice_number_key" ON "Invoice"("number");

-- CreateIndex
CREATE INDEX "Invoice_enrollmentId_idx" ON "Invoice"("enrollmentId");

-- CreateIndex
CREATE INDEX "Invoice_status_dueAt_idx" ON "Invoice"("status", "dueAt");

-- CreateIndex
CREATE INDEX "PaymentRecord_invoiceId_idx" ON "PaymentRecord"("invoiceId");

-- CreateIndex
CREATE INDEX "PaymentRecord_recordedById_idx" ON "PaymentRecord"("recordedById");

-- CreateIndex
CREATE INDEX "PaymentRecord_receivedAt_idx" ON "PaymentRecord"("receivedAt");

-- CreateIndex
CREATE INDEX "CMSPage_status_publishedAt_idx" ON "CMSPage"("status", "publishedAt");

-- CreateIndex
CREATE UNIQUE INDEX "CMSPage_slug_locale_key" ON "CMSPage"("slug", "locale");

-- CreateIndex
CREATE INDEX "PageSection_pageId_sortOrder_idx" ON "PageSection"("pageId", "sortOrder");

-- CreateIndex
CREATE INDEX "ContentRevision_entityType_entityId_createdAt_idx" ON "ContentRevision"("entityType", "entityId", "createdAt");

-- CreateIndex
CREATE INDEX "ContentRevision_authorId_idx" ON "ContentRevision"("authorId");

-- CreateIndex
CREATE INDEX "BlogPost_status_publishedAt_idx" ON "BlogPost"("status", "publishedAt");

-- CreateIndex
CREATE INDEX "BlogPost_coverId_idx" ON "BlogPost"("coverId");

-- CreateIndex
CREATE INDEX "BlogPost_authorId_idx" ON "BlogPost"("authorId");

-- CreateIndex
CREATE UNIQUE INDEX "BlogPost_slug_locale_key" ON "BlogPost"("slug", "locale");

-- CreateIndex
CREATE UNIQUE INDEX "MediaAsset_storageKey_key" ON "MediaAsset"("storageKey");

-- CreateIndex
CREATE INDEX "MediaAsset_uploadedById_idx" ON "MediaAsset"("uploadedById");

-- CreateIndex
CREATE INDEX "FAQ_status_locale_idx" ON "FAQ"("status", "locale");

-- CreateIndex
CREATE INDEX "Testimonial_status_idx" ON "Testimonial"("status");

-- CreateIndex
CREATE INDEX "MenuItem_menu_sortOrder_idx" ON "MenuItem"("menu", "sortOrder");

-- CreateIndex
CREATE INDEX "MenuItem_parentId_idx" ON "MenuItem"("parentId");

-- CreateIndex
CREATE UNIQUE INDEX "Setting_key_key" ON "Setting"("key");

-- CreateIndex
CREATE UNIQUE INDEX "Redirect_fromPath_key" ON "Redirect"("fromPath");

-- CreateIndex
CREATE INDEX "Notification_userId_readAt_idx" ON "Notification"("userId", "readAt");

-- CreateIndex
CREATE INDEX "OutboxEvent_processedAt_createdAt_idx" ON "OutboxEvent"("processedAt", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "IdempotencyRecord_key_key" ON "IdempotencyRecord"("key");

-- CreateIndex
CREATE INDEX "IdempotencyRecord_expiresAt_idx" ON "IdempotencyRecord"("expiresAt");

-- CreateIndex
CREATE INDEX "PrivacyRequest_studentId_idx" ON "PrivacyRequest"("studentId");

-- CreateIndex
CREATE INDEX "PrivacyRequest_status_dueAt_idx" ON "PrivacyRequest"("status", "dueAt");

-- CreateIndex
CREATE UNIQUE INDEX "Certificate_number_key" ON "Certificate"("number");

-- CreateIndex
CREATE INDEX "Certificate_enrollmentId_idx" ON "Certificate"("enrollmentId");

-- CreateIndex
CREATE INDEX "Certificate_approvedById_idx" ON "Certificate"("approvedById");

-- CreateIndex
CREATE INDEX "AIKnowledgeDocument_approvedById_idx" ON "AIKnowledgeDocument"("approvedById");

-- CreateIndex
CREATE UNIQUE INDEX "AIKnowledgeDocument_sourceType_sourceId_version_key" ON "AIKnowledgeDocument"("sourceType", "sourceId", "version");

-- CreateIndex
CREATE INDEX "AIKnowledgeChunk_documentId_idx" ON "AIKnowledgeChunk"("documentId");

-- CreateIndex
CREATE INDEX "AIKnowledgeChunk_visibility_locale_idx" ON "AIKnowledgeChunk"("visibility", "locale");

-- CreateIndex
CREATE UNIQUE INDEX "AIConfiguration_key_key" ON "AIConfiguration"("key");

-- CreateIndex
CREATE INDEX "AIFeedback_feature_createdAt_idx" ON "AIFeedback"("feature", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "AIUsageMetric_date_feature_key" ON "AIUsageMetric"("date", "feature");

-- CreateIndex
CREATE INDEX "AIReviewQueue_reviewerId_idx" ON "AIReviewQueue"("reviewerId");

-- CreateIndex
CREATE INDEX "AIReviewQueue_status_idx" ON "AIReviewQueue"("status");

-- AddForeignKey
ALTER TABLE "RolePermission" ADD CONSTRAINT "RolePermission_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES "Role"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RolePermission" ADD CONSTRAINT "RolePermission_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES "Permission"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES "Role"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Session" ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PasswordResetToken" ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InviteToken" ADD CONSTRAINT "InviteToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MfaSetupToken" ADD CONSTRAINT "MfaSetupToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MfaBackupCode" ADD CONSTRAINT "MfaBackupCode_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Course" ADD CONSTRAINT "Course_ogImageId_fkey" FOREIGN KEY ("ogImageId") REFERENCES "MediaAsset"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CourseModule" ADD CONSTRAINT "CourseModule_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES "Course"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Teacher" ADD CONSTRAINT "Teacher_photoId_fkey" FOREIGN KEY ("photoId") REFERENCES "MediaAsset"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TeacherCourse" ADD CONSTRAINT "TeacherCourse_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES "Teacher"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TeacherCourse" ADD CONSTRAINT "TeacherCourse_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES "Course"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TeacherAvailability" ADD CONSTRAINT "TeacherAvailability_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES "Teacher"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TrialApplication" ADD CONSTRAINT "TrialApplication_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES "Course"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TrialApplication" ADD CONSTRAINT "TrialApplication_assignedToUserId_fkey" FOREIGN KEY ("assignedToUserId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TrialApplication" ADD CONSTRAINT "TrialApplication_assignedTeacherId_fkey" FOREIGN KEY ("assignedTeacherId") REFERENCES "Teacher"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TrialApplication" ADD CONSTRAINT "TrialApplication_duplicateOfId_fkey" FOREIGN KEY ("duplicateOfId") REFERENCES "TrialApplication"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TrialHistory" ADD CONSTRAINT "TrialHistory_trialId_fkey" FOREIGN KEY ("trialId") REFERENCES "TrialApplication"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TrialHistory" ADD CONSTRAINT "TrialHistory_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TrialNote" ADD CONSTRAINT "TrialNote_trialId_fkey" FOREIGN KEY ("trialId") REFERENCES "TrialApplication"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TrialNote" ADD CONSTRAINT "TrialNote_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ContactMessage" ADD CONSTRAINT "ContactMessage_assignedToUserId_fkey" FOREIGN KEY ("assignedToUserId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ContactMessage" ADD CONSTRAINT "ContactMessage_repliedById_fkey" FOREIGN KEY ("repliedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Student" ADD CONSTRAINT "Student_createdFromTrialId_fkey" FOREIGN KEY ("createdFromTrialId") REFERENCES "TrialApplication"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StudentGuardian" ADD CONSTRAINT "StudentGuardian_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StudentGuardian" ADD CONSTRAINT "StudentGuardian_guardianId_fkey" FOREIGN KEY ("guardianId") REFERENCES "Guardian"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Enrollment" ADD CONSTRAINT "Enrollment_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Enrollment" ADD CONSTRAINT "Enrollment_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES "Course"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Enrollment" ADD CONSTRAINT "Enrollment_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES "Teacher"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Enrollment" ADD CONSTRAINT "Enrollment_planId_fkey" FOREIGN KEY ("planId") REFERENCES "PricingPlan"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ClassSchedule" ADD CONSTRAINT "ClassSchedule_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES "Enrollment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ClassSchedule" ADD CONSTRAINT "ClassSchedule_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES "Teacher"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ClassSession" ADD CONSTRAINT "ClassSession_scheduleId_fkey" FOREIGN KEY ("scheduleId") REFERENCES "ClassSchedule"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ClassSession" ADD CONSTRAINT "ClassSession_trialId_fkey" FOREIGN KEY ("trialId") REFERENCES "TrialApplication"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ClassSession" ADD CONSTRAINT "ClassSession_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES "Teacher"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ClassSession" ADD CONSTRAINT "ClassSession_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Attendance" ADD CONSTRAINT "Attendance_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "ClassSession"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Attendance" ADD CONSTRAINT "Attendance_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES "Enrollment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ProgressRecord" ADD CONSTRAINT "ProgressRecord_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES "Enrollment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ProgressRecord" ADD CONSTRAINT "ProgressRecord_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "ClassSession"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ProgressRecord" ADD CONSTRAINT "ProgressRecord_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PricingPlan" ADD CONSTRAINT "PricingPlan_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES "Course"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PricingPlanPrice" ADD CONSTRAINT "PricingPlanPrice_planId_fkey" FOREIGN KEY ("planId") REFERENCES "PricingPlan"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Invoice" ADD CONSTRAINT "Invoice_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES "Enrollment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PaymentRecord" ADD CONSTRAINT "PaymentRecord_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES "Invoice"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PaymentRecord" ADD CONSTRAINT "PaymentRecord_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PageSection" ADD CONSTRAINT "PageSection_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES "CMSPage"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ContentRevision" ADD CONSTRAINT "ContentRevision_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BlogPost" ADD CONSTRAINT "BlogPost_coverId_fkey" FOREIGN KEY ("coverId") REFERENCES "MediaAsset"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BlogPost" ADD CONSTRAINT "BlogPost_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MediaAsset" ADD CONSTRAINT "MediaAsset_uploadedById_fkey" FOREIGN KEY ("uploadedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MenuItem" ADD CONSTRAINT "MenuItem_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES "MenuItem"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PrivacyRequest" ADD CONSTRAINT "PrivacyRequest_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "Student"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Certificate" ADD CONSTRAINT "Certificate_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES "Enrollment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Certificate" ADD CONSTRAINT "Certificate_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AIKnowledgeDocument" ADD CONSTRAINT "AIKnowledgeDocument_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AIKnowledgeChunk" ADD CONSTRAINT "AIKnowledgeChunk_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES "AIKnowledgeDocument"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AIReviewQueue" ADD CONSTRAINT "AIReviewQueue_reviewerId_fkey" FOREIGN KEY ("reviewerId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

$source$;
    INSERT INTO public._prisma_migrations (id, checksum, migration_name, finished_at, applied_steps_count)
      VALUES ('ff4ac010-6e96-0a71-fbc9-586d9724962c', 'ff4ac0106e960a71fbc9586d9724962cd764cd9f1d46b2274a0c71143fb84300', '202610110001_initial', now(), 1);
  END IF;
END
$migration$;

DO $migration$
BEGIN
  IF EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '202610110002_system_constraints' AND rolled_back_at IS NULL AND (checksum <> 'e2e3c52469683b3248d2ab9eae4fb29721705ea9e521cf01cc77832fefbaa0a4' OR finished_at IS NULL)) THEN
    RAISE EXCEPTION 'Migration 202610110002_system_constraints is changed or incomplete; inspect before continuing';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '202610110002_system_constraints' AND finished_at IS NOT NULL AND rolled_back_at IS NULL) THEN
    EXECUTE $source$
-- System constants only. No business content.
INSERT INTO "Role" (id,key,name,"updatedAt") VALUES ('01a12af6-3057-7365-a165-fbb4e6b5ae2c','SUPER_ADMIN','SUPER ADMIN',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Role" (id,key,name,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-808374bf9472','ADMIN','ADMIN',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Role" (id,key,name,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-847be72f9359','CONTENT_EDITOR','CONTENT EDITOR',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Role" (id,key,name,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-8a28f230fae2','ADMISSIONS','ADMISSIONS',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Role" (id,key,name,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-8f376c178b06','ACADEMIC_COORDINATOR','ACADEMIC COORDINATOR',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-91442c02b17b','ai:draft','ai:draft',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-9611994d2a9a','ai:evaluate','ai:evaluate',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-9a3f62808bda','ai:insights','ai:insights',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-9d7d335d9e84','ai:read','ai:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-a294b3e07785','ai:toggle','ai:toggle',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-a59564f2e85e','attendance:create','attendance:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-a8f04584795c','attendance:delete','attendance:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-aca47ce0b740','attendance:read','attendance:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-b11cf56a0570','attendance:update','attendance:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-b69a38ec47ec','audit-logs:read','audit-logs:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-b921d145f2bd','backups:read','backups:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-bda52367072e','blog:create','blog:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-c3f0198d3224','blog:delete','blog:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-c7728e80deb4','blog:publish','blog:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-ca4168dd462e','blog:read','blog:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-cd55ebbbeac2','blog:submit','blog:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-d374235041eb','blog:update','blog:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-d602c921ecf5','contact-messages:create','contact-messages:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-db5ae79ce24f','contact-messages:delete','contact-messages:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-dcc04fd4c445','contact-messages:read','contact-messages:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-e10d70747e7b','contact-messages:update','contact-messages:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-e6926ffc1998','courses:create','courses:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-eafe466457b0','courses:delete','courses:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-ede76e08a9b2','courses:publish','courses:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-f03100232880','courses:read','courses:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-f7eb6dd956e7','courses:update','courses:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-faa07087bcff','courses:update-content','courses:update-content',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c99-fd7de4d5dd1e','enrollments:create','enrollments:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-02ada172e10e','enrollments:delete','enrollments:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-064acf0f86e6','enrollments:read','enrollments:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-09c9fb446be5','enrollments:update','enrollments:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-0dd0d29e0332','exports:academic','exports:academic',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-12b72e6fa36c','exports:admissions','exports:admissions',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-171979413458','exports:all','exports:all',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-1bc4d3a85079','exports:content','exports:content',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-1cbbc354adfd','faqs:create','faqs:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-22bc606aba15','faqs:delete','faqs:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-24e3bf782698','faqs:publish','faqs:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-282288fa487e','faqs:read','faqs:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-2fb77b005aa0','faqs:submit','faqs:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-300e43b5e7c0','faqs:update','faqs:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-37b59921794d','guardians:create','guardians:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-3a719ebd0b6d','guardians:delete','guardians:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-3e290a45274f','guardians:read','guardians:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-419f3422a4e1','guardians:update','guardians:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-44dd450dbfb2','invoices:create','invoices:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-4b79f0198c84','invoices:delete','invoices:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-4fb023bbfa32','invoices:read','invoices:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-51a8970104f6','invoices:update','invoices:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-55e5f2b96bf8','media:create','media:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-5a3b85191e8d','media:delete','media:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-5e8597c51111','media:publish','media:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-63f622df24d0','media:read','media:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-66b222fb606f','media:submit','media:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-6b267d186653','media:update','media:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-6fc4e6022619','menus:create','menus:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-721ccfe0d19c','menus:delete','menus:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-751b63a9a73a','menus:publish','menus:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-7ab83eb0f17d','menus:read','menus:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-7cabca3ead2b','menus:submit','menus:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-811049a878d1','menus:update','menus:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-8577f518d5e8','notifications:read','notifications:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-8a0a7049b2ec','pages:create','pages:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-8f1c5b2e99a9','pages:delete','pages:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-9363c04c7a35','pages:publish','pages:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-9425081a5fcd','pages:read','pages:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-99dfad1eee8b','pages:submit','pages:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-9d0a4eb00315','pages:update','pages:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-a3c2a3cf0660','payments:create','payments:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-a4b9319194a4','payments:delete','payments:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-abc310e94724','payments:read','payments:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-ad411e535c22','payments:update','payments:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-b32ebf76299a','pricing-plans:create','pricing-plans:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-b732e4ff322b','pricing-plans:delete','pricing-plans:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-ba134fa93c17','pricing-plans:read','pricing-plans:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-bc6216429858','pricing-plans:update','pricing-plans:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-c0d41b833a9b','privacy-requests:create','privacy-requests:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-c43ac7885eaf','privacy-requests:delete','privacy-requests:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-cb53976f9133','privacy-requests:read','privacy-requests:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-cd24bc6fa98b','privacy-requests:update','privacy-requests:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-d3e86248ae07','progress:create','progress:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-d5a0445dd138','progress:delete','progress:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-d97d963937a6','progress:read','progress:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-df39b5bb9c32','progress:update','progress:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-e0b7ab3f2ae9','reports:academic','reports:academic',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-e50640f84b9f','reports:admissions','reports:admissions',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-e961707d8a5b','reports:content','reports:content',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-eeece7132542','reports:read','reports:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-f0095b057f9e','retention:execute','retention:execute',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-f56228bb6d3f','roles:read','roles:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-f85b69c4c83f','schedules:create','schedules:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9a-ff8f876bc15a','schedules:delete','schedules:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-00d7977a52cf','schedules:read','schedules:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-0631cccea4d3','schedules:update','schedules:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-0ac783c5891b','sessions:create','sessions:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-0d8d268a3de6','sessions:delete','sessions:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-10bac721ba8d','sessions:read','sessions:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-163306feec2e','sessions:update','sessions:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-1b7a3246b287','settings:create','settings:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-1c2efe83f1d7','settings:delete','settings:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-22c3349c4191','settings:read','settings:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-2623466fe2e7','settings:security','settings:security',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-2b8089a6e366','settings:update','settings:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-2d5e7d83a63d','students:create','students:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-30db62c0c6ff','students:delete','students:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-3672c217eb27','students:read','students:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-393cb2587165','students:update','students:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-3e26c2a9164b','teachers:availability','teachers:availability',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-414a027a674e','teachers:create','teachers:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-473523dc5c6a','teachers:delete','teachers:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-4a7587d0e89c','teachers:read','teachers:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-4f5e87c6a9df','teachers:update','teachers:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-51c4ab3f7f1a','teachers:update-content','teachers:update-content',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-5657397e38e5','testimonials:create','testimonials:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-5b75744f3624','testimonials:delete','testimonials:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-5cedb1e3306c','testimonials:publish','testimonials:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-6316d251c640','testimonials:read','testimonials:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-65bc3c1d6233','testimonials:submit','testimonials:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-6b2113f8ca3a','testimonials:update','testimonials:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-6d326eb08743','trials:assign','trials:assign',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-72583f977185','trials:convert','trials:convert',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-758aa9d005f3','trials:create','trials:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-7ad603561a8d','trials:delete','trials:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-7f49ca561865','trials:notes','trials:notes',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-83631147ce33','trials:read','trials:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-871c8d85d444','trials:status','trials:status',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-888d28ede796','trials:update','trials:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-8e2e5eb15c69','users:create','users:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-935b15180370','users:delete','users:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-9498c1d2daa2','users:read','users:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-9a1616490dba','users:security','users:security',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12af6-3058-743a-9c9b-9e16d7acc685','users:update','users:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-a38519092f58',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='users:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-a414727aa308',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='users:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-a8336407d548',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='users:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-acfb2ac28ae0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='users:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-b05a304da6b5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-b4db2857928e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-bb634bea03ce',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-bef2a9ee14b3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-c22443330ea1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-c7d75b2bf1f3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-c84636883ffa',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-ce504277ac24',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-d1b923a4b360',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-d69443e89bc6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-dbbfeedb8a16',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-dd151c66b9f6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-e35f2ff32655',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-e419b9999e58',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-ebc59f65a004',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-ed114cdf058b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-f11438c1aa1a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-f7e64c48f6c7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-f9c9f063cb2f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9b-feeeef226cf7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-025f9df3edc2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-078ef84c2663',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-0875aac27c69',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-0fcb2a3db155',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-12dde350d7b9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='courses:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-178d1de8b6ee',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='courses:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-1834531bd730',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='courses:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-1d91e4c5a5a4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='courses:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-23b1f4215f62',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='teachers:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-276d93125d88',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='teachers:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-2b445d667e56',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='teachers:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-2e7915cfe78a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='teachers:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-31c938318b57',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-3509097f5d93',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-3b0970b5f3b5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-3fd65009133e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-40466b8353ef',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='contact-messages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-4519894683a6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='contact-messages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-4aaf47412514',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='contact-messages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-4ca8722b50f8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='contact-messages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-535f5059565a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='students:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-54f38063f2af',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='students:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-5b7d52752726',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='students:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-5e149defd589',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='students:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-6024cc9fcb73',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='guardians:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-6608632421e7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='guardians:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-6879d77d2183',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='guardians:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-6ee864c6186c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='guardians:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-735c374e57a7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='enrollments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-745231ea9964',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='enrollments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-7a2d3badf5af',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='enrollments:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-7cf15e44d905',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='enrollments:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-82b9dd3da0e5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='schedules:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-85049f847985',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='schedules:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-8a0a3272c598',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='schedules:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-8cee4d9db45e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='schedules:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-919d74748f59',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='sessions:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-9551b0d18f24',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='sessions:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-9816be475d17',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='sessions:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-9d6f4eee5727',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='sessions:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-a24e6cd4a12a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='attendance:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-a455bdc0a094',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='attendance:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-a8c1fc15c95d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='attendance:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-ad04fa0efff3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='attendance:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-b0056d14d450',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='progress:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-b57bd7155600',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='progress:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-b97200d3a1ab',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='progress:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-bc8c2e2687e1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='progress:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-c31a2e0bd5d7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pricing-plans:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-c7ef6191c45e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pricing-plans:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-cace21774a91',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pricing-plans:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-cf693165928d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pricing-plans:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-d116edcda03b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='invoices:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-d653a874899e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='invoices:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-da8e2ff2898c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='invoices:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-dc59a78e18f8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='invoices:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-e0f78e8a81ef',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='payments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-e7814a9d3754',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='payments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-eb2339e10aa3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='payments:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-eeeb415df34a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='payments:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-f3cc47c8aeb6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='settings:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-f4585743bc22',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='settings:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-fa9deb21f9c4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='settings:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9c-fd8024e516bc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='settings:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9d-0159ddb7f349',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='privacy-requests:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9d-05fec0bca1c6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='privacy-requests:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9d-0bdc26379c0e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='privacy-requests:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9d-0d9143b6e049',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='privacy-requests:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9d-10b2d8bdfc5e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='roles:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9d-17def53620ab',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='audit-logs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3058-743a-9c9d-1afd4bd3cb47',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='notifications:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-22449257d5a6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='reports:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-24d71611a849',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='backups:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-2a7668d58045',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-2fdec6e4f22f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-31fe26c72529',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-3651784db113',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-3b1c332fe940',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-3f313ad35f0a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-4106068670c7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-46c67d74bf7a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-49b5a5c57c37',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-4d92753867fc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-514c6a6d9aae',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-56ac4ca0317a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-5a0076d938f0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='courses:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-5ff10a547efe',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:assign' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-611a5302fe14',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:convert' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-66751d6c8ac4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:status' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-6b4a100eeaff',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:notes' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-6d903339e226',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='teachers:availability' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-71c8b534eb9f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='exports:all' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-74929129c30d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='exports:admissions' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-79a339e92e88',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='exports:academic' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-7fc2ba4b33e4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='exports:content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-82f45a2d9f91',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='ai:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-84894bd7422a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='ai:draft' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-88ff19098c34',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='ai:toggle' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-8f11eaf60f64',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='ai:evaluate' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-936ea451168e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='ai:insights' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-977bb80226fe',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='users:security' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-98d4dcb3fc56',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='settings:security' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-9c57c91d4426',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='retention:execute' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-a27710a31cf1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='users:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-a6a5bbeefab0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='users:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-a96ff0ca1d76',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='users:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-afce043025ec',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='users:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-b324ba4543c3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-b6661fc121a7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-bb08ed01119c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-bc9cd05f3c23',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-c2a5ab37986c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-c7112ddd1dcc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-c943152ad6c4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-cc2b234e34fb',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-d15dd26f27be',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-d405a8f9afd2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-db81f2cf6436',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-df94a6072173',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-e18f56d9b3d6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-e7b7c06cc0af',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-ea2cbbf9a10a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-ef6df474323c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-f3d748c09aa8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-f5aca793f1fc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-fbd32075ccfd',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b002-fc83c9613c38',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-0361c60ed15a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-04ad3cf81a89',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-08cb8b82e5fe',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-0d70bd16e1f5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-13706f12a1c2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='courses:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-142e2258026c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='courses:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-1bd7c8673fed',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='courses:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-1fac474f039d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='courses:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-222a23699e0d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='teachers:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-27f4aa662914',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='teachers:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-2b60556b4962',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='teachers:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-2fc476e73a7a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='teachers:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-33122a460e15',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-36c174e08eef',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-3bd21b427f33',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-3c733cae74b4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-4200783ac635',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='contact-messages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-44550a9807b1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='contact-messages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-4847708ddfff',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='contact-messages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-4dd83f5507c0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='contact-messages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-53eab16cb120',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='students:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-555765154e3b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='students:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-5bde698fa4c8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='students:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-5ea80cc1cec6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='students:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-619181f87648',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='guardians:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-6769763d4b58',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='guardians:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-69b7f7822810',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='guardians:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-6dace97ef08e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='guardians:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-716c4e331695',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='enrollments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-75aa8b3f867d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='enrollments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-79eade2cff15',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='enrollments:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-7f3ba7786721',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='enrollments:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-8161ff1479dc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='schedules:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-86e3e6334ce0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='schedules:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-8b4750784c5c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='schedules:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-8e6da9eaa43b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='schedules:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-9368e9302936',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='sessions:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-94bbce2591e1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='sessions:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-9aa00109a3ae',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='sessions:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-9ca831634dac',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='sessions:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-a1ad40ef2788',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='attendance:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-a5857529b1f5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='attendance:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-a860587fbf94',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='attendance:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-af5d30c802dc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='attendance:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-b236d0f3ad47',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='progress:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-b5229dba72fa',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='progress:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-ba42ccc2be34',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='progress:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-bd5d2869ff8e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='progress:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-c0139dab8d5d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pricing-plans:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-c46d47382dde',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pricing-plans:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-ca5d0850a542',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pricing-plans:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-cd1225baf022',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pricing-plans:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-d3edabeebe7e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='invoices:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-d5833c402620',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='invoices:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-d951c1a260f6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='invoices:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-df007ea2914d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='invoices:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-e3a769b2f00e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='payments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-e5f4ef31ce6c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='payments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-ea75a31a6708',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='payments:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-ee03162eb0fc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='payments:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-f0432159d96f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='settings:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-f69b4cbea861',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='settings:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-fb68f8c00707',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='settings:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b003-ffbf703dae5c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='settings:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-029cc8f093af',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='privacy-requests:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-06d49b59ad21',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='privacy-requests:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-0b4d65f4c3f5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='privacy-requests:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-0d7c8f322bf7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='privacy-requests:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-112dddc37f9d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='roles:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-16a5bed34e21',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='audit-logs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-1ba6e05aba99',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='notifications:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-1d3d64510cb2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='reports:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-21220961e9c3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='backups:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-27659f927f71',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-29721516dabd',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-2e8895a744f6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-322943a18b03',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-3510699f0caa',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-3b635efce0c1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-3f5d2f63e8b5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-4250a65713e3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-4648c6e8b05c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-492643fd7090',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-4d27b126989c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-51acc89eab21',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-55303358c089',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='courses:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-5bb4e89119bd',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:assign' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-5e2b77a3a283',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:convert' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-602743cfdf29',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:status' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-664a4c01042f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:notes' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-68349c038002',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='teachers:availability' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-6c30cf31a4c0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='exports:all' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-73e8a19a7960',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='exports:admissions' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-76acf7464232',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='exports:academic' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-7bec08d286b2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='exports:content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-7d244718bbd5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='ai:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-83eb54c6df10',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='ai:draft' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-86e3f049f5e0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='ai:toggle' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-8933ed0d7677',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='ai:insights' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-8f20daf83a5b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-90027b615fae',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-94eb108b2268',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-98c54119233c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-9e27f3b78b3b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='blog:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-a36b6fe6e731',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='blog:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-a6474ec11c5a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='blog:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-aa4c7fa7ed28',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='blog:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-adc9a336cec2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='faqs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-b1698a3f7d37',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='faqs:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-b6f814988e15',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='faqs:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-bafcd2e16b86',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='faqs:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-be0602e52b6c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='testimonials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-c387c4bb1a3e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='testimonials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-c69f66f2c97d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='testimonials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-cb3dd8506fc1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='testimonials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-cf47a1a9061b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='media:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-d0449eaf4d0c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='media:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-d4072e6c77b8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='media:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-d9d909883f6a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='media:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-df22a0592e6b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='menus:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-e3c91688e1b5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='menus:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-e57becf0ab7a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='menus:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-ea7ffa5acd0a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='menus:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-ecbf84c37c06',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pages:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-f35ad9cff43b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='blog:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-f739c0487195',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='faqs:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-f8edf3f55009',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='testimonials:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b004-fdec9401083b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='media:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-01cd213b8b75',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='menus:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-05c9503d0806',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='courses:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-0835762b814c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='courses:update-content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-0c0e22fac7c5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='teachers:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-123c05d1ef7a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='teachers:update-content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-1719d7c599fb',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pricing-plans:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-1aa4bd6d4a19',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='exports:content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-1fc919748ffc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='reports:content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-22d75b3b445a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='ai:draft' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-2647e5e92016',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-2b0a6135d5f6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-2fe561baf052',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-30f688cb8adb',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-37b3a9dfdfd4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='contact-messages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-385882659932',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='contact-messages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-3d1fb7f78ff3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='contact-messages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-40cae8c8658c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='contact-messages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-472987fabba7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='courses:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-4b9d238abdb4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='teachers:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-4f8fdd16072e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='students:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-50c400e9f6bc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='students:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-5592ac899a1c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='guardians:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-58c2f702bf40',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='guardians:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-5e48f59df1dc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='enrollments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-605ba04b07e0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='enrollments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-677e5c521c9e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='schedules:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-6b5ba5112e0b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='sessions:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-6f36aa28512b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='attendance:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-702e293b7eae',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='progress:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-74950abf220a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='pricing-plans:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-7b6cca0e2367',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='invoices:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-7da59ddaf61c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='payments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-831b7b236d53',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:assign' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-840d0b9e1e6c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:convert' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-8b1af0f85fac',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:status' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-8d2bb53382f2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:notes' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-90577ef72f4c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='exports:admissions' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-95af367313b4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='reports:admissions' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-99ee5c1d033c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='courses:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-9e39cdeb5dea',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='courses:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-a2a184421071',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='courses:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-a5b9c056afc0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='courses:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-a9292e1fa06a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='teachers:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-aeb897865a9f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='teachers:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-b1dcd1b0a44e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='teachers:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-b5d676b55e96',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='teachers:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-b848bbee321e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='students:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-bfecf6695e68',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='students:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-c3f90484d65f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='students:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-c7aff39fca21',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='students:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-c94030e54bca',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='guardians:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-cf3571f0449d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='guardians:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-d2eb30493a01',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='guardians:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-d50618fe3565',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='guardians:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-dab2461eacdc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='enrollments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-de3fbe873581',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='enrollments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-e1cc587705da',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='enrollments:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-e59e4a8fcc14',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='enrollments:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-eabfec28df05',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='schedules:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-ef520ec26959',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='schedules:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-f29d3744bc6c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='schedules:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-f748980e1cb0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='schedules:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-fa15a829ce5d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='sessions:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b005-fe7a56bc040a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='sessions:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-0102f4d17d7f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='sessions:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-0556cb1bbb5e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='sessions:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-0b288c8959ca',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='attendance:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-0c67e36d58bf',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='attendance:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-1090d8dc54dd',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='attendance:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-17603e819735',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='attendance:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-1a558ff963f2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='progress:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-1e643ddf842f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='progress:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-2230bedef138',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='progress:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-2561a72aef73',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='progress:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-28f874b08593',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='pages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-2f0c1f7ccaa1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='blog:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-3247259f244e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='faqs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-36dfc45006a1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='testimonials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-39eeff07011a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='media:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-3c2c4517628a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='menus:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-4355e7d86622',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='pricing-plans:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-479d62f2d021',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='invoices:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-4ac38743fbf8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='payments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-4d11f910475a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='trials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-528db2f8d77a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='trials:assign' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-56d3aa73a643',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='exports:academic' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-5b99ebfe2366',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='reports:academic' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-5c1678b66f55',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='ai:insights' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-6022bdb4fec1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='ai:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12af6-3059-772e-b006-6602b35fca97',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='teachers:availability' ON CONFLICT ("roleId","permissionId") DO NOTHING;

ALTER TABLE "ClassSession" ADD CONSTRAINT teacher_no_overlap EXCLUDE USING gist ("teacherId" WITH =,tstzrange("startsAtUtc","endsAtUtc",'[)') WITH &&) WHERE (status <> 'CANCELLED');
ALTER TABLE "ClassSession" ADD CONSTRAINT student_no_overlap EXCLUDE USING gist ("studentId" WITH =,tstzrange("startsAtUtc","endsAtUtc",'[)') WITH &&) WHERE (status <> 'CANCELLED' AND "studentId" IS NOT NULL);
ALTER TABLE "ClassSession" ADD CONSTRAINT session_positive_duration CHECK ("endsAtUtc">"startsAtUtc");
ALTER TABLE "ClassSession" ADD CONSTRAINT session_kind_target CHECK ((kind='TRIAL' AND "trialId" IS NOT NULL AND "scheduleId" IS NULL) OR (kind='REGULAR' AND "scheduleId" IS NOT NULL AND "studentId" IS NOT NULL AND "trialId" IS NULL));
ALTER TABLE "TeacherAvailability" ADD CONSTRAINT availability_bounds CHECK (weekday BETWEEN 1 AND 7 AND "startMinute" BETWEEN 0 AND 1439 AND "endMinute" BETWEEN 1 AND 1440 AND "endMinute">"startMinute");
ALTER TABLE "ClassSchedule" ADD CONSTRAINT schedule_bounds CHECK (weekday BETWEEN 1 AND 7 AND "startMinute" BETWEEN 0 AND 1439 AND "durationMin" BETWEEN 1 AND 240);
CREATE UNIQUE INDEX enrollment_active_unique ON "Enrollment" ("studentId","courseId") WHERE status IN ('ACTIVE','PAUSED') AND "deletedAt" IS NULL;
ALTER TABLE "Testimonial" ADD CONSTRAINT consent_before_publish CHECK (status <> 'PUBLISHED' OR "consentRecordedAt" IS NOT NULL);
ALTER TABLE "TrialApplication" ADD CONSTRAINT trial_consent CHECK ("consentGiven" IS TRUE);
ALTER TABLE "PricingPlanPrice" ADD CONSTRAINT price_nonnegative CHECK ("amountMinor">=0 AND currency ~ '^[A-Z]{3}$');
ALTER TABLE "Invoice" ADD CONSTRAINT invoice_nonnegative CHECK ("totalMinor">=0 AND currency ~ '^[A-Z]{3}$');
ALTER TABLE "PaymentRecord" ADD CONSTRAINT payment_positive CHECK ("amountMinor">0);
CREATE SEQUENCE invoice_number_seq;
CREATE FUNCTION audit_immutable() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'Audit log is append-only'; END; $$;
CREATE TRIGGER audit_immutable BEFORE UPDATE OR DELETE ON "AuditLog" FOR EACH ROW EXECUTE FUNCTION audit_immutable();
CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON "AuditLog" FOR EACH STATEMENT EXECUTE FUNCTION audit_immutable();
CREATE INDEX course_search_idx ON "Course" USING gin (to_tsvector('english', title || ' ' || summary));
CREATE INDEX teacher_name_idx ON "Teacher" USING gin ("displayName" gin_trgm_ops);
CREATE INDEX student_name_idx ON "Student" USING gin ("fullName" gin_trgm_ops);
CREATE INDEX ai_embedding_idx ON "AIKnowledgeChunk" USING hnsw (embedding vector_cosine_ops);

$source$;
    INSERT INTO public._prisma_migrations (id, checksum, migration_name, finished_at, applied_steps_count)
      VALUES ('e2e3c524-6968-3b32-48d2-ab9eae4fb297', 'e2e3c52469683b3248d2ab9eae4fb29721705ea9e521cf01cc77832fefbaa0a4', '202610110002_system_constraints', now(), 1);
  END IF;
END
$migration$;

DO $migration$
BEGIN
  IF EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '202610110003_catalog_permissions' AND rolled_back_at IS NULL AND (checksum <> '8ce4ccd40135428de159b2574c1c08b3a2dbc846d1832d0d7921762a5ceb3604' OR finished_at IS NULL)) THEN
    RAISE EXCEPTION 'Migration 202610110003_catalog_permissions is changed or incomplete; inspect before continuing';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '202610110003_catalog_permissions' AND finished_at IS NOT NULL AND rolled_back_at IS NULL) THEN
    EXECUTE $source$
-- Add missing explicit catalog submit/publish permissions; no business data.
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-8829-717e-95a5-03e9967f4972','ai:draft','ai:draft',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-272af76c1651','ai:evaluate','ai:evaluate',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-288180d7686c','ai:insights','ai:insights',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-2f4c2f1540aa','ai:read','ai:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-31d7c6eb973e','ai:toggle','ai:toggle',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-35e0b16a8809','attendance:create','attendance:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-380e90cabb66','attendance:delete','attendance:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-3cdd2d1c5aef','attendance:read','attendance:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-401407406b5e','attendance:update','attendance:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-470b606ffb60','audit-logs:read','audit-logs:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-48f2f14c0502','backups:read','backups:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-4f8ace76c1bc','blog:create','blog:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-520b67ffadd3','blog:delete','blog:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-563a931670f5','blog:publish','blog:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-5a1474b5ed97','blog:read','blog:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-5edd0c731170','blog:submit','blog:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-635b38e8ef34','blog:update','blog:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-667f715cd70c','contact-messages:create','contact-messages:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-6afe69dce8f5','contact-messages:delete','contact-messages:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-6d3199859704','contact-messages:read','contact-messages:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-70f33bcbff02','contact-messages:update','contact-messages:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-75c84b538fa2','courses:create','courses:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-7817ff12265d','courses:delete','courses:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-7cfb14e13a2c','courses:publish','courses:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-835d4aced205','courses:read','courses:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-87f3208df5df','courses:submit','courses:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-899b27a434bf','courses:update','courses:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-8d54ed417b91','courses:update-content','courses:update-content',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-9180f27821a7','enrollments:create','enrollments:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-977fe0a68a8c','enrollments:delete','enrollments:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-984ac47aa68c','enrollments:read','enrollments:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-9c7105457675','enrollments:update','enrollments:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-a0ad9387e1a0','exports:academic','exports:academic',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-a5af7742a2b2','exports:admissions','exports:admissions',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-aabde1264d76','exports:all','exports:all',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-af43efebdae4','exports:content','exports:content',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-b33439ff9b64','faqs:create','faqs:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-b5354f28425c','faqs:delete','faqs:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-bb44614db4fb','faqs:publish','faqs:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-be4fdbcb2553','faqs:read','faqs:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-c05287559f0c','faqs:submit','faqs:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-c61fcbdad5e2','faqs:update','faqs:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-ca5309f2ebdb','guardians:create','guardians:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-cd231be4f193','guardians:delete','guardians:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-d32e3f74c0b8','guardians:read','guardians:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-d60deaf6fe8e','guardians:update','guardians:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-db65e97f6595','invoices:create','invoices:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-dec8ded7c4d0','invoices:delete','invoices:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-e2657905004e','invoices:read','invoices:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-e7050b133264','invoices:update','invoices:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-ebb73806f08e','media:create','media:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-ec8bef1925f1','media:delete','media:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-f2a07bcf1cd4','media:publish','media:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-f4435937f1b8','media:read','media:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-faef7c6c1f50','media:submit','media:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8c-fc7062c4a68e','media:update','media:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-03d4ac38f7b1','menus:create','menus:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-05f963e0e0da','menus:delete','menus:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-08368c04218c','menus:publish','menus:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-0dc667609396','menus:read','menus:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-1386ccddbd74','menus:submit','menus:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-14ded9b787ff','menus:update','menus:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-1ae9af5f4f42','notifications:read','notifications:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-1d1a4718efac','pages:create','pages:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-2309ec35b919','pages:delete','pages:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-26224b14c6bf','pages:publish','pages:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-2ad8ef179d5c','pages:read','pages:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-2ca92ad3fdf7','pages:submit','pages:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-32ed2e984fa6','pages:update','pages:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-362cdd027bfe','payments:create','payments:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-391d24a9d885','payments:delete','payments:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-3f93d2972e84','payments:read','payments:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-43198e48b29f','payments:update','payments:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-44e9899fbcdc','pricing-plans:create','pricing-plans:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-4b0f2af37b2d','pricing-plans:delete','pricing-plans:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-4de58d435aa3','pricing-plans:publish','pricing-plans:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-50b0a1a04db7','pricing-plans:read','pricing-plans:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-56ae566a827a','pricing-plans:submit','pricing-plans:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-58c354c4df5a','pricing-plans:update','pricing-plans:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-5e488c82bccb','privacy-requests:create','privacy-requests:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-61e93f8697bc','privacy-requests:delete','privacy-requests:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-654f6a63c78a','privacy-requests:read','privacy-requests:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-6bf63d440adb','privacy-requests:update','privacy-requests:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-6dbcc6a1665a','progress:create','progress:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-71ea47fff343','progress:delete','progress:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-7644e47a2ecd','progress:read','progress:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-799e979cc110','progress:update','progress:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-7e85f8d514da','reports:academic','reports:academic',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-82aac03a20e8','reports:admissions','reports:admissions',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-875872a455ea','reports:content','reports:content',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-8b708edc1917','reports:read','reports:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-8c9b81db4373','retention:execute','retention:execute',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-9259653fa87f','roles:read','roles:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-977f8d1f8b04','schedules:create','schedules:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-9b3a46275533','schedules:delete','schedules:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-9e7aac98847a','schedules:read','schedules:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-a0283de1c590','schedules:update','schedules:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-a5910216751e','sessions:create','sessions:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-abc0e88ebbcf','sessions:delete','sessions:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-ada087af3cd1','sessions:read','sessions:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-b1beb48edf32','sessions:update','sessions:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-b77e973dffa9','settings:create','settings:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-baf76d34e6e3','settings:delete','settings:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-be2230a13e92','settings:read','settings:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-c05d52629b81','settings:security','settings:security',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-c5768657bd10','settings:update','settings:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-cb0b1423d8f6','students:create','students:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-ce3768e3181c','students:delete','students:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-d2c2eb744d97','students:read','students:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-d628e57efef3','students:update','students:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-da88a6be6d67','teachers:availability','teachers:availability',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-de9ef4839b21','teachers:create','teachers:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-e26ea94f0d17','teachers:delete','teachers:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-e693a4f0b034','teachers:read','teachers:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-eb973a07ae3a','teachers:update','teachers:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-ec47c6e5654b','teachers:update-content','teachers:update-content',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-f00ff755077c','testimonials:create','testimonials:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-f5e5893628f8','testimonials:delete','testimonials:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-f879e97835f2','testimonials:publish','testimonials:publish',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8d-fcd9f91b7e71','testimonials:read','testimonials:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8e-01983ae901f1','testimonials:submit','testimonials:submit',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8e-058316011f9a','testimonials:update','testimonials:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882a-7582-9a8e-08fb2fb42fbe','trials:assign','trials:assign',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-7e08a6b8c846','trials:convert','trials:convert',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-80f5062dec22','trials:create','trials:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-87db5fc8883e','trials:delete','trials:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-8aa1d96a81f4','trials:notes','trials:notes',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-8dae8953c756','trials:read','trials:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-9249eb2e245a','trials:status','trials:status',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-94435b9d8b30','trials:update','trials:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-9a032d7f8a0a','users:create','users:create',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-9d87799435fb','users:delete','users:delete',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-a1b2e9bc9c65','users:read','users:read',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-a42358c30f49','users:security','users:security',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('01a12b0a-882b-725a-a730-a88ae18ee2f1','users:update','users:update',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-882b-725a-a730-ac951ee2ea8e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='users:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-882b-725a-a730-b2e7f618682a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='users:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bda-eeac27ef0407',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='users:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bda-f0cb4c33926d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='users:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bda-f4f084b7679b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bda-fa964a2321e1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bda-ff9813127cfd',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-023ee9c8a4f1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-0746df53d4e9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-0b27afff2883',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-0ec082c46f04',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-136a5ac902c1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-16fa12b20a65',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-1a148bef95a9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-1e396d0785b8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-22c1ba664b4c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-246e38dd0b53',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-2a8b21f9b019',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-2d66228366dd',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-32e45b1701c4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-352d57a0a84e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-38763d5e55c9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-3cc1eca2664f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-426a0cf7e2b4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-4757a44ef2f3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-4be11d889043',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-4e0f57307cc9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-53a3af7597e8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-8849-7568-9bdb-563409e9b6bd',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='courses:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-b4dce03671e2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='courses:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-b95d4aef8798',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='courses:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-bc37ce5dabd7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='courses:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-c0bb78ea8b76',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='teachers:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-c50699bc2610',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='teachers:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-c9a949ef3eaa',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='teachers:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-cd7a1a3930ee',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='teachers:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-d073ae7fef48',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-d4dd24abecd5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-da3fd4abc649',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-df348d983311',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-e3c6f1707b31',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='contact-messages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-e4d09facaee3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='contact-messages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-e84e0714a6aa',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='contact-messages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-efa64f182909',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='contact-messages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-f1c9249684a5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='students:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-f67da6dd33fa',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='students:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-fa10189da576',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='students:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a881-fdc1af1c0820',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='students:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-015c56e9708c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='guardians:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-0414fea5238f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='guardians:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-0b186a808895',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='guardians:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-0ecf4f43a8c0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='guardians:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-10aa0dc3f7ef',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='enrollments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-17f6d141e41c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='enrollments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-1959eaad5233',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='enrollments:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-1da6bfdc8940',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='enrollments:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-22116c8f9af7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='schedules:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-26b8f74e46e6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='schedules:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-2b11585e78a2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='schedules:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-2ce8b7213b1a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='schedules:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-32fce8ce956a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='sessions:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-36ebaebef330',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='sessions:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-39d0ebd2ca69',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='sessions:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-3e869dbd24aa',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='sessions:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-4300af0db0d8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='attendance:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-470ee326f2e0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='attendance:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-4a892db265bd',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='attendance:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-4e9ffdc0fcd6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='attendance:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-53fb2dec3179',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='progress:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-55e1f6e2fffa',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='progress:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-5b8894b88a90',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='progress:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-5e705b381d1b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='progress:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-60b9e1a056a6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pricing-plans:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-64e9b52f95c8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pricing-plans:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-6871c92d9e39',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pricing-plans:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-6fc0a54f4fd5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pricing-plans:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-73f7e30d4fe6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='invoices:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-743db1551f40',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='invoices:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-79fbb542576c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='invoices:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-7ff594624433',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='invoices:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-8387dba784a9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='payments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-8482395764e3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='payments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-894fa2f23c33',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='payments:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-8c341f4feb2b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='payments:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-9380f7e522df',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='settings:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-9678309ab45b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='settings:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-9ba18fe25ab5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='settings:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-9e7db2f8a571',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='settings:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-a103299d6764',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='privacy-requests:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-a78116ad6ed6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='privacy-requests:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-ab0bde39bfc2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='privacy-requests:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-afd26e66e74e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='privacy-requests:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-b3fa383a5d76',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='roles:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-b60868ccb0ab',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='audit-logs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-bb82ef215a23',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='notifications:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-bee8bafe7ee1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='reports:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-c33ca1f6cdf5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='backups:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-c5278ad8f9b2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-ca646d9c2a08',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pages:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-cc6fa35aed03',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-d0e39d509415',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='blog:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-d751e1aaa4bc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-db1be8e12535',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='faqs:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-de52c6171b1b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-e3b774c86f58',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='testimonials:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-e5361574d135',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-e8d7311c22bb',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='media:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-ed63b200bfab',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-f3418ae7cf61',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='menus:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-f66ba355cd88',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='courses:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-f989bd6e0b92',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='courses:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a882-fd24c1bbb9ce',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pricing-plans:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-026b6ea85148',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='pricing-plans:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-0759b95238ee',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:assign' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-0858646a52da',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:convert' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-0f3633d857de',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:status' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-1364651e3966',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='trials:notes' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-160d25b935bb',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='teachers:availability' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-19fbc526f6c8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='exports:all' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-1c356c1b82c5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='exports:admissions' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-230652bfd7bd',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='exports:academic' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-24d5abfcd339',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='exports:content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-28b72123caf4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='ai:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-2e8a941dc68c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='ai:draft' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-3214d04c66be',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='ai:toggle' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-37c2f75f5b06',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='ai:evaluate' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-3b8ba9913df3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='ai:insights' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-3dbc84b60846',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='users:security' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-412a66e4a908',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='settings:security' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-4695736d15ed',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='SUPER_ADMIN' AND p.key='retention:execute' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-4850c8466ed1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='users:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-4fab8e3f420b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='users:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-538e593cbd2d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='users:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-5451e4991528',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='users:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-597374ed2eb5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-5f19875ebd99',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-603ce8ccb4c1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-65ae0bafb744',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-68b1afb37ae1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-6fa55406741a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-7307d5993097',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-771c5f90f16e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-788e0c283aa1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-7e8de0a5096e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-81b43c2c668e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-8787d678d78e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-8b862c7755e8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-8cb679eb12c5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-91b869b25526',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-978ef6623c57',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-98444aa7bcd8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-9c226f23cf9b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-a39b86e94635',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-a64bc9ef4416',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-aa6b2ee940ca',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-ac53482ae39b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-b339841d466e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-b7c5635492ca',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-b9f8e6c5a04b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='courses:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-bea77b0b99c1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='courses:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-c28e1d8d411a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='courses:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-c4d248011e18',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='courses:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-cbcee989dc5d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='teachers:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-ce07a70d9ae8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='teachers:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-d22f2dcf3177',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='teachers:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-d4424d8f0566',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='teachers:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-d8586366a428',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-dd8afc03fcb5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-e1bb624b2225',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-e4d7181fb903',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-e964208a1737',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='contact-messages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-ef9a6de70d1f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='contact-messages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-f2a614eb321b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='contact-messages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-f41c7d34a48e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='contact-messages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-fb7d83efdba1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='students:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a883-fe8f26733f97',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='students:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-006dceab6953',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='students:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-060e22addba1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='students:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-0841bd823449',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='guardians:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-0db81104a73e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='guardians:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-128be828e7f3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='guardians:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-1765abd6ea35',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='guardians:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-185d22556bdb',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='enrollments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-1d4e26748413',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='enrollments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-21207ff44943',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='enrollments:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-25509092ff99',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='enrollments:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-2a22c4728480',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='schedules:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-2c7ab2f9af87',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='schedules:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-32a3aae7d04f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='schedules:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-3719f6130daa',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='schedules:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-3b9ad324985f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='sessions:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-3f52cc584d95',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='sessions:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-40801dfbabd1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='sessions:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-4721a959452a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='sessions:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-4a006ced5159',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='attendance:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-4c06167daf5c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='attendance:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-52af54dff745',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='attendance:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-54348a452aa2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='attendance:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-5b040b132f11',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='progress:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-5c626a109e4c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='progress:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-63554c44b108',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='progress:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-659b30a2905b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='progress:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-69fbf7d33e7f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pricing-plans:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-6dca471377e7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pricing-plans:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-71d90e3f3c96',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pricing-plans:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-76890a803a5f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pricing-plans:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-793f2efa56e9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='invoices:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-7d2f0697e9bf',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='invoices:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-82f78266a485',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='invoices:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-868dae9def4b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='invoices:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-8860a626bb2a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='payments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-8fd53f12a826',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='payments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-90237b4dc2ba',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='payments:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-978e314d596d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='payments:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-997e4fadb07a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='settings:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-9dea23fd0020',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='settings:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-a1e6451dfbba',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='settings:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-a7af6fc9b853',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='settings:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-a9b153f56ca7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='privacy-requests:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-ac7c0b12b3e3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='privacy-requests:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-b1b8a48a9f4b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='privacy-requests:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-b5420cf7cb20',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='privacy-requests:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-b9d1e4cd5eac',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='roles:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-bef7dff72049',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='audit-logs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-c2706693f257',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='notifications:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-c593aef6174a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='reports:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-c83d317ed4d3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='backups:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-cc1442c463bb',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-d317f8cff7de',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pages:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-d7b7a908fbb1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-d92d5b3761eb',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='blog:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-de5b06e336c0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-e1997008e00f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='faqs:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-e493c3deabbe',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-eb3c9149954e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='testimonials:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-ee5c2cb2d61a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-f3d53360ddf8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='media:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-f59144430146',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884a-778f-a884-fad2a69b1125',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='menus:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48c-d8830177efac',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='courses:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48c-dea26cd144a2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='courses:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48c-e39723a86802',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pricing-plans:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48c-e6a29da7a130',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='pricing-plans:publish' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48c-ea2960fa4dc6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:assign' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48c-ef23d690bcda',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:convert' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48c-f0b11e443a64',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:status' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48c-f7de613b50a7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='trials:notes' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48c-fb676963ab53',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='teachers:availability' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48c-fc5846518482',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='exports:all' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-01642f1d294d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='exports:admissions' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-0709a0163dd2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='exports:academic' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-0bf1b4612fb1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='exports:content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-0c3e51c8a1c3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='ai:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-106c38b679c9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='ai:draft' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-148450dbdd87',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='ai:toggle' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-1ab4c5cc72e2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMIN' AND p.key='ai:insights' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-1faedbf5729a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-2155c44faa98',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-267ce61c0bba',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-2bcc12b06d44',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-2c414b73c6f4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='blog:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-33aa42288c20',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='blog:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-35135bf7fa44',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='blog:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-3ba13310446a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='blog:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-3db61dcf4b58',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='faqs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-4211381a4bc3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='faqs:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-467e34b66ca3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='faqs:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-496c6e14027a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='faqs:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-4f49a6dfefca',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='testimonials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-5211fb6a8aad',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='testimonials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-557c3c6aeb60',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='testimonials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-5a3d42d59665',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='testimonials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-5fa3e39b081c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='media:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-621a546b873f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='media:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-67cc50295c31',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='media:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-6be17e8c4a46',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='media:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-6c648dece7e7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='menus:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-7225fbdccc0b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='menus:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-77320240a87a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='menus:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-794507a6b9a7',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='menus:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-7d9b7310b242',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pages:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-8353a0bc8321',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='blog:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-85c6194d07ca',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='faqs:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-8b084db5958c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='testimonials:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-8ddd0aa12929',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='media:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-90d1f8ab61c0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='menus:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-94b347a579ce',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='courses:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-9a8c56da32c4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='courses:update-content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-9c85e72241d5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='teachers:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-a21621a04108',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='teachers:update-content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-a5e84d5c993d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='courses:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-ab9321ef2478',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='pricing-plans:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-ae9ebf874f04',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='exports:content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-b1c6323927bd',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='reports:content' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-b537dc4a6a36',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='ai:draft' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-ba439e15bda5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-bdb6092b3510',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-c30f5d31b690',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-c54285011e0e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-cba8dc111d2f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='contact-messages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-cc14ed5dde8c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='contact-messages:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-d081b24fd1f1',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='contact-messages:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-d445f581f273',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='contact-messages:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-d84549776d55',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='courses:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-dd187091a520',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='teachers:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-e3c1cba5cdc4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='students:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-e7e8141ef71a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='students:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-ea7221d5c2db',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='guardians:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-ef75d72b2893',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='guardians:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-f163dee0d9d4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='enrollments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-f604dc15274c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='enrollments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-f838e7677f67',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='schedules:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48d-fe48ea05c863',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='sessions:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-00d24fe1a0e2',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='attendance:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-0599a0407dd9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='progress:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-0acf3754b66b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='pricing-plans:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-0d440e80fb91',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='invoices:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-1064f0246dd6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='payments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-146407ce24b4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:assign' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-18c44d2f9cbc',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:convert' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-1c74a2cd6e49',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:status' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-23846b0ae72b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='trials:notes' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-26028fb4077e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='exports:admissions' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-28901beb7c2d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='reports:admissions' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-2c46a7a2ec68',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='courses:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-3149b05fd040',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='courses:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-355ae16f9cd8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='courses:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-3b847622a6fe',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='courses:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-3ffdf3c90a6b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='teachers:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-4075d99648ab',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='teachers:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-46e0d03f3726',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='teachers:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-4a8d687a95c4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='teachers:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-4d20e6fa926d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='students:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-505e4244ad96',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='students:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-54c9ce45d3f3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='students:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-5a6e23026a8b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='students:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-5cf8a827b7d9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='guardians:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-61a53ba2116d',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='guardians:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-64361e3f948e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='guardians:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-69fc00a0c5a8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='guardians:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-6ff6eb7dc438',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='enrollments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-72b18e45a35a',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='enrollments:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-77219e1aa6db',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='enrollments:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-795eaa7fe432',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='enrollments:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-7d6954d4cd9f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='schedules:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-80103a103547',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='schedules:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-870fd5311b91',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='schedules:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-8bdaadc51556',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='schedules:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-8f0039a876b3',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='sessions:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-90bcb4d1c51c',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='sessions:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-9585e6d69746',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='sessions:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-9b64bcea7fe9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='sessions:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-9c8947205529',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='attendance:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-a35aa908c6e4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='attendance:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-a470813ba3fd',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='attendance:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-aa0c9f1cfb75',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='attendance:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-afce0a4d33fa',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='progress:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-b21ea88c19c9',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='progress:create' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-b753db2f442f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='progress:update' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-ba03c7133e89',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='progress:delete' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-bda2fccde9e0',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='pages:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-c0df7c4f58e6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='blog:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-c7d68ccdbfc4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='faqs:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-cbef98279cf5',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='testimonials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-ceb6dfa8221f',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='media:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-d144ccbfac8b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='menus:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-d4872add32c8',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='pricing-plans:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-db29f0310616',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='invoices:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-df7562425f01',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='payments:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-e1097b940265',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='courses:submit' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-e5b323574c28',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='trials:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-eb37ec3869e4',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='trials:assign' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-ec2aae6eb358',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='exports:academic' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-f28de56d7b47',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='reports:academic' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-f6a5252b4bfb',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='ai:insights' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-fb7079fc690b',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='ai:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b0a-884b-74ba-b48e-fcdaf2730e8e',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='teachers:availability' ON CONFLICT ("roleId","permissionId") DO NOTHING;

$source$;
    INSERT INTO public._prisma_migrations (id, checksum, migration_name, finished_at, applied_steps_count)
      VALUES ('8ce4ccd4-0135-428d-e159-b2574c1c08b3', '8ce4ccd40135428de159b2574c1c08b3a2dbc846d1832d0d7921762a5ceb3604', '202610110003_catalog_permissions', now(), 1);
  END IF;
END
$migration$;

DO $migration$
BEGIN
  IF EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '202610110004_notification_permissions' AND rolled_back_at IS NULL AND (checksum <> 'e5927b71c0c8c19bd2af4c64fc7ed7e4ff47770f0652b72de119b188e322325a' OR finished_at IS NULL)) THEN
    RAISE EXCEPTION 'Migration 202610110004_notification_permissions is changed or incomplete; inspect before continuing';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '202610110004_notification_permissions' AND finished_at IS NOT NULL AND rolled_back_at IS NULL) THEN
    EXECUTE $source$
-- Staff can read only their own internal notifications. System constants only.
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b3c-bfb0-72f5-840e-09c1f34b3670',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='CONTENT_EDITOR' AND p.key='notifications:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b3c-bfb1-75b0-b1d0-aa537bfc7ed6',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ADMISSIONS' AND p.key='notifications:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;
INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '01a12b3c-bfb1-75b0-b1d0-aea5b944fc81',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='ACADEMIC_COORDINATOR' AND p.key='notifications:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;

$source$;
    INSERT INTO public._prisma_migrations (id, checksum, migration_name, finished_at, applied_steps_count)
      VALUES ('e5927b71-c0c8-c19b-d2af-4c64fc7ed7e4', 'e5927b71c0c8c19bd2af4c64fc7ed7e4ff47770f0652b72de119b188e322325a', '202610110004_notification_permissions', now(), 1);
  END IF;
END
$migration$;

DO $migration$
BEGIN
  IF EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '202610120001_supabase_portability' AND rolled_back_at IS NULL AND (checksum <> '2df479649691f26fcd80a4f745fc9267ecaa9e8bd19f3ed3abd3f384da3e0f6b' OR finished_at IS NULL)) THEN
    RAISE EXCEPTION 'Migration 202610120001_supabase_portability is changed or incomplete; inspect before continuing';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public._prisma_migrations WHERE migration_name = '202610120001_supabase_portability' AND finished_at IS NOT NULL AND rolled_back_at IS NULL) THEN
    EXECUTE $source$
-- Shared PostgreSQL rate limiting works across serverless instances without Redis.
CREATE TABLE "RateLimitBucket" (
  key TEXT PRIMARY KEY,
  count INTEGER NOT NULL CHECK (count > 0),
  "expiresAt" TIMESTAMPTZ(3) NOT NULL
);
CREATE INDEX "RateLimitBucket_expiresAt_idx" ON "RateLimitBucket" ("expiresAt");

-- Staff identity is managed by the application (MFA + RBAC), not Supabase Auth.
-- Browser/API roles must never read these tables, including password hashes.
-- Connect the server as the table owner; do not put DATABASE_URL in NEXT_PUBLIC_*.
ALTER TABLE public."Role" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Role" FROM PUBLIC;
ALTER TABLE public."Permission" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Permission" FROM PUBLIC;
ALTER TABLE public."RolePermission" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."RolePermission" FROM PUBLIC;
ALTER TABLE public."User" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."User" FROM PUBLIC;
ALTER TABLE public."Session" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Session" FROM PUBLIC;
ALTER TABLE public."PasswordResetToken" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."PasswordResetToken" FROM PUBLIC;
ALTER TABLE public."InviteToken" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."InviteToken" FROM PUBLIC;
ALTER TABLE public."MfaSetupToken" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."MfaSetupToken" FROM PUBLIC;
ALTER TABLE public."MfaBackupCode" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."MfaBackupCode" FROM PUBLIC;
ALTER TABLE public."AuditLog" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."AuditLog" FROM PUBLIC;
ALTER TABLE public."Course" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Course" FROM PUBLIC;
ALTER TABLE public."CourseModule" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."CourseModule" FROM PUBLIC;
ALTER TABLE public."Teacher" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Teacher" FROM PUBLIC;
ALTER TABLE public."TeacherCourse" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."TeacherCourse" FROM PUBLIC;
ALTER TABLE public."TeacherAvailability" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."TeacherAvailability" FROM PUBLIC;
ALTER TABLE public."TrialApplication" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."TrialApplication" FROM PUBLIC;
ALTER TABLE public."TrialHistory" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."TrialHistory" FROM PUBLIC;
ALTER TABLE public."TrialNote" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."TrialNote" FROM PUBLIC;
ALTER TABLE public."ContactMessage" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."ContactMessage" FROM PUBLIC;
ALTER TABLE public."Student" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Student" FROM PUBLIC;
ALTER TABLE public."Guardian" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Guardian" FROM PUBLIC;
ALTER TABLE public."StudentGuardian" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."StudentGuardian" FROM PUBLIC;
ALTER TABLE public."Enrollment" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Enrollment" FROM PUBLIC;
ALTER TABLE public."ClassSchedule" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."ClassSchedule" FROM PUBLIC;
ALTER TABLE public."ClassSession" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."ClassSession" FROM PUBLIC;
ALTER TABLE public."Attendance" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Attendance" FROM PUBLIC;
ALTER TABLE public."ProgressRecord" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."ProgressRecord" FROM PUBLIC;
ALTER TABLE public."PricingPlan" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."PricingPlan" FROM PUBLIC;
ALTER TABLE public."PricingPlanPrice" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."PricingPlanPrice" FROM PUBLIC;
ALTER TABLE public."Invoice" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Invoice" FROM PUBLIC;
ALTER TABLE public."PaymentRecord" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."PaymentRecord" FROM PUBLIC;
ALTER TABLE public."CMSPage" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."CMSPage" FROM PUBLIC;
ALTER TABLE public."PageSection" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."PageSection" FROM PUBLIC;
ALTER TABLE public."ContentRevision" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."ContentRevision" FROM PUBLIC;
ALTER TABLE public."BlogPost" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."BlogPost" FROM PUBLIC;
ALTER TABLE public."MediaAsset" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."MediaAsset" FROM PUBLIC;
ALTER TABLE public."FAQ" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."FAQ" FROM PUBLIC;
ALTER TABLE public."Testimonial" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Testimonial" FROM PUBLIC;
ALTER TABLE public."MenuItem" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."MenuItem" FROM PUBLIC;
ALTER TABLE public."Setting" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Setting" FROM PUBLIC;
ALTER TABLE public."Redirect" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Redirect" FROM PUBLIC;
ALTER TABLE public."Notification" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Notification" FROM PUBLIC;
ALTER TABLE public."OutboxEvent" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."OutboxEvent" FROM PUBLIC;
ALTER TABLE public."IdempotencyRecord" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."IdempotencyRecord" FROM PUBLIC;
ALTER TABLE public."PrivacyRequest" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."PrivacyRequest" FROM PUBLIC;
ALTER TABLE public."Certificate" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."Certificate" FROM PUBLIC;
ALTER TABLE public."AIKnowledgeDocument" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."AIKnowledgeDocument" FROM PUBLIC;
ALTER TABLE public."AIKnowledgeChunk" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."AIKnowledgeChunk" FROM PUBLIC;
ALTER TABLE public."AIConfiguration" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."AIConfiguration" FROM PUBLIC;
ALTER TABLE public."AIFeedback" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."AIFeedback" FROM PUBLIC;
ALTER TABLE public."AIEvaluationRun" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."AIEvaluationRun" FROM PUBLIC;
ALTER TABLE public."AIUsageMetric" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."AIUsageMetric" FROM PUBLIC;
ALTER TABLE public."AIReviewQueue" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."AIReviewQueue" FROM PUBLIC;
ALTER TABLE public."RateLimitBucket" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."RateLimitBucket" FROM PUBLIC;
ALTER TABLE public."_prisma_migrations" ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public."_prisma_migrations" FROM PUBLIC;
DO $access$
DECLARE role_name TEXT;
BEGIN
  FOREACH role_name IN ARRAY ARRAY['anon', 'authenticated'] LOOP
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = role_name) THEN
      EXECUTE format('REVOKE ALL ON TABLE public."Role" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Permission" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."RolePermission" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."User" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Session" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."PasswordResetToken" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."InviteToken" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."MfaSetupToken" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."MfaBackupCode" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."AuditLog" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Course" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."CourseModule" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Teacher" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."TeacherCourse" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."TeacherAvailability" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."TrialApplication" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."TrialHistory" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."TrialNote" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."ContactMessage" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Student" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Guardian" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."StudentGuardian" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Enrollment" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."ClassSchedule" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."ClassSession" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Attendance" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."ProgressRecord" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."PricingPlan" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."PricingPlanPrice" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Invoice" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."PaymentRecord" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."CMSPage" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."PageSection" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."ContentRevision" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."BlogPost" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."MediaAsset" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."FAQ" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Testimonial" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."MenuItem" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Setting" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Redirect" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Notification" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."OutboxEvent" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."IdempotencyRecord" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."PrivacyRequest" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."Certificate" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."AIKnowledgeDocument" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."AIKnowledgeChunk" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."AIConfiguration" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."AIFeedback" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."AIEvaluationRun" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."AIUsageMetric" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."AIReviewQueue" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."RateLimitBucket" FROM %I', role_name);
      EXECUTE format('REVOKE ALL ON TABLE public."_prisma_migrations" FROM %I', role_name);
    END IF;
  END LOOP;
END
$access$;

$source$;
    INSERT INTO public._prisma_migrations (id, checksum, migration_name, finished_at, applied_steps_count)
      VALUES ('2df47964-9691-f26f-cd80-a4f745fc9267', '2df479649691f26fcd80a4f745fc9267ecaa9e8bd19f3ed3abd3f384da3e0f6b', '202610120001_supabase_portability', now(), 1);
  END IF;
END
$migration$;

COMMIT;
