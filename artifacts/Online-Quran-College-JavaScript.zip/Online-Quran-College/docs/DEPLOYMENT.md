# Deploy Online Quran College

Choose the application host independently of the database. Domain setup is intentionally skipped. Start with the host's assigned HTTPS URL.

## 1. Supabase PostgreSQL

1. Create/select a dedicated Supabase project in your own account. No project access or credentials were available during this implementation.
2. Open its SQL editor and run the complete `supabase/schema.sql` as the project database owner (`postgres`). The SQL installs the required `citext`, `pg_trgm`, `btree_gist` and `vector` extensions, the original application schema, system roles/permissions and the new rate-limit table. Existing extensions in the `extensions` schema are supported.
3. The import is transactional and repeatable: completed migrations are checked and skipped. Existing data is retained. A changed/incomplete recorded migration stops the import. Take a backup before updating a populated project.
4. Under **Connect**, obtain the connection strings. Set server-only `DATABASE_URL` to the **transaction pooler** URL (port 6543) for web requests. Set `DIRECT_URL` to a **session pooler** (port 5432) or direct database URL for migrations and the long-lived worker. Use the host and project-specific username supplied by Supabase; do not guess them.
5. Use `sslmode=verify-full` in both cloud URLs and URL-encode special characters in passwords. If your connection requires a provider CA, supply its official certificate using the host's trusted CA configuration or libpq's `sslrootcert` URL parameter. Do not turn off certificate verification.

Alternatively, apply the versioned migrations from your own machine with the same private environment variables:

```sh
pnpm db:generate
pnpm db:migrate
```

The SQL editor import and CLI migrations share `_prisma_migrations` and checksums; using the CLI after the SQL import is supported and tested. After adding a new migration, run `pnpm db:sql` to regenerate the editor import.

The application retains its existing staff identity, MFA and RBAC system. It does not use Supabase Auth. Application tables have RLS enabled and no browser policies; privileges are revoked from `PUBLIC`, `anon` and `authenticated`. All access goes through the protected Node.js API using the database owner connection. Never put database credentials in `NEXT_PUBLIC_*` variables or frontend code. Use a dedicated database/project and keep the connection string in your host's server secrets.

## 2. Runtime variables

Use `.env.supabase.example` as the template. On a local machine save private values to `apps/web/.env`; for Compose use `apps/web/.env.production`. These files are ignored and excluded from Docker builds.

| Variable | Purpose |
| --- | --- |
| `NODE_ENV=production` | Production cookie/configuration rules |
| `APP_URL` | Host-assigned HTTPS URL; exact origin used for CSRF |
| `DATABASE_URL` | Supabase transaction pooler or verified PostgreSQL URL |
| `DIRECT_URL` | Session pooler/direct URL for migrations and worker |
| `DATABASE_POOL_SIZE=3` | Connections per web process; budget across instances |
| `AUTH_SECRET` | Random server secret, at least 32 characters; keep stable |
| `RATE_LIMIT_DRIVER=postgres` | Shared database rate limiting without Redis |
| `CRON_SECRET` | Optional random 32+ character bearer secret for scheduler |
| `INDEXING_ENABLED=false` | Keep staging out of search results |
| `DEPLOYMENT_ENVIRONMENT=staging` | Existing launch controls |

Generate random secrets locally with a password manager or `node -e "console.log(require('node:crypto').randomBytes(48).toString('base64url'))"`. Enter them in your host's secret settings; never commit them. A proxy placeholder is not suitable for a raw PostgreSQL password or a local encryption secret: these must be actual server runtime values on your chosen host.

For optional Redis set `RATE_LIMIT_DRIVER=redis` and a private `REDIS_URL`. Database mode fails closed if the shared store is unavailable.

## 3A. Any Node.js host / VPS / Railway / Render

Working directory: repository root. Install Node 24 and pnpm 10.34.6.

```sh
pnpm install --frozen-lockfile
pnpm db:generate
pnpm build
pnpm start
```

Set the provider's `PORT` if required. The server binds to `0.0.0.0`. Set environment variables at runtime and terminate HTTPS at the provider or your reverse proxy. Run migrations as a deliberate deployment step, not concurrently in every web replica.

Run `pnpm worker` as a separate long-lived process for scheduled publication and internal notifications. The worker uses the session/direct URL. Configure a process supervisor/restart policy.

## 3B. Docker

```sh
docker build --target web -t online-quran-college .
docker build --target tools -t online-quran-college-tools .
# Configure apps/web/.env.production first.
docker compose -f compose.deploy.yml up -d --build
```

Compose binds the web port to loopback; place your HTTPS reverse proxy in front of it. On a container hosting provider, deploy the `web` image and expose `PORT=3000` using the provider's routing. The `tools` image runs the worker by default and also supports one-off commands:

```sh
docker run --rm --env-file apps/web/.env.production online-quran-college-tools node scripts/migrate.mjs
docker run --rm -it --env-file apps/web/.env.production online-quran-college-tools node --import ./scripts/register.mjs scripts/bootstrap-admin.js --email your-staff-address --confirm-production
```

If your build machine uses an organization TLS proxy, pass its trusted public CA as a BuildKit secret: `docker build --secret id=build_ca,src=/path/to/official-ca.pem --target web -t online-quran-college .`. The optional CA is used only during installation, is not baked into the image, and certificate verification stays enabled.

The web image runs without root privileges and contains standalone Next.js output, public assets and invoice fonts. Secrets are supplied only at runtime.

## 3C. Vercel

Import the repository and set **Root Directory** to `apps/web`. Include files outside the root directory in the build. Its `vercel.json` installs from the workspace root, generates the Prisma client and builds the application. Use Node 24 and enter the runtime values above.

Vercel cannot keep `pnpm worker` running indefinitely. Use an external scheduler calling `POST /api/internal/jobs` (or authenticated GET for Vercel Cron) every minute with `Authorization: Bearer <CRON_SECRET>`, or run the worker on another Node/Docker host. The endpoint is disabled without a sufficiently long configured secret. Choose a scheduler frequency supported by your provider/plan; pending jobs wait until the next call. Each call publishes at most 20 records, drains at most 50 events and cleans 1,000 expired rate-limit buckets. Increase frequency or use the worker for larger backlogs. Delivery to external email/SMS providers remains inactive.

A generic cron host can instead run `pnpm jobs:once` each minute with private runtime variables. Do not expose scheduler credentials in client JavaScript or URLs.

## 4. Optional media storage

Create a **private** bucket named `oqc` in Supabase Storage. Obtain S3 protocol credentials from Storage settings. Set `S3_ENDPOINT`, `S3_REGION`, `S3_BUCKET`, `S3_ACCESS_KEY` and `S3_SECRET_KEY` as shown in the template. These are S3 credentials, not Supabase API keys. The existing staff-authorized upload/download routes use the S3 adapter. Any compatible private S3 service can replace Supabase Storage. Hosted storage has not been exercised without account access.

## 5. Verify and populate

1. Check `/api/health` and `/api/ready` return HTTP 200.
2. Create your first staff account interactively, enroll MFA and remove `BOOTSTRAP_TOKEN`.
3. Enter actual college content and consent wording; configure anti-bot settings through the existing admin controls before opening admissions.
4. Publish a course and submit a real test application using your own details; verify it appears in admin. Verify worker/scheduler notifications.
5. Configure optional storage if uploads are needed. Verify a real upload and PDF invoice download on the chosen host.

No cloud account, domain or external deployment was provisioned by this workspace. Local test evidence is recorded in `docs/VALIDATION.md`; your chosen provider still needs its own post-deployment checks.
