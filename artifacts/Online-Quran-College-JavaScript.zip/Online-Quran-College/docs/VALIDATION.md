# Validation — JavaScript/Supabase revision

Verified on 12 October 2026 in this cloud workspace. These results apply to this revision; historical reports supplied in the ZIP are in `docs/source-reference`.

| Check | Result |
| --- | --- |
| JavaScript source syntax | Passed, 285 JavaScript/JSX/MJS files; no authored TypeScript source |
| ESLint | Passed |
| Unit tests | 45 passed in 13 files |
| PostgreSQL integration tests | 56 passed in 3 files |
| Chromium end-to-end tests | 15 passed; runner completed, no failed tests |
| Production Next.js build | Passed |
| Local setup script | Passed on an existing prepared database; migrations correctly reported no pending changes |
| SQL editor import | Passed twice on disposable PostgreSQL; compatible with subsequent CLI migrations |
| Supabase extension layout | Tested with extensions installed in `extensions` schema |
| SQL security | RLS enabled on application tables; no PUBLIC table privileges |
| Shared PostgreSQL limits | Concurrent limit enforcement, expiry/reset and storage-failure rejection passed |
| Scheduler authentication | Missing/incorrect/weak secrets rejected; unauthorized HTTP request returned 401 |
| Maintenance CLI | Passed; empty business database correctly returned zero pending work |
| Long-lived worker | Started successfully, including after environment restart |
| Docker web image | Built successfully; ran as non-root in production mode |
| Docker tools image | Built successfully; migrations and maintenance ran as non-root |
| Production container requests | Health, readiness, homepage, courses, staff login and logo returned 200 |
| Production database TLS | Tested with a trusted local test certificate and `sslmode=verify-full` |
| Embedded environment files | No `.env` file in the production web image |
| Development restart | Health, readiness, homepage and staff login returned 200 after restarting services |
| Generated SQL consistency | Regeneration produced identical file content |

The browser suite covered public accessibility, mobile forms, searchable/mobile staff navigation, MFA login, draft approval/publication, trial submission, enrollment, consent, contact workflow, scheduling/attendance, catalog filters, revisions, page editing, pricing and invoice PDF download. Test business records were confined to disposable local databases.

During implementation, a missing Prisma JavaScript runtime dependency was added, native Node alias resolution was corrected for CommonJS dependencies, the API inventory was updated for JavaScript routes, and Docker worker file ownership was corrected. Those affected operations were rerun successfully. Docker installation behind this environment's TLS proxy used its trusted CA through a temporary BuildKit secret; certificate verification was not disabled.

## Boundaries

- No live Supabase project/account connection, hosted storage, external deployment or domain connection was performed. The SQL and server connection configuration are prepared for the user's chosen account.
- ARM/Windows hosts, external hosting providers and WebKit were not tested here. The Linux-specific SWC package is optional, and runtime/install commands avoid an OS-specific application dependency.
- Outbound AI, email and payment gateways remain inactive as in the supplied application. Staff-entered payment records are supported.
- The development database has system constants only. Real college content, the first staff account, reviewed consent/policies and optional external service credentials must be supplied by the owner.
- Cloud installation/startup instructions were saved; a saved configuration or successful local check does not establish live website deployment.
