# Responsive page states

Public: skip link → sticky header → breadcrumb → one H1 → CMS/catalog content or honest empty state → action → policy/footer links. Home follows Appendix A.2, hiding absent trust, benefits, teacher, testimonial and FAQ data. Mobile header opens a keyboard-operable menu; trial CTA remains visible.

Admin: authenticated permission-filtered navigation → heading/actions → filters → table → pagination. Every module has loading, empty, error/retry and populated states. Forms retain values after errors; no preselected consent. Keyboard reorder controls accompany dragging.

Templates: home, content/policy, catalog list/detail, teacher list/detail, pricing, trial/contact, blog list/detail, FAQ/testimonial, errors; admin dashboard, list/detail/edit and workflow views.
