# ADR-017: Explicit next-intl request-config alias

Status: Accepted for this environment.

next-intl's plugin imports @swc/core at configuration load time. The current native loader rejects the container ancestry for its cache even when the cache itself is owned by the agent. No loader protection is disabled.

Use the same documented request-config resolver alias the plugin installs, configured explicitly for Turbopack and Webpack. Experimental message precompilation is not enabled. next-intl still provides request configuration and ICU messages. English is enabled; unreviewed locales remain disabled.

Evidence: Next.js 16.4.0 production compilation, strict TypeScript and page generation pass with the alias.
