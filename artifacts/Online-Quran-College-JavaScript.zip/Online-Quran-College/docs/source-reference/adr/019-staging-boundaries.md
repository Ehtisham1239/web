# ADR 019: Vercel staging and verified database TLS

The user selected Vercel plus managed PostgreSQL. Keep staging credentials in STAGING_DATABASE_URL and STAGING_DATABASE_DIRECT_URL in the cloud operator environment, separately from local DATABASE_URL. Bind the pooled URL as DATABASE_URL in Vercel runtime settings and use the direct URL for a separate migration release job. Do not migrate inside every Vercel build or request.

Production runtime configuration requires PostgreSQL sslmode=verify-full and an HTTPS APP_URL. Provider certificate/region/extension support still needs verification with the actual managed service. Authenticated deployment access is not present, so no remote deployment or database operation is claimed.

A persistent worker service is separate from Vercel request handlers. The current worker creates internal notifications only. Provider activation, production launch and owner signoff remain separate gates.
