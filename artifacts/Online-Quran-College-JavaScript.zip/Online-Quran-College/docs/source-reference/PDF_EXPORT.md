# Invoice PDF export

Staff with invoices:read can download an issued/paid/void invoice from its detail screen. Export uses POST with exact Origin, session, CSRF and recent password/MFA verification. The endpoint is rate limited, returns a private no-store PDF attachment, and audits a checksum without copying names or document contents into audit records.

Amounts come from the invoice and its non-deleted payment records. Currencies remain separate. Voided invoices show zero amount due and their VOID status. The document records its generation time and shows at most 100 payment rows; its aggregate includes all payment rows. Linked learner/course display names are current values; historical invoice line snapshots remain a release item.

The original owner logo is embedded unchanged. DejaVu Sans regular/bold fonts are embedded/subsetted to preserve Unicode text. Fonts were copied unchanged from the trusted cloud machine's fonts-dejavu-core package; redistribution notices are in apps/web/assets/pdf/FONT_LICENSE.txt. The font files passed the installed package's checksum verification; stripped optional package documentation was absent. No font is fetched when exporting.

PDFKit is pinned. Documents include language, title, figure alt text, headings, paragraphs and a structure tree. Integration checks use independent Poppler text extraction and metadata inspection. Full PDF/UA/manual screen-reader and non-Latin visual verification remain pending; tagging alone does not establish conformance.

PDF runtime does not require Poppler. PDF integration/browser verification requires pdftotext and pdfinfo (poppler-utils); both are available in the current cloud machine, and the prepared CI installs poppler-utils. Remote CI has not been run.
