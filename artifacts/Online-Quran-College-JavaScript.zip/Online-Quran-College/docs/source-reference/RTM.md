# Requirements traceability

| ID | Requirement section | Module | Verification | Status |
|---|---|---|---|---|
| R00 | How Codex Must Use This Document | docs | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R01 | Product Summary | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R02 | Brand and Design System | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R03 | Technology Stack (DECIDED) | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R04 | Repository Structure (DECIDED) | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R05 | Environment Configuration (`.env.example`, all documented) | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R06 | Data Model (DECIDED; implement as Prisma schema + migrations) | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R07 | Authentication, Authorization and Permission Matrix | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R08 | Public Website Specification | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R09 | Free Trial and Contact Journeys | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R10 | Admin Panel Module Specifications | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R11 | API Contracts | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R12 | AI Architecture (disabled by default) | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R13 | AI Safety, Privacy and Religious Accuracy | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R14 | Security Requirements | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R15 | SEO, Performance and Accessibility | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R16 | Testing and Evaluation Plan | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R17 | Phased Backlog with Exit Criteria | docs | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R18 | Deployment and Operations | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R19 | Deliverables Checklist | docs | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R20 | Owner Decisions and TBD Register | docs | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R21 | Engineering Team Charter (Codex acts as every role) | docs | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R22 | No-Seed-Data Policy and System Bootstrap | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R23 | Architecture Deep-Dive (Principal Architect) | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R24 | Data Engineering (Database Engineer) | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R25 | Backend Engineering Standards (Staff Backend Engineer) | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R26 | Frontend, UX and Design-Systems Engineering | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R27 | Security Engineering (AppSec) | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R28 | Privacy, Child Safety and Compliance Engineering | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R29 | AI and LLM Engineering Deep-Dive | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R30 | QA and Test Engineering Deep-Dive | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R31 | SRE, DevOps and Infrastructure Engineering | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R32 | Performance Engineering | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R33 | Accessibility and Inclusive-Design Engineering | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R34 | Localization, Typography and Content Integrity | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R35 | Product, KPIs and Operations (inside the scope boundary) | web / worker / infrastructure | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R36 | Release Management, Documentation and Handover | docs | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R37 | Risk Register | docs | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R38 | Epics, Stories and Acceptance Criteria | docs | Planned: unit, integration, E2E or documented review as applicable | Pending |
| R39 | Codex Master Execution Command and Operating Protocol | docs | Planned: unit, integration, E2E or documented review as applicable | Pending |

Fine-grained story coverage is recorded as each implementation lands; planned checks are not passing evidence.


## Implemented slices with executed verification

These entries verify specific behavior; they do not close the parent epic or its remaining release gates.

| Epic / specification area | Implemented slice | Actual evidence | Remaining scope |
|---|---|---|---|
| E1–E2 / sections 3–6, 22–25 | Pinned toolchain, repeatable install, PostgreSQL extensions, schema/migrations, system-only constants, audit and scheduling constraints | Tested setup script, generation, migration repeatability and fresh-database integration tests | Full IaC/runtime packaging and production privilege review |
| E3 / sections 7, 27 | Mandatory privileged MFA, backup-code replay rejection, lockout, hashed sessions, 48-hour invitations, 30-minute resets, cross-tab CSRF, last-owner protection, self-session revocation | Identity/security integration tests and staff browser flows | MFA recovery with second confirmation, identity-device metadata and complete adversarial pack |
| E4–E5 / sections 2, 8, 15, 26 | Original PDF logo, responsive empty/populated public catalog, filters, SEO/RSS, related content, custom pages, navigation and approved-content projection | Desktop/mobile screenshots; 44 public-page accessibility scans and 66 responsive route checks; no serious/critical violations or horizontal overflow | Owner brand approval, logo derivatives, manual accessibility and performance budgets |
| E6 / section 9 | Mobile trial steps, three preferred time ranges, privacy-limited draft recovery, trial/contact validation, bot checks, consent approval/version history, stale-consent rejection, persisted submissions, replay/duplicate handling and transactional conversion | Admissions integration tests and browser trial/contact/conversion/consent flows | Operational SLAs, advanced filters and complete contact-note history |
| E7 / section 10 | Draft/submit/approve/publish, sanitized rich text, typed sections, signed private preview, scheduled publication, revision diff/restore, menus and redirects | Publishing/XSS/concurrency integration checks and publication browser flow | Last-published snapshots and media storage verification |
| E8 / section 10 | Course syllabus add/edit/reorder/remove, teacher-course assignments, weekly availability, per-currency pricing and visibility | Dedicated integration checks and syllabus/teacher/fee browser flows | Media associations and owner content |
| E9 / section 10 | Guardian linkage, manual enrollment, duplicate-enrollment protection, trial conversion, DST-safe schedules and database overlap constraints | Academics integration checks and enrollment browser flows | Session rescheduling/calendar/attendance UI, certificates and suggested free slots |
| E10 / section 10 | Integer money, sequence numbers, invoice/payment transactions and overpayment prevention | Finance/concurrency integration tests | Invoice PDFs, overdue administration, void/correction workflows |
| E11 / section 10 | Permission-scoped aggregate reports, recent-auth CSV export, formula escaping, personal notifications and atomic outbox draining | Report/export/outbox integration checks; actual local worker startup | Dashboard views, full query/index/load review and operational alert routing |
| E12 / section 28 | Guardian-led validation, versioned owner-approved consent and no private AI inputs | Validation, consent integration/browser checks and disabled AI endpoint check | DSAR, anonymization proof, retention dry run/jobs, RoPA/DPIA and legal signoff |
| E15–E16 / sections 16, 18, 30, 33 | Unit/integration/Chromium/WebKit packs, compiled production browser target, local encrypted restore, staging/CI configuration | QA_EVIDENCE.md records counts and exact scope | Full performance/security/chaos/mutation gates, remote CI, staging deployment, production drills and UAT |

E13–E14 remain disabled and incomplete. No live AI evaluation or provider integration has been claimed. See IMPLEMENTATION_STATUS.md and QA_EVIDENCE.md for current check counts and blockers.
