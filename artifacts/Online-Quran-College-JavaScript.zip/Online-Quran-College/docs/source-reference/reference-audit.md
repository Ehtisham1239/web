# Reference audit

2026-10-11: `curl -I --max-time 20 https://www.tarteelequran.com/` failed: CONNECT tunnel HTTP 403 from the egress proxy. No reference content was copied. All live course, teacher, blog, policy, quality, certificate and location observations remain unverified. Members area is out of scope and unverified. Appendix A observations are supplied specification claims, not observations performed here.

| Reference | OQC equivalent | Implementation / QA | Status |
|---|---|---|---|
| Home/navigation | CMS-backed home/navigation | Pending | Unverified reference |
| Courses/teachers | Catalog and public directory | Pending | Unverified reference |
| Schedule/fees | Approved pricing only | Pending | Unverified reference |
| Contact | Separate contact/trial flows | Pending | Unverified reference |
| Policies/blog/quality/certificates | Reviewed CMS pages | Pending | Unverified reference |

Logo derivatives, browser screenshots, visual comparison and similarity checks remain pending.
