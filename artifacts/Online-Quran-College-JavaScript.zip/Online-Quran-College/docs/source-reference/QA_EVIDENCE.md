# QA evidence

2026-10-12, local cloud machine. Only executed checks are counted.

| Check | Actual result | Scope / limitation |
|---|---|---|
| GitHub read-only access | Passed | Selected repository only |
| Public design reference | HTTP 403 proxy denial | Live reference unverified |
| PostgreSQL / Redis | Healthy | Local PostgreSQL 16 + pgvector and Redis containers |
| Schema/client generation | Passed | Verified npm/WASM toolchain |
| Migrations | Four applied; repeat reports none pending | Local oqc_dev and disposable databases |
| Repeatable cloud install | Passed | Frozen install, preserved local settings, services, generation, migrations, typecheck, no-seed check |
| Unit | 42 passed | Security, crypto, RBAC, DST, validation, exact money conversion and image processing |
| Integration | 52 passed | Disposable PostgreSQL databases; concurrency, authorization, identity, publication, admissions, finance, availability, syllabus, session revocation, pricing, manual enrollment and versioned consent and independent PDF text/tag checks |
| Encrypted backup/restore | Passed within integration suite | Actual local pg_dump/pg_restore, schema/data/grants verification and tamper rejection; not production recovery |
| TypeScript | Passed | Complete current website/CMS source |
| ESLint | Passed without warnings | Complete current website/CMS source |
| Production build | Passed on 2026-10-12 | Also rebuilt by browser runner into isolated .next-e2e output |
| Browser + axe | 15 Chromium + 15 WebKit passed | Both native engines; includes mobile preference privacy, signed CMS preview, revision restoration, page sections and scheduled publication; eight public/admin-login pages scanned with zero serious/critical violations. Compiled production output; disposable test owner explicitly opts out of the unconfigured bot provider. |
| Dependency audit | Zero advisories across the full graph | Pinned PDFKit and scoped glob-chain remediation; compatibility probe, repeated client generation and frozen setup passed |
| PDF deployment assets | Passed | Standalone build tracing includes both embedded font files and the original logo |
| Root-free WebKit setup | Passed, repeated | Signed Debian 13 indexes and package SHA-256 verification, extraction only, original browser files preserved, native rendering probe; helper documented |
| Website scheduler worker | Restarted and processing jobs | Current owned worker; due-publication concurrency/permission checks covered by integration tests, no external delivery |
| Responsive website review | 66 route/viewport checks passed | 22 public pages at 320/768/1440px, no horizontal overflow or browser errors; missing-route HTTP 404 verified |
| Expanded public axe review | 44 scans passed with zero serious/critical violations | 22 pages at 375/1440px; empty developer content, automated check only |
| Mobile Lighthouse 13.5.0 | Performance 98, accessibility 100, best practices 100; SEO 69 | LCP 2.3s, CLS 0.001, TBT 50ms; empty public homepage, simulated mobile lab only. SEO reduced by intentional prelaunch noindex/robots block. INP and field performance unmeasured. Local font preload replaced stylesheet font discovery. |
| Private storage | Blocked | MinIO image pull denied; S3 upload/download not exercised against a storage service |
| CI / Vercel staging | Unrun | Configured locally; remote project, managed database and credentials unavailable |
| Owner brand/legal/content approval | Pending | Original logo retained; no invented business records |
| Full release gates | Unrun | Manual accessibility, load, security/mutation/chaos, live AI/provider evaluations, production recovery and UAT |

Earlier failed test attempts are not counted as passes. The browser runner now builds the app before starting its test server; no developer HMR is involved. Local runtime configuration remains a test environment, so this is not a claim of verified production TLS/provider integration.

The development database has no real users or business content. Synthetic test records live only in disposable databases, which the runners destroy. No remote deployment or outbound messaging is activated.

Final screenshots were refreshed against the empty development database. A stale development module after sharing the normal build directory was diagnosed and resolved; the launcher now isolates development output in `.next-dev`. Screenshot capture rejects error boundaries and waits for images and fonts to decode. The repeated startup returned ready and rendered the home/catalog normally.

The final WebKit pass must include completed save feedback before leaving settings. An earlier run exposed navigation before router refresh completion; the first feedback change revealed that a value-derived component key remounted the form and erased that feedback. The social editor now retains its component identity, clears confirmation on edits, and exposes success only after refresh completion. Failed attempts are not counted as passes.

The navigation-link and invoice/payment browser flows likewise wait for their saved table rows before navigating; observing a committed database row alone does not guarantee that the client router refresh is complete. This adds UI persistence checks without changing timeouts or retries.
