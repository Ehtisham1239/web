# Security design

### 27.1 STRIDE threat model (maintain in `docs/SECURITY.md`; Codex extends it per feature)
| Component | Spoofing | Tampering | Repudiation | Info disclosure | DoS | Elevation |
|---|---|---|---|---|---|---|
| Public forms | Bot submissions: Turnstile, honeypot | Payload tampering: Zod strict schemas | Idempotent reference and audit | Duplicate probing: identical confirmation | Rate limits, body caps | n/a |
| Admin login | Credential stuffing: lockout, MFA | Session fixation: rotate on login | Audit of auth events | Enumeration: uniform responses and timing | Lockout abuse: per-account plus IP | Role escalation: server-side RBAC, re-auth |
| Admin APIs | Stolen cookie: HttpOnly, SameSite, device list | CSRF: Origin check plus token | Immutable audit | IDOR: ownership and permission tests on every id route | Export abuse: caps and rate limits | Privilege creep: permission matrix tests |
| File uploads | MIME spoofing: magic-byte check | Polyglot files: re-encode | Checksum and uploader id | Public bucket leaks: private bucket, signed URLs | Zip bombs: size and dimension caps | XSS via SVG: sanitise or reject |
| AI endpoints | Prompt injection via content or user | Poisoned knowledge: approval workflow | Interaction signals logged redacted | PII leakage: redaction, ACL-filtered retrieval, output checks | Cost exhaustion: budgets, per-IP limits, kill switch | Tool abuse: no tools, no write access |
| CI/CD and supply chain | Compromised dependency: lockfile, audit, pinned actions | Tampered artefacts: provenance, SBOM | Signed commits and release tags | Secret leakage: gitleaks, scoped tokens | Runner exhaustion: concurrency limits | Over-broad deploy token: environment protection, least privilege |



Planned controls: Argon2id, opaque hashed sessions, encrypted TOTP secrets, mandatory privileged MFA, per-session CSRF, strict Origin check, server-side RBAC, append-only audit, body caps, private storage and safe upload re-encoding. Production boot fails on missing/default secrets. Security gates remain unrun until implemented.
